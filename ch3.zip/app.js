(function () {
'use strict';
var D = {"subs": [["آب", "H2O", 1, "آب از دو عنصر هیدروژن و اکسیژن ساخته شده است."], ["اکسیژن", "O2", 0, "فقط یک نوع اتم (اکسیژن) دارد."], ["آهن", "Fe", 0, "آهن فقط از اتم‌های آهن ساخته شده است."], ["نمک خوراکی", "NaCl", 1, "از دو عنصر سدیم و کلر ساخته شده است."], ["کربن دی‌اکسید", "CO2", 1, "از دو عنصر کربن و اکسیژن ساخته شده است."], ["طلا", "Au", 0, "طلا یک عنصر است و فقط اتم طلا دارد."], ["هیدروژن", "H2", 0, "فقط اتم‌های هیدروژن دارد."], ["آمونیاک", "NH3", 1, "از دو عنصر نیتروژن و هیدروژن ساخته شده است."], ["مس", "Cu", 0, "مس یک عنصر است."], ["متان", "CH4", 1, "از دو عنصر کربن و هیدروژن ساخته شده است."]], "props": [["رسانایی الکتریکی خوب", 1], ["چکش‌خواری", 1], ["سطح براق", 1], ["شکنندگی و خرد شدن با ضربه", 0], ["رسانای ضعیف گرما", 0], ["قابلیت تبدیل شدن به سیم", 1], ["سطح مات", 0], ["رسانای خوب گرما", 1], ["عایق بودن در برابر برق", 0], ["صدای زنگ‌مانند هنگام ضربه", 1]], "bank": [["کوچک‌ترین ذره سازنده یک عنصر چه نام دارد؟", ["مولکول", "اتم", "سلول", "یون"], 1, null], ["کدام ذره در هسته اتم بار مثبت دارد؟", ["الکترون", "نوترون", "پروتون", "ذره نور"], 2, null], ["الکترون‌ها در اتم چه می‌کنند؟", ["درون هسته ثابت‌اند", "به دور هسته می‌چرخند", "بار مثبت دارند", "جرم اتم را تعیین می‌کنند"], 1, null], ["نوترون چه باری دارد؟", ["مثبت", "منفی", "خنثی", "متغیر"], 2, null], ["کدام یک عنصر است؟", ["آب", "نمک خوراکی", "آهن", "شکر"], 2, null], ["کدام یک ترکیب است؟", ["اکسیژن", "طلا", "مس", "کربن دی‌اکسید"], 3, null], ["فرمول شیمیایی آب کدام است؟", ["CO2", "H2O", "O2", "NaCl"], 1, null], ["مولکول کربن دی‌اکسید در مجموع چند اتم دارد؟", ["۲", "۳", "۴", "۵"], 1, null], ["کدام ویژگی مربوط به فلزهاست؟", ["شکننده بودن", "رسانایی الکتریکی خوب", "مات بودن", "عایق بودن"], 1, null], ["کدام یک نافلز است؟", ["آهن", "مس", "گوگرد", "طلا"], 2, null], ["الماس و گرافیت هر دو از کدام عنصر ساخته شده‌اند؟", ["سیلیسیم", "کربن", "آهن", "اکسیژن"], 1, null], ["سخت‌ترین ماده طبیعی کدام است؟", ["گرافیت", "الماس", "آهن", "مس"], 1, null], ["در حالت جامد ذره‌ها چگونه‌اند؟", ["دور از هم و آزاد", "منظم و نزدیک به هم", "فقط می‌چرخند", "وجود ندارند"], 1, null], ["در حالت گاز ذره‌ها چگونه‌اند؟", ["در جای خود می‌لرزند", "به‌آرامی می‌لغزند", "سریع حرکت می‌کنند و از هم دورند", "بی‌حرکت‌اند"], 2, null], ["تبدیل مایع به گاز چه نام دارد؟", ["ذوب", "انجماد", "تبخیر", "میعان"], 2, null], ["تبدیل گاز به مایع چه نام دارد؟", ["تبخیر", "میعان", "ذوب", "انجماد"], 1, null], ["پخش شدن جوهر در آب چه چیزی را نشان می‌دهد؟", ["آب زنده است", "ذره‌ها در حرکت‌اند", "جوهر سنگین است", "آب ساکن است"], 1, null], ["اتم‌ها را با چشم نمی‌بینیم؛ از کجا به وجودشان پی می‌بریم؟", ["از شواهد غیرمستقیم", "از حدس بی‌دلیل", "از ظاهر ماده", "از رنگ ماده"], 0, null], ["یک مولکول آب چند اتم هیدروژن دارد؟", ["۱", "۲", "۳", "۴"], 1, null], ["نماد شیمیایی طلا کدام است؟", ["Ag", "Au", "Fe", "Cu"], 1, null], ["نماد شیمیایی آهن کدام است؟", ["Fe", "Ir", "Cu", "F"], 0, null], ["گاز هلیم برای چه کاری استفاده می‌شود؟", ["پر کردن بالن‌ها", "ساخت سیم", "ساخت پل", "ساخت جواهر"], 0, null], ["مولکول متان از چه اتم‌هایی ساخته شده است؟", ["کربن و هیدروژن", "کربن و اکسیژن", "هیدروژن و اکسیژن", "نیتروژن و هیدروژن"], 0, null], ["گرافیت برای چه کاری به کار می‌رود؟", ["ساخت مغز مداد", "ساخت جواهر", "ساخت بالن", "ساخت لوله آب"], 0, null]], "m8Qs": [["این پدیده چه چیزی را نشان می‌دهد؟", ["آب ساکن است", "ماده از ذره‌های در حال حرکت ساخته شده است", "جوهر زنده است", "آب و جوهر ذره ندارند"], 1, "جوهر خودبه‌خود در آب پخش می‌شود؛ پس ذره‌ها همیشه در حرکت‌اند."], ["اگر آب گرم‌تر بود، پخش شدن جوهر چگونه می‌شد؟", ["کندتر", "سریع‌تر", "بدون تغییر", "متوقف می‌شد"], 1, "با گرما ذره‌ها سریع‌تر حرکت می‌کنند."], ["چرا ذره‌های آب و جوهر را با چشم نمی‌بینیم؟", ["بسیار ریزند", "شفاف‌اند", "خیلی دورند", "وجود ندارند"], 0, "ذره‌ها بسیار ریزند و از رفتار ماده به وجود آن‌ها پی می‌بریم؛ این یک شواهد غیرمستقیم است."]], "md": [["CO2", 3, [1, 2, 1], [-70, 0, 70], [0, 0, 0]], ["H2O", 3, [1, 0, 0], [0, -45, 45], [0, 40, 40]], ["CH4", 5, [2, 0, 0, 0, 0], [0, -50, 50, -50, 50], [0, -45, -45, 45, 45]], ["CO", 2, [2, 1], [-35, 35], [0, 0]], ["H2O2", 4, [0, 1, 1, 0], [-80, -30, 30, 80], [-30, 0, 0, 30]], ["C2H6", 8, [2, 2, 0, 0, 0, 0, 0, 0], [-30, 30, -60, -60, -85, 60, 60, 85], [0, 0, -45, 45, 0, -45, 45, 0]]], "elems": [["Fe", "آهن", 26, 0, "ساخت سازه‌ها، پل‌ها و ماشین‌آلات"], ["Cu", "مس", 29, 0, "سیم‌های برق و لوله‌کشی"], ["Au", "طلا", 79, 0, "جواهرسازی و قطعات الکترونیکی"], ["O", "اکسیژن", 8, 1, "تنفس موجودات زنده و سوختن"], ["C", "کربن", 6, 1, "سوخت، مغز مداد و الماس"], ["H", "هیدروژن", 1, 1, "سوخت موشک و ساخت آمونیاک"], ["N", "نیتروژن", 7, 1, "ساخت کود شیمیایی"], ["Na", "سدیم", 11, 0, "ساخت نمک خوراکی همراه با کلر"], ["Cl", "کلر", 17, 1, "ضدعفونی کردن آب استخر"], ["He", "هلیم", 2, 2, "پر کردن بالن‌ها"]], "ael": [["هیدروژن", "H", 1, 0, 1, [1, 0, 0, 0], 1, "سبک‌ترین عنصر، سوخت موشک"], ["هلیوم", "He", 2, 2, 2, [2, 0, 0, 0], 1, "گاز بالن و بادکنک"], ["لیتیوم", "Li", 3, 4, 3, [2, 1, 0, 0], 2, "باتری‌های قابل شارژ"], ["کربن", "C", 6, 6, 6, [2, 4, 0, 0], 2, "پایه تمام موجودات زنده"], ["اکسیژن", "O", 8, 8, 8, [2, 6, 0, 0], 2, "ضروری برای تنفس"], ["سدیم", "Na", 11, 12, 11, [2, 8, 1, 0], 3, "نمک خوراکی (NaCl)"], ["آلومینیوم", "Al", 13, 14, 13, [2, 8, 3, 0], 3, "قوطی نوشابه و فویل"], ["آهن", "Fe", 26, 30, 26, [2, 8, 14, 2], 4, "ساخت و ساز و ابزار"]], "mtName": ["آهن", "مس", "طلا", "هلیم", "کلر", "اکسیژن", "کربن", "نیتروژن"], "mtUse": ["ساخت پل و ماشین‌آلات", "سیم‌های برق", "جواهرسازی", "پر کردن بالن‌ها", "ضدعفونی آب استخر", "تنفس موجودات زنده", "مغز مداد و الکترود", "ساخت کود شیمیایی"], "cName": ["الماس", "گرافیت", "فولرن (مدل ساده‌شده)", "نانولوله"], "cBrief": ["هر اتم به ۴ اتم پیوند دارد؛ بسیار سخت", "لایه‌های شش‌ضلعی روی هم؛ نرم و لغزنده", "اتم‌ها روی سطح یک گوی توخالی", "کربنِ لوله‌ای شکل؛ بسیار محکم و سبک"], "cDetail": ["الماس: هر اتم کربن با چهار پیوند به چهار اتم دیگر وصل است. شفاف و درخشان و سخت‌ترین ماده طبیعی است؛ در جواهرسازی و ابزارهای برش به کار می‌رود.", "گرافیت: اتم‌ها در لایه‌های شش‌ضلعی قرار دارند و لایه‌ها با پیوند ضعیف (خط‌چین) به هم چسبیده‌اند. نرم و لغزنده است؛ مغز مداد از آن ساخته می‌شود.", "فولرن: اتم‌های کربن روی سطح یک گوی توخالی قرار می‌گیرند (در این‌جا یک مدل ساده‌شده با ۳۲ اتم). در پژوهش‌های علمی کاربرد دارد.", "نانولوله: اتم‌های کربن در حلقه‌های شش‌ضلعی پشت سر هم قرار گرفته‌اند و یک لولهٔ بسیار محکم و سبک می‌سازند."]};
var FAD = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
function toFa(n) { return String(n).replace(/\d/g, function (c) { return FAD[+c]; }); }
function fmt(v, d) { return toFa(Number(v).toFixed(d)).replace('.', '٫'); }
function parseNum(s) {
  s = String(s).replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 1776); })
    .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); })
    .replace(/[٫،,]/g, '.').replace(/[−–]/g, '-');
  var v = parseFloat(s);
  return isNaN(v) ? null : v;
}
function shuffle(a) {
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}
function faText(s) { return String(s).replace(/\b\d+(?:\.\d+)?\b/g, function (m) { return toFa(m).replace('.', '٫'); }); }
function rnd(n) { return Math.floor(Math.random() * n); }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}
function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); }
function btn(text, cls, fn) {
  var b = el('button', 'btn-sm' + (cls ? ' ' + cls : ''), text);
  b.type = 'button';
  if (fn) b.addEventListener('click', fn);
  return b;
}
function css(c) { return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; }
function subHtml(f) { return f.replace(/(\d+)/g, function (m) { return '<sub>' + toFa(m) + '</sub>'; }); }
var dead = false, timeouts = [], docHandlers = [];
function later(fn, ms) { var t = setTimeout(fn, ms); timeouts.push(t); return t; }
function onDoc(type, fn, opts) { document.addEventListener(type, fn, opts); docHandlers.push([type, fn, opts]); }
function loop(fn) {
  var last = 0;
  function tick(t) {
    if (dead) return;
    var dt = last ? Math.min(0.05, (t - last) / 1000) : 0.016;
    last = t;
    try { fn(dt, t); } catch (e) { console.error(e); }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}
function visible(n) { return !!(n && n.offsetParent !== null); }
function showError(root, e) {
  var d = el('div', 'err-box', 'خطا: ' + (e && e.message ? e.message : e));
  root.insertBefore(d, root.firstChild);
}
function confettiBurst() {
  var colors = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
  for (var i = 0; i < 80; i++) {
    var p = document.createElement('div');
    p.className = 'confetti-piece';
    p.style.left = (30 + Math.random() * 40) + '%';
    p.style.background = colors[Math.floor(Math.random() * colors.length)];
    p.style.animationDelay = (Math.random() * 0.3) + 's';
    document.body.appendChild(p);
    setTimeout(function (node) { return function () { if (node.parentNode) node.parentNode.removeChild(node); }; }(p), 3500);
  }
}
function secOf(root, type, renderer) {
  var ss = root.querySelectorAll('section');
  for (var i = 0; i < ss.length; i++) {
    if (ss[i].getAttribute('data-type') === type && (!renderer || ss[i].getAttribute('data-renderer') === renderer)) return ss[i];
  }
  return null;
}
function buildHome(root, cards) {
  var g = root.querySelector('#home-grid');
  if (!g) throw new Error('home-grid not found');
  clear(g);
  cards.forEach(function (c) {
    var b = el('button', 'home-card');
    b.type = 'button';
    b.appendChild(el('span', 'icon', c.icon));
    b.appendChild(document.createTextNode(c.label));
    b.addEventListener('click', function () {
      var t = secOf(root, c.type, c.renderer);
      if (t) window.__openSection(t);
    });
    g.appendChild(b);
  });
}
function hit(node, x, y) {
  var r = node.getBoundingClientRect();
  return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
}
function ptOf(e) {
  var t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
  return { x: t.clientX, y: t.clientY };
}
// drag with transform (mouse + touch). hooks.end(x, y) returns true when the node was placed somewhere else
function makeDrag(node, h) {
  var sx = 0, sy = 0, active = false;
  function down(e) {
    if (h.canStart && !h.canStart()) return;
    var p = ptOf(e);
    active = true; sx = p.x; sy = p.y;
    node.style.transition = 'none'; node.style.zIndex = '50';
    node.classList.add('dragging');
    if (h.start) h.start(p.x, p.y);
    if (e.cancelable) e.preventDefault();
  }
  function move(e) {
    if (!active) return;
    var p = ptOf(e);
    node.style.transform = 'translate(' + (p.x - sx) + 'px,' + (p.y - sy) + 'px)';
    if (h.move) h.move(p.x, p.y);
    if (e.cancelable) e.preventDefault();
  }
  function up(e) {
    if (!active) return;
    active = false;
    var p = ptOf(e);
    node.classList.remove('dragging'); node.style.zIndex = '';
    var ok = h.end ? h.end(p.x, p.y) : false;
    if (!ok) { node.style.transition = 'transform .22s ease-out'; node.style.transform = 'translate(0px,0px)'; }
  }
  node.addEventListener('mousedown', down);
  node.addEventListener('touchstart', down, { passive: false });
  onDoc('mousemove', move); onDoc('touchmove', move, { passive: false });
  onDoc('mouseup', up); onDoc('touchend', up); onDoc('touchcancel', up);
}
// free dragging inside a stage (sets left/top)
function dragFree(node, stage, onChange) {
  var active = false, ox = 0, oy = 0;
  function down(e) {
    var p = ptOf(e), r = node.getBoundingClientRect();
    active = true; ox = p.x - (r.left + r.width / 2); oy = p.y - (r.top + r.height / 2);
    node.classList.add('dragging');
    if (e.cancelable) e.preventDefault();
  }
  function move(e) {
    if (!active) return;
    var p = ptOf(e), s = stage.getBoundingClientRect();
    node.style.left = clamp(p.x - ox - s.left, 24, s.width - 24) + 'px';
    node.style.top = clamp(p.y - oy - s.top, 24, s.height - 24) + 'px';
    if (onChange) onChange();
    if (e.cancelable) e.preventDefault();
  }
  function up() { if (active) { active = false; node.classList.remove('dragging'); if (onChange) onChange(); } }
  node.addEventListener('mousedown', down);
  node.addEventListener('touchstart', down, { passive: false });
  onDoc('mousemove', move); onDoc('touchmove', move, { passive: false });
  onDoc('mouseup', up); onDoc('touchend', up); onDoc('touchcancel', up);
}
function resultBox(parent, score, total, restart, title) {
  var box = el('div', 'quiz-final');
  box.appendChild(el('div', 'res-title', title || 'نتیجه'));
  var pct = total ? Math.round(score * 100 / total) : 0;
  box.appendChild(el('div', 'res-pct', toFa(pct) + '٪'));
  var bar = el('div', 'res-bar'), fill = el('div', 'res-fill');
  fill.style.width = pct + '%';
  fill.style.background = pct >= 70 ? '#10B981' : (pct >= 40 ? '#F59E0B' : '#EF4444');
  bar.appendChild(fill); box.appendChild(bar);
  box.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(total)));
  var row = el('div', 'quiz-nav');
  row.appendChild(btn('بازی جدید', 'green', restart));
  box.appendChild(row);
  parent.appendChild(box);
  if (total && score / total >= 0.7) confettiBurst();
  return box;
}
function progressBar(frac) {
  var b = el('div', 'prog'), f = el('div', 'prog-fill');
  f.style.width = Math.round(clamp(frac, 0, 1) * 100) + '%';
  b.appendChild(f);
  return b;
}
// multiple choice engine: questions [{q, o[4], c, e, scen}]
function mcq(host, cfg) {
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var pool, idx, score;
  function start() {
    pool = cfg.shuffleQ ? shuffle(cfg.questions.slice()) : cfg.questions.slice();
    if (cfg.count) pool = pool.slice(0, cfg.count);
    idx = 0; score = 0;
    show();
  }
  function show() {
    clear(wrap);
    if (idx >= pool.length) { resultBox(wrap, score, pool.length, start, cfg.finalTitle); return; }
    var q = pool[idx];
    wrap.appendChild(progressBar(idx / pool.length));
    wrap.appendChild(el('div', 'mc-count', 'سوال ' + toFa(idx + 1) + ' از ' + toFa(pool.length)));
    if (q.scen) wrap.appendChild(el('div', 'scenario-card', faText(q.scen)));
    wrap.appendChild(el('div', 'quiz-question', faText(q.q)));
    var opts = el('div', 'quiz-options');
    var order = shuffle([0, 1, 2, 3]), buttons = [], locked = false;
    var expl = el('div', 'quiz-expl');
    expl.style.display = 'none';
    var nav = el('div', 'quiz-nav');
    order.forEach(function (oi) {
      var b = el('button', 'quiz-opt', faText(q.o[oi]));
      b.type = 'button';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (oi === q.c);
        if (ok) score++;
        buttons.forEach(function (x) { x.btn.disabled = true; if (x.oi === q.c) x.btn.classList.add('correct'); });
        if (!ok) b.classList.add('wrong');
        expl.textContent = (ok ? '✓ ' : '✗ ') + faText(q.e || (ok ? 'درست است!' : 'پاسخ درست با رنگ سبز مشخص شد.'));
        expl.style.display = 'block';
        nav.appendChild(btn(idx === pool.length - 1 ? 'نتیجه' : 'بعدی', '', function () { idx++; show(); }));
      });
      buttons.push({ btn: b, oi: oi });
      opts.appendChild(b);
    });
    wrap.appendChild(opts); wrap.appendChild(expl); wrap.appendChild(nav);
  }
  start();
  return { restart: start };
}
// matching: left[i] <-> right[i]; icons optional (array of css colours)
function matchGame(host, left, right, icons) {
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var done, sel, score, rorder, busy;
  function start() {
    clear(wrap);
    done = []; sel = -1; score = 0; busy = false;
    rorder = shuffle(left.map(function (_, i) { return i; }));
    var count = el('div', 'mc-count', 'امتیاز: ' + toFa(0) + ' از ' + toFa(left.length));
    wrap.appendChild(count);
    var cols = el('div', 'match-cols'), lc = el('div', 'match-col'), rc = el('div', 'match-col');
    var lb = [], rb = [];
    left.forEach(function (t, i) {
      var b = el('button', 'match-item');
      b.type = 'button';
      if (icons) { var d = el('span', 'dot'); d.style.background = icons[i]; b.appendChild(d); }
      b.appendChild(document.createTextNode(t));
      b.addEventListener('click', function () {
        if (busy || done[i]) return;
        sel = (sel === i) ? -1 : i;
        lb.forEach(function (x, k) { x.classList.toggle('sel', k === sel); });
      });
      lb.push(b); lc.appendChild(b);
    });
    rorder.forEach(function (ri) {
      var b = el('button', 'match-item', right[ri]);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (busy || done[ri] || sel < 0) return;
        if (sel === ri) {
          done[ri] = true; score++;
          lb[ri].className = 'match-item ok'; b.className = 'match-item ok';
          sel = -1;
          lb.forEach(function (x) { x.classList.remove('sel'); });
          count.textContent = 'امتیاز: ' + toFa(score) + ' از ' + toFa(left.length);
          if (score === left.length) later(function () { resultBox(wrap, score, left.length, start); }, 500);
        } else {
          busy = true;
          var cur = sel;
          lb[cur].classList.add('bad'); b.classList.add('bad');
          later(function () { lb[cur].classList.remove('bad', 'sel'); b.classList.remove('bad'); sel = -1; busy = false; }, 500);
        }
      });
      rb.push(b); rc.appendChild(b);
    });
    cols.appendChild(lc); cols.appendChild(rc); wrap.appendChild(cols);
  }
  start();
}
// one card + several choice buttons per round: items [{html|text, a, why}]
function choiceGame(host, items, choices, opts) {
  opts = opts || {};
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var pool, idx, score;
  function start() { pool = shuffle(items.slice()); if (opts.count) pool = pool.slice(0, opts.count); idx = 0; score = 0; show(); }
  function show() {
    clear(wrap);
    if (idx >= pool.length) { resultBox(wrap, score, pool.length, start); return; }
    var it = pool[idx];
    wrap.appendChild(progressBar(idx / pool.length));
    wrap.appendChild(el('div', 'mc-count', toFa(idx + 1) + ' از ' + toFa(pool.length)));
    if (opts.prompt) wrap.appendChild(el('div', 'mc-prompt', opts.prompt));
    var card = el('div', 'choice-card');
    if (it.html) card.innerHTML = it.html; else card.textContent = it.text;
    wrap.appendChild(card);
    var row = el('div', 'choice-row'), bs = [], locked = false;
    choices.forEach(function (c, ci) {
      var b = el('button', 'choice-btn', c);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (ci === it.a);
        if (ok) score++;
        bs.forEach(function (x, k) { x.disabled = true; if (k === it.a) x.classList.add('correct'); });
        if (!ok) b.classList.add('wrong');
        fb.textContent = ok ? '✓ درست است' : '✗ پاسخ درست: ' + choices[it.a];
        fb.className = 'choice-fb ' + (ok ? 'ok' : 'bad');
        later(function () { idx++; show(); }, ok ? 900 : 1500);
      });
      bs.push(b); row.appendChild(b);
    });
    wrap.appendChild(row);
    var fb = el('div', 'choice-fb', '');
    wrap.appendChild(fb);
  }
  start();
}

var DK = '#334155';
function svgWrap(w, h, inner, minW) {
  return '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="width:100%;' + (minW ? 'min-width:' + minW + 'px;' : 'max-width:420px;') + '" font-family="Vazirmatn, Tahoma, sans-serif">' + inner + '</svg>';
}
function sT(x, y, text, size, anchor, fill) {
  return '<text x="' + x + '" y="' + y + '" font-size="' + (size || 11) + '" text-anchor="' + (anchor || 'middle') + '" fill="' + (fill || DK) + '">' + text + '</text>';
}
function sR(x, y, w, h, fill, stroke) {
  return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + fill + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="2"' : '') + '/>';
}
function sP(d, color, w) { return '<path d="' + d + '" stroke="' + (color || DK) + '" stroke-width="' + (w || 1) + '" fill="none"/>'; }

var DALTON = 'بر اساس نظریه دالتون، اتم‌های کربن در همه این شکل‌ها یکسان‌اند. هیچ اتمی ساخته یا نابود نمی‌شود؛ فقط آرایش و تعداد پیوندهای آن فرق می‌کند.';
var ATOM_NAMES = ['هیدروژن', 'اکسیژن', 'کربن'];
var ATOM_SYM = ['H', 'O', 'C'];
var ATOM_COL = ['#E2E8F0', '#EF4444', '#374151'];
var ATOM_R = [14, 20, 23];

// ---------- states of matter ----------
function initMatter(sec) {
  var W = 300, H = 240, N = 30;
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var label = el('div', 'tech-name', ''), temp = el('div', 'mc-prompt', '');
  wrap.appendChild(label);
  var box = el('div', 'stage matter-box'), level = el('div', 'matter-level');
  box.appendChild(level);
  wrap.appendChild(box);
  var P = [], t = 10, mode = -1;
  for (var k = 0; k < N; k++) {
    var node = el('div', 'matter-p');
    box.appendChild(node);
    P.push({ n: node, x: 0, y: 0, vx: 0, vy: 0, hx: 40 + (k % 6) * 44, hy: H - 24 - Math.floor(k / 6) * 34 });
    P[k].x = P[k].hx; P[k].y = P[k].hy;
  }
  var row = el('div', 'in-row');
  row.appendChild(el('span', '', 'سرد'));
  var sl = el('input', 'range');
  sl.type = 'range'; sl.min = '0'; sl.max = '100'; sl.value = '10';
  sl.addEventListener('input', function () { t = Number(sl.value); });
  row.appendChild(sl); row.appendChild(el('span', '', 'گرم'));
  wrap.appendChild(row); wrap.appendChild(temp);
  var names = ['جامد', 'مایع', 'گاز'], cols = ['#2563EB', '#06B6D4', '#EF4444'];
  function kick() { P.forEach(function (p) { var a = Math.random() * 6.283; p.vx = Math.cos(a) * 50; p.vy = Math.sin(a) * 50; }); }
  loop(function (dt) {
    if (!visible(box)) return;
    var m = t < 33 ? 0 : (t < 66 ? 1 : 2);
    if (m !== mode) {
      mode = m; kick();
      label.textContent = 'حالت: ' + names[m]; label.style.color = cols[m];
      level.style.height = (m === 1 ? '58%' : '0%');
      P.forEach(function (p) { p.n.style.background = cols[m]; });
    }
    temp.textContent = 'دما: ' + toFa(Math.round(t * 1.2)) + ' °C';
    var sp = m === 1 ? 30 + t * 1.4 : 90 + t * 2.5, top = m === 1 ? H * 0.42 : 0;
    P.forEach(function (p) {
      if (m === 0) {
        var amp = 0.4 + t * 0.05, kk = Math.min(1, dt * 6);
        p.x += (p.hx - p.x) * kk + (Math.random() - 0.5) * amp * 2;
        p.y += (p.hy - p.y) * kk + (Math.random() - 0.5) * amp * 2;
      } else {
        var len = Math.sqrt(p.vx * p.vx + p.vy * p.vy) || 1;
        p.vx *= sp / len; p.vy *= sp / len;
        p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.x < 10) { p.x = 10; p.vx = Math.abs(p.vx); }
        if (p.x > W - 10) { p.x = W - 10; p.vx = -Math.abs(p.vx); }
        if (p.y < top + 10) { p.y = Math.max(p.y, top + 10); p.vy = Math.abs(p.vy); }
        if (p.y > H - 10) { p.y = H - 10; p.vy = -Math.abs(p.vy); }
      }
      p.n.style.transform = 'translate(' + (p.x - 7).toFixed(1) + 'px,' + (p.y - 7).toFixed(1) + 'px)';
    });
  });
}

// ---------- atom structure (static SVG orbits) ----------
function initAtom(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var sel = 3;
  var chips = el('div', 'chip-row'), chipEls = [];
  D.ael.forEach(function (a, k) {
    var c = el('button', 'chip', a[0] + ' (' + a[1] + ')');
    c.type = 'button';
    c.addEventListener('click', function () { sel = k; draw(); });
    chipEls.push(c); chips.appendChild(c);
  });
  wrap.appendChild(chips);
  var box = el('div', 'svg-box'), info = el('div', 'card-box');
  wrap.appendChild(box); wrap.appendChild(info);
  function draw() {
    chipEls.forEach(function (c, k) { c.className = 'chip' + (k === sel ? ' on' : ''); });
    var a = D.ael[sel], p = a[2], n = a[3], e = a[4], sh = a[5], ns = a[6], s = '', k, j;
    var rad = [40, 68, 96, 124];
    for (k = 0; k < 4; k++) s += '<circle cx="170" cy="170" r="' + rad[k] + '" fill="none" stroke="' + (k < ns ? '#94A3B8' : '#E2E8F0') + '" stroke-width="1.5"/>';
    var total = p + n, R = total <= 1 ? 6 : Math.min(30, 8 + 2.6 * Math.sqrt(total));
    s += '<circle cx="170" cy="170" r="' + (R + 6) + '" fill="#FEF3C7" stroke="#F59E0B" stroke-width="2"/>';
    for (k = 0; k < total; k++) {
      var yy = 1 - 2 * (k + 0.5) / total, rr = Math.sqrt(Math.max(0, 1 - yy * yy)), th = k * 2.39996;
      var isP = Math.floor((k + 1) * p / total) > Math.floor(k * p / total);
      var cx = total === 1 ? 170 : 170 + rr * Math.cos(th) * R * 0.85, cy = total === 1 ? 170 : 170 + yy * R * 0.85;
      s += '<circle cx="' + cx.toFixed(1) + '" cy="' + cy.toFixed(1) + '" r="3.2" fill="' + (isP ? '#DC2626' : '#2563EB') + '"/>';
    }
    for (k = 0; k < ns; k++)
      for (j = 0; j < sh[k]; j++) {
        var ang = j * 2 * Math.PI / sh[k] + k * 0.6;
        s += '<circle cx="' + (170 + rad[k] * Math.cos(ang)).toFixed(1) + '" cy="' + (170 + rad[k] * Math.sin(ang)).toFixed(1) + '" r="5" fill="#1D4ED8" stroke="#1E3A8A" stroke-width="1"/>';
      }
    box.innerHTML = svgWrap(340, 340, s);
    var parts = [];
    for (k = 0; k < ns; k++) parts.push('KLMN'.charAt(k) + ':' + toFa(sh[k]));
    clear(info);
    info.appendChild(el('div', 'tech-name', a[0] + ' (' + a[1] + ')'));
    info.appendChild(el('div', 'mc-prompt', 'پروتون: ' + toFa(p) + '   نوترون: ' + toFa(n) + '   الکترون: ' + toFa(e)));
    info.appendChild(el('div', 'mc-prompt', 'لایه‌ها: ' + parts.join('، ')));
    info.appendChild(el('div', 'mc-prompt', 'کاربرد: ' + a[7]));
    info.appendChild(el('div', 'mc-prompt', 'قرمز: پروتون (+)   آبی تیره: الکترون (−)   آبی: نوترون'));
  }
  draw();
}

// ---------- element or compound: click the card, then the zone ----------
function initElemComp(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var order, idx, score;
  function restart() { order = shuffle(D.subs.map(function (_, k) { return k; })); idx = 0; score = 0; show(); }
  function show() {
    clear(wrap);
    if (idx >= order.length) { resultBox(wrap, score, order.length, restart, 'نتیجه'); return; }
    var s = D.subs[order[idx]];
    wrap.appendChild(progressBar(idx / order.length));
    wrap.appendChild(el('div', 'mc-count', 'ماده ' + toFa(idx + 1) + ' از ' + toFa(order.length) + ' — امتیاز: ' + toFa(score)));
    var card = el('button', 'choice-card sel-card');
    card.type = 'button';
    card.innerHTML = '<div>' + s[0] + '</div><div class="formula">' + subHtml(s[1]) + '</div>';
    wrap.appendChild(card);
    var hint = el('div', 'mc-prompt', 'ابتدا روی کارت ماده کلیک کنید');
    wrap.appendChild(hint);
    var row = el('div', 'choice-row'), selected = false, busy = false, zs = [];
    ['عنصر', 'ترکیب'].forEach(function (name, z) {
      var b = el('button', 'choice-btn zone-btn', name);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (busy) return;
        if (!selected) { hint.textContent = 'ابتدا کارت ماده را انتخاب کنید'; hint.style.color = '#DC2626'; return; }
        busy = true;
        if (z === s[2]) {
          card.className = 'choice-card sel-card ok'; b.classList.add('correct'); score++;
          later(function () { idx++; show(); }, 300);
        } else {
          card.className = 'choice-card sel-card bad'; b.classList.add('wrong');
          hint.textContent = 'اشتباه! ' + s[3]; hint.style.color = '#DC2626';
          later(function () { card.className = 'choice-card sel-card'; b.classList.remove('wrong'); selected = false; busy = false; }, 500);
        }
      });
      zs.push(b); row.appendChild(b);
    });
    card.addEventListener('click', function () {
      if (busy) return;
      selected = !selected;
      card.className = 'choice-card sel-card' + (selected ? ' picked' : '');
      hint.textContent = selected ? 'حالا ناحیه درست را انتخاب کنید' : 'ابتدا روی کارت ماده کلیک کنید';
      hint.style.color = '';
    });
    wrap.appendChild(row);
  }
  restart();
}

// ---------- molecule builder ----------
function initMolBuild(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var MOLS = [[2, 1, 0, 'آب', 'H2O'], [0, 2, 1, 'کربن دی‌اکسید', 'CO2'], [4, 0, 1, 'متان', 'CH4'], [2, 0, 0, 'گاز هیدروژن', 'H2'], [0, 2, 0, 'گاز اکسیژن', 'O2'], [0, 1, 1, 'کربن مونوکسید', 'CO']];
  var found = [false, false, false, false, false, false];
  var atoms = [];
  var bar = el('div', 'chip-row');
  [0, 1, 2].forEach(function (t) {
    var b = el('button', 'chip atom-chip', 'افزودن ' + ATOM_NAMES[t] + ' (' + ATOM_SYM[t] + ')');
    b.type = 'button';
    b.addEventListener('click', function () { add(t); });
    bar.appendChild(b);
  });
  bar.appendChild(btn('پاک کردن', 'red', function () { atoms.forEach(function (a) { if (a.n.parentNode) a.n.parentNode.removeChild(a.n); }); atoms = []; update(); }));
  wrap.appendChild(bar);
  wrap.appendChild(el('div', 'mc-prompt', 'اتم‌ها را بکشید و کنار هم بگذارید'));
  var stage = el('div', 'stage mol-stage'), layer = el('div', 'mol-layer'), labels = el('div', 'mol-layer');
  stage.appendChild(layer); stage.appendChild(labels);
  wrap.appendChild(stage);
  var list = el('div', 'card-box');
  wrap.appendChild(list);
  function pos(a) { return { x: parseFloat(a.n.style.left) || 0, y: parseFloat(a.n.style.top) || 0 }; }
  function add(t) {
    if (atoms.length >= 12) return;
    var n = el('div', 'mol-atom', ATOM_SYM[t]);
    n.style.background = ATOM_COL[t]; n.style.color = t === 0 ? '#1E293B' : '#fff';
    n.style.width = n.style.height = (ATOM_R[t] * 2) + 'px'; n.style.lineHeight = (ATOM_R[t] * 2) + 'px';
    n.style.left = (60 + rnd(180)) + 'px'; n.style.top = (50 + rnd(150)) + 'px';
    stage.appendChild(n);
    var a = { n: n, t: t };
    atoms.push(a);
    dragFree(n, stage, update);
    update();
  }
  function update() {
    clear(layer); clear(labels);
    var comp = atoms.map(function () { return -1; }), nc = 0, i, j;
    for (i = 0; i < atoms.length; i++) {
      if (comp[i] >= 0) continue;
      comp[i] = nc;
      var stack = [i];
      while (stack.length) {
        var a = stack.pop(), pa = pos(atoms[a]);
        for (j = 0; j < atoms.length; j++) {
          if (comp[j] >= 0) continue;
          var pb = pos(atoms[j]);
          if (Math.sqrt((pa.x - pb.x) * (pa.x - pb.x) + (pa.y - pb.y) * (pa.y - pb.y)) < 60) { comp[j] = nc; stack.push(j); }
        }
      }
      nc++;
    }
    var svg = '';
    for (i = 0; i < atoms.length; i++)
      for (j = i + 1; j < atoms.length; j++) {
        var p1 = pos(atoms[i]), p2 = pos(atoms[j]);
        if (Math.sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y)) < 60)
          svg += '<line x1="' + p1.x + '" y1="' + p1.y + '" x2="' + p2.x + '" y2="' + p2.y + '" stroke="#64748B" stroke-width="5"/>';
      }
    layer.innerHTML = '<svg width="100%" height="100%" style="position:absolute;left:0;top:0">' + svg + '</svg>';
    for (var k = 0; k < nc; k++) {
      var c = [0, 0, 0], sx = 0, sy = 0, cnt = 0;
      for (i = 0; i < atoms.length; i++) if (comp[i] === k) { c[atoms[i].t]++; var q = pos(atoms[i]); sx += q.x; sy += q.y; cnt++; }
      for (var m = 0; m < MOLS.length; m++) {
        if (MOLS[m][0] === c[0] && MOLS[m][1] === c[1] && MOLS[m][2] === c[2]) {
          found[m] = true;
          var lb = el('div', 'mol-label');
          lb.innerHTML = MOLS[m][3] + '<div class="formula">' + subHtml(MOLS[m][4]) + '</div>';
          lb.style.left = (sx / cnt) + 'px'; lb.style.top = Math.max(4, sy / cnt - 70) + 'px';
          labels.appendChild(lb);
        }
      }
    }
    clear(list);
    var fc = 0;
    MOLS.forEach(function (m, x) { if (found[x]) fc++; list.appendChild(el('div', 'mol-row' + (found[x] ? ' ok' : ''), (found[x] ? '✓ ' : '؟ ') + (found[x] ? m[3] : '???'))); });
    list.appendChild(el('div', 'mc-count', 'کشف‌شده: ' + toFa(fc) + ' از ' + toFa(MOLS.length)));
  }
  update();
}

// ---------- carbon forms ----------
function carbonShape(idx) {
  var A = [], B = [], i, j, k;
  if (idx === 0) {
    A = [[0, 0, 0], [1, 1, 1], [1, -1, -1], [-1, 1, -1], [-1, -1, 1]];
    for (i = 1; i < 5; i++) B.push([0, i, 0]);
  } else if (idx === 1) {
    for (i = 0; i < 2; i++) for (j = 0; j < 6; j++) { var a = (j * 60 + i * 30) * Math.PI / 180; A.push([Math.cos(a), Math.sin(a), i ? 0.4 : -0.4]); }
    for (i = 0; i < 2; i++) for (j = 0; j < 6; j++) B.push([i * 6 + j, i * 6 + (j + 1) % 6, 0]);
    for (j = 0; j < 6; j++) B.push([j, 6 + j, 1]);
  } else if (idx === 2) {
    for (i = 0; i < 32; i++) { var y = 1 - 2 * (i + 0.5) / 32, r = Math.sqrt(1 - y * y), th = i * 2.39996; A.push([r * Math.cos(th), y, r * Math.sin(th)]); }
    var seen = {};
    for (i = 0; i < 32; i++) {
      var ds = [];
      for (j = 0; j < 32; j++) if (j !== i) ds.push([Math.pow(A[i][0] - A[j][0], 2) + Math.pow(A[i][1] - A[j][1], 2) + Math.pow(A[i][2] - A[j][2], 2), j]);
      ds.sort(function (p, q) { return p[0] - q[0]; });
      for (k = 0; k < 3; k++) { var lo = Math.min(i, ds[k][1]), hi = Math.max(i, ds[k][1]); if (!seen[lo + '_' + hi]) { seen[lo + '_' + hi] = 1; B.push([lo, hi, 0]); } }
    }
  } else {
    for (i = 0; i < 4; i++) for (j = 0; j < 6; j++) { var b = (j * 60 + (i % 2) * 30) * Math.PI / 180; A.push([0.9 * Math.cos(b), 0.9 * Math.sin(b), (i - 1.5) * 0.8]); }
    for (i = 0; i < 4; i++) for (j = 0; j < 6; j++) B.push([i * 6 + j, i * 6 + (j + 1) % 6, 0]);
    for (i = 0; i < 3; i++) for (j = 0; j < 6; j++) B.push([i * 6 + j, (i + 1) * 6 + j, 0]);
  }
  return { A: A, B: B };
}
function carbonSvg(idx, size) {
  var sh = carbonShape(idx), ang = 0.6, tilt = 0.35, sc = [34, 36, 38, 32][idx] * size / 200, c = Math.cos(ang), s = Math.sin(ang), ct = Math.cos(tilt), st = Math.sin(tilt);
  var P = sh.A.map(function (a) {
    var x = a[0] * c - a[2] * s, z = a[0] * s + a[2] * c, y = a[1] * ct - z * st, z2 = a[1] * st + z * ct;
    return { x: size / 2 + x * sc * 2.2, y: size / 2 + y * sc * 2.2, z: z2 };
  });
  var out = '';
  sh.B.forEach(function (b) {
    var a1 = idx === 0 ? P[0] : P[b[0]], a2 = idx === 0 ? P[b[1]] : P[b[1]];
    out += '<line x1="' + a1.x.toFixed(1) + '" y1="' + a1.y.toFixed(1) + '" x2="' + a2.x.toFixed(1) + '" y2="' + a2.y.toFixed(1) + '" stroke="#8291AF" stroke-width="3"' + (idx === 1 && b[2] === 1 ? ' stroke-dasharray="4 4"' : '') + '/>';
  });
  var ord = P.map(function (p, i) { return i; }).sort(function (u, v) { return P[u].z - P[v].z; });
  ord.forEach(function (i) {
    var r = [11, 9, 6, 8][idx] * size / 200 * (1 + P[i].z * 0.25);
    out += '<circle cx="' + P[i].x.toFixed(1) + '" cy="' + P[i].y.toFixed(1) + '" r="' + r.toFixed(1) + '" fill="#374151" stroke="#1F2937" stroke-width="1"/><circle cx="' + (P[i].x - r * 0.3).toFixed(1) + '" cy="' + (P[i].y - r * 0.3).toFixed(1) + '" r="' + (r * 0.35).toFixed(1) + '" fill="#A0B4D2"/>';
  });
  return svgWrap(size, size, out);
}
function initCarbon(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  wrap.appendChild(el('div', 'mc-prompt', 'روی هر کارت کلیک کنید'));
  var grid = el('div', 'carbon-grid');
  D.cName.forEach(function (name, i) {
    var card = el('button', 'carbon-card');
    card.type = 'button';
    card.appendChild(el('div', 'tech-name', name));
    var sv = el('div', 'svg-box'); sv.innerHTML = carbonSvg(i, 200); card.appendChild(sv);
    card.appendChild(el('div', 'mc-prompt', D.cBrief[i]));
    card.addEventListener('click', function () {
      var back = el('div', 'modal-back'), m = el('div', 'modal-card');
      m.appendChild(el('div', 'tech-name', name));
      var big = el('div', 'svg-box'); big.innerHTML = carbonSvg(i, 320); m.appendChild(big);
      m.appendChild(el('div', 'mc-prompt', D.cDetail[i]));
      m.appendChild(el('div', 'scenario-card', DALTON));
      m.appendChild(el('div', 'mc-count', 'برای بستن کلیک کنید'));
      back.appendChild(m);
      back.addEventListener('click', function () { if (back.parentNode) back.parentNode.removeChild(back); });
      document.body.appendChild(back);
    });
    grid.appendChild(card);
  });
  wrap.appendChild(grid);
  wrap.appendChild(el('div', 'scenario-card', DALTON));
}

// ---------- evidence: ink spreading, then questions ----------
function initEvidence(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var status = el('div', 'mc-prompt', 'یک قطره جوهر در آب ریخته شد؛ نگاه کنید ...');
  wrap.appendChild(status);
  var box = el('div', 'stage ink-box');
  wrap.appendChild(box);
  var host = el('div', '');
  wrap.appendChild(host);
  var W = 300, H = 200, P = [], tm = 0, shown = false;
  for (var k = 0; k < 80; k++) {
    var n = el('div', 'ink-p');
    box.appendChild(n);
    P.push({ n: n, x: W / 2 + rnd(21) - 10, y: 24 + rnd(21) - 10 });
  }
  loop(function (dt) {
    if (!visible(box)) return;
    tm += dt;
    P.forEach(function (p) {
      p.x = clamp(p.x + (Math.random() - 0.5) * 3, 8, W - 8);
      p.y = clamp(p.y + (Math.random() - 0.5) * 3 + 0.15, 8, H - 8);
      p.n.style.transform = 'translate(' + (p.x - 12).toFixed(1) + 'px,' + (p.y - 12).toFixed(1) + 'px)';
    });
    if (tm >= 7 && !shown) {
      shown = true;
      status.textContent = 'حالا به پرسش‌ها پاسخ دهید';
      mcq(host, { questions: D.m8Qs.map(function (x) { return { q: x[0], o: x[1], c: x[2], e: x[3] }; }), finalTitle: 'نتیجه شواهد غیرمستقیم' });
    }
  });
}

// ---------- count atoms ----------
function initCount(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var order, idx, score;
  function restart() { order = shuffle(D.md.map(function (_, k) { return k; })); idx = 0; score = 0; show(); }
  function counts(d) { var c = [0, 0, 0]; d[2].forEach(function (t) { c[t]++; }); return c; }
  function molSvg(d) {
    var s = '', i, j;
    for (i = 0; i < d[1]; i++) for (j = i + 1; j < d[1]; j++) {
      var dx = d[3][i] - d[3][j], dy = d[4][i] - d[4][j];
      if (dx * dx + dy * dy < 75 * 75 && !(d[2][i] === 0 && d[2][j] === 0)) s += '<line x1="' + (150 + d[3][i]) + '" y1="' + (100 + d[4][i]) + '" x2="' + (150 + d[3][j]) + '" y2="' + (100 + d[4][j]) + '" stroke="#64748B" stroke-width="5"/>';
    }
    for (i = 0; i < d[1]; i++) s += '<circle cx="' + (150 + d[3][i]) + '" cy="' + (100 + d[4][i]) + '" r="' + ATOM_R[d[2][i]] + '" fill="' + ATOM_COL[d[2][i]] + '" stroke="#475569" stroke-width="2"/>';
    return svgWrap(300, 200, s);
  }
  function show() {
    clear(wrap);
    if (idx >= order.length) { resultBox(wrap, score, order.length, restart, 'نتیجه شمارش اتم‌ها'); return; }
    var d = D.md[order[idx]], c = counts(d);
    var ts = [];
    [2, 1, 0].forEach(function (t) { if (c[t] > 0 && ts.length < 2) ts.push(t); });
    if (ts.length < 2) ts.push(ts[0]);
    wrap.appendChild(progressBar(idx / order.length));
    wrap.appendChild(el('div', 'mc-count', 'سوال ' + toFa(idx + 1) + ' از ' + toFa(order.length)));
    var f = el('div', 'formula center'); f.innerHTML = subHtml(d[0]); wrap.appendChild(f);
    var box = el('div', 'svg-box'); box.innerHTML = molSvg(d); wrap.appendChild(box);
    wrap.appendChild(el('div', 'mc-prompt', 'این مولکول از چند اتم ' + ATOM_NAMES[ts[0]] + ' و چند اتم ' + ATOM_NAMES[ts[1]] + ' تشکیل شده است؟'));
    var ins = [];
    ts.forEach(function (t) {
      var row = el('div', 'in-row');
      row.appendChild(el('span', '', 'تعداد اتم ' + ATOM_NAMES[t] + ':'));
      var inp = el('input', 'num-in');
      inp.type = 'text'; inp.setAttribute('inputmode', 'numeric');
      row.appendChild(inp); wrap.appendChild(row); ins.push(inp);
    });
    var fb = el('div', 'fb-line', ''), nav = el('div', 'quiz-nav'), done = false;
    var chk = btn('بررسی', 'green', function () {
      if (done) return;
      var a = parseNum(ins[0].value), b = parseNum(ins[1].value);
      if (a === null || b === null) { fb.textContent = 'هر دو عدد را وارد کنید'; fb.className = 'fb-line bad'; return; }
      done = true;
      var ok = (a === c[ts[0]]) && (b === c[ts[1]]);
      if (ok) score++;
      fb.textContent = ok ? '✓ آفرین!' : '✗ پاسخ درست: ' + toFa(c[ts[0]]) + ' و ' + toFa(c[ts[1]]);
      fb.className = 'fb-line ' + (ok ? 'ok' : 'bad');
      nav.appendChild(btn(idx === order.length - 1 ? 'نتیجه' : 'بعدی', '', function () { idx++; show(); }));
    });
    nav.appendChild(chk);
    wrap.appendChild(fb); wrap.appendChild(nav);
  }
  restart();
}

// ---------- element file ----------
function initElement(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var cats = ['فلز', 'نافلز', 'گاز نجیب'], colors = ['#FDE0C0', '#CDEFD7', '#E5D9F7'];
  var grid = el('div', 'el-grid'), tiles = [], panel = el('div', 'card-box', '');
  panel.appendChild(el('div', 'mc-prompt', 'یک عنصر را انتخاب کنید'));
  D.elems.forEach(function (e, k) {
    var t = el('button', 'el-tile');
    t.type = 'button';
    t.style.background = colors[e[3]];
    t.appendChild(el('div', 'el-sym', e[0]));
    t.appendChild(el('div', 'el-num', toFa(e[2])));
    t.addEventListener('click', function () {
      tiles.forEach(function (x, i) { x.classList.toggle('on', i === k); });
      clear(panel);
      panel.appendChild(el('div', 'tech-name', e[0] + ' — ' + e[1]));
      panel.appendChild(el('div', 'mc-prompt', 'نماد: ' + e[0]));
      panel.appendChild(el('div', 'mc-prompt', 'عدد اتمی: ' + toFa(e[2])));
      panel.appendChild(el('div', 'mc-prompt', 'دسته: ' + cats[e[3]]));
      panel.appendChild(el('div', 'mc-prompt', 'کاربرد: ' + e[4]));
    });
    tiles.push(t); grid.appendChild(t);
  });
  wrap.appendChild(grid); wrap.appendChild(panel);
}

function safe(root, fn, section) {
  try { if (section) fn(section); } catch (e) { showError(root, e); }
}
window.chapterInit = function (root) {
  dead = false;
  try {
    buildHome(root, [
      { icon: '💧', label: 'ماده و ذره‌ها', type: 'matter' },
      { icon: '⚛️', label: 'ساختار اتم', type: 'atom' },
      { icon: '🧪', label: 'عنصر یا ترکیب', type: 'elemcomp' },
      { icon: '🔗', label: 'مولکول‌ساز', type: 'molbuild' },
      { icon: '🔩', label: 'فلز یا نافلز', type: 'metal' },
      { icon: '💎', label: 'شکل‌های کربن', type: 'carbon' },
      { icon: '🎯', label: 'تطبیق ماده و کاربرد', type: 'match' },
      { icon: '💨', label: 'شواهد غیرمستقیم', type: 'evidence' },
      { icon: '🔢', label: 'شمارش اتم‌ها', type: 'count' },
      { icon: '📋', label: 'پرونده عنصرها', type: 'element' },
      { icon: '🏆', label: 'چالش نهایی', type: 'challenge' }
    ]);
  } catch (e) { showError(root, e); return; }
  safe(root, initMatter, secOf(root, 'matter'));
  safe(root, initAtom, secOf(root, 'atom'));
  safe(root, initElemComp, secOf(root, 'elemcomp'));
  safe(root, initMolBuild, secOf(root, 'molbuild'));
  safe(root, function (s) {
    choiceGame(s, D.props.map(function (p) { return { text: p[0], a: p[1] ? 0 : 1 }; }), ['فلز', 'نافلز'], { prompt: 'این ویژگی مربوط به کدام گروه است؟' });
  }, secOf(root, 'metal'));
  safe(root, initCarbon, secOf(root, 'carbon'));
  safe(root, function (s) {
    matchGame(s, D.mtName, D.mtUse, ['#8C96A5', '#D28250', '#E6BE3C', '#F0AABE', '#5ABE64', '#DC3C3C', '#374151', '#4664DC']);
  }, secOf(root, 'match'));
  safe(root, initEvidence, secOf(root, 'evidence'));
  safe(root, initCount, secOf(root, 'count'));
  safe(root, initElement, secOf(root, 'element'));
  safe(root, function (s) {
    mcq(s, { questions: D.bank.map(function (x) { return { q: x[0], o: x[1], c: x[2], e: x[3] }; }), count: 20, shuffleQ: true, finalTitle: 'نتیجه چالش' });
  }, secOf(root, 'challenge'));
};
window.chapterTeardown = function () {
  dead = true;
  timeouts.forEach(function (t) { clearTimeout(t); }); timeouts = [];
  docHandlers.forEach(function (h) { document.removeEventListener(h[0], h[1], h[2]); }); docHandlers = [];
};

})();
