﻿(function () {
  'use strict';

  window.chapterInit = function (root) {
    initHome(root);
    initM1(root);
    initM2(root);
    initM3(root);
    initM4(root);
    initM5(root);
    initM6(root);
    initM7(root);
    initM8(root);
    initM9(root);
    initM10(root);
    initM11(root);
  };

  function toFa(n) {
    var fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return String(n).split('').map(function (c) {
      return /\d/.test(c) ? fa[parseInt(c, 10)] : c;
    }).join('');
  }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
  function confettiBurst() {
    var colors = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
    for (var i = 0; i < 80; i++) {
      var p = document.createElement('div');
      p.className = 'confetti-piece';
      p.style.left = (30 + Math.random() * 40) + '%';
      p.style.background = colors[Math.floor(Math.random() * colors.length)];
      p.style.animationDelay = (Math.random() * 0.3) + 's';
      p.style.animationDuration = (1.8 + Math.random() * 1.2) + 's';
      document.body.appendChild(p);
      (function (node) { setTimeout(function () { node.remove(); }, 3500); })(p);
    }
  }

  // ============================================================
  // HOME
  // ============================================================
  function initHome(root) {
    var grid = root.querySelector('#home-grid');
    if (!grid) return;
    var items = [
      { label: 'ماده و ذره‌ها', icon: '💧', type: 'matter' },
      { label: 'ساختار اتم', icon: '⚛️', type: 'atom' },
      { label: 'عنصر یا ترکیب', icon: '🧪', type: 'elemcomp' },
      { label: 'مولکول‌ساز', icon: '🔗', type: 'molbuild' },
      { label: 'فلز یا نافلز', icon: '🔩', type: 'metal' },
      { label: 'شکل‌های کربن', icon: '💎', type: 'carbon' },
      { label: 'تطبیق ماده و کاربرد', icon: '🎯', type: 'match' },
      { label: 'شواهد غیرمستقیم', icon: '💨', type: 'evidence' },
      { label: 'شمارش اتم‌ها', icon: '🔢', type: 'count' },
      { label: 'پرونده عنصرها', icon: '📋', type: 'element' },
      { label: 'چالش نهایی', icon: '🏆', type: 'challenge' }
    ];
    items.forEach(function (it) {
      var b = el('button', 'home-card');
      b.appendChild(el('span', 'icon', it.icon));
      b.appendChild(document.createTextNode(it.label));
      b.onclick = function () {
        var secs = root.querySelectorAll('section');
        for (var i = 0; i < secs.length; i++) {
          if (secs[i].getAttribute('data-type') === it.type) {
            if (window.__openSection) window.__openSection(secs[i]);
            return;
          }
        }
      };
      grid.appendChild(b);
    });
  }

  // ============================================================
  // M1 — MATTER & PARTICLES
  // ============================================================
  function initM1(root) {
    var sec = root.querySelector('section[data-renderer="m1"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m1-wrap');
    if (!wrap) return;
    wrap.innerHTML = '';
    var stage = el('div', 'm1-stage');
    var liquid = el('div', 'm1-liquid');
    stage.appendChild(liquid);
    wrap.appendChild(stage);

    var label = el('div', 'm1-label');
    wrap.appendChild(label);

    var row = el('div', 'm1-slider-row');
    var slider = document.createElement('input');
    slider.type = 'range';
    slider.min = '0';
    slider.max = '100';
    slider.value = '10';
    slider.className = 'm1-slider';
    row.appendChild(slider);
    wrap.appendChild(row);

    var tempLabel = el('div', 'm1-temp-label');
    wrap.appendChild(tempLabel);

    var particles = [];
    for (var i = 0; i < 30; i++) {
      var p = el('div', 'm1-particle');
      p.style.left = (100 + (i % 10) * 25) + 'px';
      p.style.top = (200 - Math.floor(i / 10) * 40) + 'px';
      p._hx = 100 + (i % 10) * 25;
      p._hy = 200 - Math.floor(i / 10) * 40;
      p._vx = (Math.random() - 0.5) * 2;
      p._vy = (Math.random() - 0.5) * 2;
      p._x = p._hx;
      p._y = p._hy;
      stage.appendChild(p);
      particles.push(p);
    }

    var temp = 10;
    var animId = null;
    function update() {
      var mode = temp < 33 ? 0 : (temp < 66 ? 1 : 2);
      label.textContent = 'حالت: ' + (mode === 0 ? 'جامد' : mode === 1 ? 'مایع' : 'گاز');
      tempLabel.textContent = 'دما: ' + toFa(Math.round(temp * 1.2)) + ' °C';
      liquid.style.display = mode === 1 ? 'block' : 'none';

      var stageRect = stage.getBoundingClientRect();
      var W = stageRect.width, H = stageRect.height;
      var speed = mode === 1 ? (35 + temp * 1.6) * 0.03 : (mode === 2 ? (110 + temp * 3) * 0.03 : 0);
      var top = mode === 1 ? H * 0.42 : (mode === 2 ? 10 : H * 0.5);

      particles.forEach(function (p) {
        if (mode === 0) {
          p._x += (p._hx - p._x) * 0.08 + (Math.random() - 0.5) * (0.4 + temp * 0.06);
          p._y += (p._hy - p._y) * 0.08 + (Math.random() - 0.5) * (0.4 + temp * 0.06);
          p.classList.remove('gas', 'liquid');
        } else {
          p.classList.toggle('gas', mode === 2);
          p.classList.toggle('liquid', mode === 1);
          p._vx += (Math.random() - 0.5) * 0.5;
          p._vy += (Math.random() - 0.5) * 0.5;
          var len = Math.sqrt(p._vx * p._vx + p._vy * p._vy) || 1;
          p._vx = (p._vx / len) * speed;
          p._vy = (p._vy / len) * speed;
          p._x += p._vx;
          p._y += p._vy;
          if (p._x < 10) { p._x = 10; p._vx = Math.abs(p._vx); }
          if (p._x > W - 30) { p._x = W - 30; p._vx = -Math.abs(p._vx); }
          if (p._y < top) { p._y = top; p._vy = Math.abs(p._vy); }
          if (p._y > H - 30) { p._y = H - 30; p._vy = -Math.abs(p._vy); }
        }
        p.style.left = p._x + 'px';
        p.style.top = p._y + 'px';
      });
      animId = requestAnimationFrame(update);
    }
    slider.oninput = function () { temp = parseFloat(slider.value); };
    update();
  }

  // ============================================================
  // M2 — ATOM STRUCTURE (2D)
  // ============================================================
  var ATOMS = [
    { name: 'هیدروژن', sym: 'H', p: 1, n: 0, e: 1, shells: [1], use: 'سبک‌ترین عنصر، سوخت موشک' },
    { name: 'هلیوم', sym: 'He', p: 2, n: 2, e: 2, shells: [2], use: 'گاز بالن و بادکنک' },
    { name: 'لیتیوم', sym: 'Li', p: 3, n: 4, e: 3, shells: [2, 1], use: 'باتری‌های قابل شارژ' },
    { name: 'کربن', sym: 'C', p: 6, n: 6, e: 6, shells: [2, 4], use: 'پایه تمام موجودات زنده' },
    { name: 'اکسیژن', sym: 'O', p: 8, n: 8, e: 8, shells: [2, 6], use: 'ضروری برای تنفس' },
    { name: 'سدیم', sym: 'Na', p: 11, n: 12, e: 11, shells: [2, 8, 1], use: 'نمک خوراکی (NaCl)' },
    { name: 'آلومینیوم', sym: 'Al', p: 13, n: 14, e: 13, shells: [2, 8, 3], use: 'قوطی نوشابه و فویل' },
    { name: 'آهن', sym: 'Fe', p: 26, n: 30, e: 26, shells: [2, 8, 14, 2], use: 'ساخت و ساز و ابزار' }
  ];
  var atomSel = 3;

  function initM2(root) {
    var sec = root.querySelector('section[data-renderer="m2"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m2-wrap');
    if (!wrap) return;

    function render() {
      wrap.innerHTML = '';
      var grid = el('div', 'm2-selectors');
      ATOMS.forEach(function (a, i) {
        var b = el('button', 'm2-sel' + (i === atomSel ? ' active' : ''), a.name + ' (' + a.sym + ')');
        b.onclick = function () { atomSel = i; render(); };
        grid.appendChild(b);
      });
      wrap.appendChild(grid);

      var a = ATOMS[atomSel];
      var stage = el('div', 'm2-stage');
      var cx = 160, cy = 160;
      var svg = '<svg viewBox="0 0 320 320" width="100%" style="max-width:320px">';
      svg += '<circle cx="' + cx + '" cy="' + cy + '" r="80" fill="rgba(250,215,60,0.2)"/>';
      svg += '<circle cx="' + cx + '" cy="' + cy + '" r="60" fill="rgba(250,215,60,0.4)"/>';
      var Rn = Math.min(45, 8 + a.p * 1.2);
      svg += '<circle cx="' + cx + '" cy="' + cy + '" r="' + Rn + '" fill="#E64C3C" opacity="0.9"/>';
      var total = a.p + a.n;
      for (var i = 0; i < total && i < 30; i++) {
        var ang = (i / total) * Math.PI * 2;
        var rr = 8 + Math.random() * (Rn - 10);
        var px = cx + Math.cos(ang) * rr;
        var py = cy + Math.sin(ang) * rr;
        var isP = i < a.p;
        svg += '<circle cx="' + px + '" cy="' + py + '" r="3.5" fill="' + (isP ? '#E64C3C' : '#3C78E6') + '"/>';
      }
      var radii = [90, 120, 145, 165];
      a.shells.forEach(function (cnt, s) {
        var r = radii[s];
        svg += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="none" stroke="rgba(100,120,170,0.4)" stroke-width="1"/>';
        for (var j = 0; j < cnt; j++) {
          var ea = (j / cnt) * Math.PI * 2 - Math.PI / 2;
          var ex = cx + Math.cos(ea) * r;
          var ey = cy + Math.sin(ea) * r;
          svg += '<circle cx="' + ex + '" cy="' + ey + '" r="5" fill="#2563EB" stroke="#fff" stroke-width="1"/>';
        }
      });
      svg += '</svg>';
      stage.innerHTML = svg;
      wrap.appendChild(stage);

      var info = el('div', 'm2-info');
      var shellsText = a.shells.map(function (c, i) { return 'KLMN'[i] + ':' + c; }).join(', ');
      info.innerHTML =
        '<h3 style="font-size:18px;font-weight:600;color:#28A096;margin-bottom:8px">' + a.name + ' (' + a.sym + ')</h3>' +
        '<div><strong>پروتون:</strong> ' + toFa(a.p) + ' &nbsp; <strong>نوترون:</strong> ' + toFa(a.n) + ' &nbsp; <strong>الکترون:</strong> ' + toFa(a.e) + '</div>' +
        '<div style="margin-top:6px"><strong>لایه‌ها:</strong> ' + shellsText + '</div>' +
        '<div style="margin-top:6px;color:#2563EB"><strong>کاربرد:</strong> ' + a.use + '</div>';
      wrap.appendChild(info);
    }
    render();
  }

  // ============================================================
  // M3 — ELEMENT OR COMPOUND
  // ============================================================
  var M3_SUBS = [
    { name: 'آب', f: 'H₂O', comp: true, why: 'آب از دو عنصر هیدروژن و اکسیژن ساخته شده است.' },
    { name: 'اکسیژن', f: 'O₂', comp: false, why: 'فقط یک نوع اتم (اکسیژن) دارد.' },
    { name: 'آهن', f: 'Fe', comp: false, why: 'آهن فقط از اتم‌های آهن ساخته شده است.' },
    { name: 'نمک خوراکی', f: 'NaCl', comp: true, why: 'از دو عنصر سدیم و کلر ساخته شده است.' },
    { name: 'کربن دی‌اکسید', f: 'CO₂', comp: true, why: 'از دو عنصر کربن و اکسیژن ساخته شده است.' },
    { name: 'طلا', f: 'Au', comp: false, why: 'طلا یک عنصر است و فقط اتم طلا دارد.' },
    { name: 'هیدروژن', f: 'H₂', comp: false, why: 'فقط اتم‌های هیدروژن دارد.' },
    { name: 'آمونیاک', f: 'NH₃', comp: true, why: 'از دو عنصر نیتروژن و هیدروژن ساخته شده است.' },
    { name: 'مس', f: 'Cu', comp: false, why: 'مس یک عنصر است.' },
    { name: 'متان', f: 'CH₄', comp: true, why: 'از دو عنصر کربن و هیدروژن ساخته شده است.' }
  ];

  function initM3(root) {
    var sec = root.querySelector('section[data-renderer="m3"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m3-wrap');
    if (!wrap) return;
    var order = shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    var cur = 0, score = 0, selected = false, phase = 0, done = false;

    function render() {
      if (done) {
        wrap.innerHTML = '';
        var f = el('div', 'quiz-final');
        f.appendChild(el('h3', null, 'نتیجه'));
        f.appendChild(el('div', 'score-line', toFa(score) + ' از ۱۰'));
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () {
          order = shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
          cur = 0; score = 0; phase = 0; selected = false; done = false;
          render();
        };
        f.appendChild(again);
        wrap.appendChild(f);
        if (score >= 8) confettiBurst();
        return;
      }
      wrap.innerHTML = '';
      wrap.appendChild(el('div', 'm3-head', 'ماده ' + toFa(cur + 1) + ' از ۱۰ — امتیاز: ' + toFa(score)));
      var s = M3_SUBS[order[cur]];
      var card = el('div', 'm3-card' + (selected ? ' sel' : '') + (phase === 1 ? ' correct' : '') + (phase === 2 ? ' wrong' : ''));
      card.appendChild(el('div', 'm3-name', s.name));
      card.appendChild(el('div', 'm3-formula', s.f));
      card.onclick = function () { if (phase === 0) { selected = !selected; render(); } };
      wrap.appendChild(card);

      var zones = el('div', 'm3-zones');
      var z0 = el('button', 'm3-zone z0', 'عنصر');
      var z1 = el('button', 'm3-zone z1', 'ترکیب');
      function choose(isComp) {
        if (phase !== 0) return;
        if (!selected) return;
        if (isComp === s.comp) {
          phase = 1; score++;
          setTimeout(function () {
            cur++;
            if (cur >= 10) { done = true; render(); }
            else { phase = 0; selected = false; render(); }
          }, 500);
        } else {
          phase = 2;
          setTimeout(function () { phase = 0; selected = false; render(); }, 1500);
        }
        render();
      }
      z0.onclick = function () { choose(false); };
      z1.onclick = function () { choose(true); };
      zones.appendChild(z0);
      zones.appendChild(z1);
      wrap.appendChild(zones);

      var hint = el('div', 'm3-hint');
      if (phase === 2) hint.textContent = 'اشتباه! ' + s.why;
      else if (!selected) hint.textContent = 'ابتدا روی کارت ماده بزنید';
      else hint.textContent = 'حالا ناحیه درست را انتخاب کنید';
      wrap.appendChild(hint);
    }
    render();
  }

  // ============================================================
  // M4 — MOLECULE BUILDER (2D)
  // ============================================================
  var MOLS = [
    { name: 'آب', f: 'H₂O', h: 2, o: 1, c: 0 },
    { name: 'کربن دی‌اکسید', f: 'CO₂', h: 0, o: 2, c: 1 },
    { name: 'متان', f: 'CH₄', h: 4, o: 0, c: 1 },
    { name: 'گاز هیدروژن', f: 'H₂', h: 2, o: 0, c: 0 },
    { name: 'گاز اکسیژن', f: 'O₂', h: 0, o: 2, c: 0 },
    { name: 'کربن مونوکسید', f: 'CO', h: 0, o: 1, c: 1 }
  ];

  function initM4(root) {
    var sec = root.querySelector('section[data-renderer="m4"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m4-wrap');
    if (!wrap) return;
    var atoms = [];
    var found = [false, false, false, false, false, false];

    function render() {
      wrap.innerHTML = '';
      wrap.appendChild(el('div', 'quiz-meta', 'اتم‌ها را روی صفحه بکشید و کنار هم بچسبانید'));

      var stage = el('div', 'm4-stage');
      var stageId = 'm4-stage-' + Math.random().toString(36).substr(2, 9);
      stage.id = stageId;
      stage.style.touchAction = 'none';
      wrap.appendChild(stage);

      var addRow = el('div', 'm4-add-row');
      [['H', 'h'], ['O', 'o'], ['C', 'c']].forEach(function (def) {
        var b = el('button', 'm4-add', def[0]);
        b.onclick = function () {
          if (atoms.length >= 12) return;
          var a = {
            type: def[1],
            x: 80 + Math.random() * 200,
            y: 60 + Math.random() * 200,
            dom: null
          };
          atoms.push(a);
          var node = el('div', 'm4-atom ' + def[1], def[0]);
          node.style.left = a.x + 'px';
          node.style.top = a.y + 'px';
          var drag = false, offX = 0, offY = 0;
          function down(e) {
            var p = e.touches ? e.touches[0] : e;
            var r = node.getBoundingClientRect();
            offX = p.clientX - r.left;
            offY = p.clientY - r.top;
            drag = true;
            e.preventDefault();
          }
          function move(e) {
            if (!drag) return;
            var p = e.touches ? e.touches[0] : e;
            var sr = stage.getBoundingClientRect();
            a.x = p.clientX - sr.left - offX;
            a.y = p.clientY - sr.top - offY;
            a.x = clamp(a.x, 0, sr.width - node.offsetWidth);
            a.y = clamp(a.y, 0, sr.height - node.offsetHeight);
            node.style.left = a.x + 'px';
            node.style.top = a.y + 'px';
            checkMols();
            e.preventDefault();
          }
          function up() { drag = false; }
          node.addEventListener('mousedown', down);
          node.addEventListener('touchstart', down, { passive: false });
          document.addEventListener('mousemove', move);
          document.addEventListener('touchmove', move, { passive: false });
          document.addEventListener('mouseup', up);
          document.addEventListener('touchend', up);
          a.dom = node;
          stage.appendChild(node);
          checkMols();
        };
        addRow.appendChild(b);
      });
      wrap.appendChild(addRow);

      atoms.forEach(function (a) { stage.appendChild(a.dom); });
      checkMols();

      var foundBox = el('div', 'm4-found');
      var fc = 0;
      MOLS.forEach(function (m, i) {
        if (found[i]) fc++;
        var row = el('div', 'm4-found-row ' + (found[i] ? 'found' : 'unfound'));
        row.appendChild(el('span', null, (found[i] ? '✓ ' : '؟ ') + (found[i] ? m.name + ' (' + m.f + ')' : '؟؟؟')));
        foundBox.appendChild(row);
      });
      wrap.appendChild(foundBox);
      wrap.appendChild(el('div', 'quiz-meta', 'کشف‌شده: ' + toFa(fc) + ' از ۶'));

      var clr = el('button', 'm4-clear', 'پاک کردن همه');
      clr.onclick = function () { atoms = []; render(); };
      wrap.appendChild(clr);
    }

    function checkMols() {
      for (var i = 0; i < atoms.length; i++) {
        for (var j = i + 1; j < atoms.length; j++) {
          var dx = atoms[i].x - atoms[j].x;
          var dy = atoms[i].y - atoms[j].y;
          if (dx * dx + dy * dy < 60 * 60) {
            var cluster = groupAtoms();
            cluster.forEach(function (grp) {
              var hc = 0, oc = 0, cc = 0;
              grp.forEach(function (a) { if (a.type === 'h') hc++; else if (a.type === 'o') oc++; else cc++; });
              MOLS.forEach(function (m, idx) {
                if (m.h === hc && m.o === oc && m.c === cc) found[idx] = true;
              });
            });
            return;
          }
        }
      }
    }

    function groupAtoms() {
      var visited = [];
      var groups = [];
      for (var i = 0; i < atoms.length; i++) {
        if (visited.indexOf(i) >= 0) continue;
        var stack = [i], grp = [];
        while (stack.length) {
          var v = stack.pop();
          if (visited.indexOf(v) >= 0) continue;
          visited.push(v);
          grp.push(atoms[v]);
          for (var j = 0; j < atoms.length; j++) {
            if (visited.indexOf(j) >= 0) continue;
            var dx = atoms[v].x - atoms[j].x, dy = atoms[v].y - atoms[j].y;
            if (dx * dx + dy * dy < 60 * 60) stack.push(j);
          }
        }
        groups.push(grp);
      }
      return groups;
    }

    render();
  }

  // ============================================================
  // M5 — METAL OR NONMETAL
  // ============================================================
  var M5_PROPS = [
    { t: 'رسانایی الکتریکی خوب', metal: true },
    { t: 'چکش‌خواری', metal: true },
    { t: 'سطح براق', metal: true },
    { t: 'شکنندگی و خرد شدن با ضربه', metal: false },
    { t: 'رسانای ضعیف گرما', metal: false },
    { t: 'قابلیت تبدیل شدن به سیم', metal: true },
    { t: 'سطح مات', metal: false },
    { t: 'رسانای خوب گرما', metal: true },
    { t: 'عایق بودن در برابر برق', metal: false },
    { t: 'صدای زنگ‌مانند هنگام ضربه', metal: true }
  ];

  function initM5(root) {
    var sec = root.querySelector('section[data-renderer="m5"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m5-wrap');
    if (!wrap) return;
    var order = shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
    var cur = 0, score = 0, answered = false, done = false;

    function render() {
      if (done) {
        wrap.innerHTML = '';
        var f = el('div', 'quiz-final');
        f.appendChild(el('h3', null, 'نتیجه'));
        f.appendChild(el('div', 'score-line', toFa(score) + ' از ۱۰'));
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () {
          order = shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
          cur = 0; score = 0; answered = false; done = false;
          render();
        };
        f.appendChild(again);
        wrap.appendChild(f);
        if (score >= 7) confettiBurst();
        return;
      }
      wrap.innerHTML = '';
      wrap.appendChild(el('div', 'm5-progress', 'سوال ' + toFa(cur + 1) + ' از ۱۰'));
      var p = M5_PROPS[order[cur]];
      var card = el('div', 'm5-prop-card');
      card.appendChild(el('div', 'm5-prop-sub', 'این ویژگی مربوط به کدام گروه است؟'));
      card.appendChild(el('div', 'm5-prop-text', p.t));
      wrap.appendChild(card);

      var btns = el('div', 'm5-btns');
      var mBtn = el('button', 'm5-btn metal', 'فلز');
      var nBtn = el('button', 'm5-btn nonmetal', 'نافلز');
      function choose(isMetal) {
        if (answered) return;
        answered = true;
        var ok = isMetal === p.metal;
        if (ok) { score++; mBtn.classList.add('correct'); nBtn.classList.add('correct'); }
        else { (isMetal ? mBtn : nBtn).classList.add('wrong'); (isMetal ? nBtn : mBtn).classList.add('correct'); }
        mBtn.disabled = nBtn.disabled = true;
        var fb = el('div', 'm5-feedback ' + (ok ? 'ok' : 'bad'),
          ok ? 'درست!' : 'پاسخ درست: ' + (p.metal ? 'فلز' : 'نافلز'));
        wrap.appendChild(fb);
        setTimeout(function () {
          cur++;
          if (cur >= 10) { done = true; render(); }
          else { answered = false; render(); }
        }, 900);
      }
      mBtn.onclick = function () { choose(true); };
      nBtn.onclick = function () { choose(false); };
      btns.appendChild(mBtn);
      btns.appendChild(nBtn);
      wrap.appendChild(btns);
    }
    render();
  }

  // ============================================================
  // M6 — CARBON SHAPES (2D SVG, no rotation)
  // ============================================================
  function carbonSvg(idx) {
    var color = '#3C4458', atom = '#50505A', hi = '#A0A8BC';
    if (idx === 0) {
      // Diamond — tetrahedron
      return '<svg viewBox="0 0 200 160" width="100%"><line x1="100" y1="80" x2="60" y2="40" stroke="' + color + '" stroke-width="3"/><line x1="100" y1="80" x2="140" y2="40" stroke="' + color + '" stroke-width="3"/><line x1="100" y1="80" x2="60" y2="120" stroke="' + color + '" stroke-width="3"/><line x1="100" y1="80" x2="140" y2="120" stroke="' + color + '" stroke-width="3"/><circle cx="100" cy="80" r="14" fill="' + atom + '" stroke="#282D3C"/><circle cx="60" cy="40" r="12" fill="' + atom + '"/><circle cx="140" cy="40" r="12" fill="' + atom + '"/><circle cx="60" cy="120" r="12" fill="' + atom + '"/><circle cx="140" cy="120" r="12" fill="' + atom + '"/></svg>';
    }
    if (idx === 1) {
      // Graphite — hex layers
      var s = '<svg viewBox="0 0 200 160" width="100%">';
      for (var l = 0; l < 2; l++) {
        for (var j = 0; j < 6; j++) {
          var ang = (60 * j + 30 * l) * Math.PI / 180;
          var cx = 100 + Math.cos(ang) * 40, cy = 80 + Math.sin(ang) * 30 + (l === 0 ? -8 : 8);
          s += '<circle cx="' + cx + '" cy="' + cy + '" r="8" fill="' + atom + '"/>';
          var ang2 = (60 * ((j + 1) % 6) + 30 * l) * Math.PI / 180;
          var nx = 100 + Math.cos(ang2) * 40, ny = 80 + Math.sin(ang2) * 30 + (l === 0 ? -8 : 8);
          s += '<line x1="' + cx + '" y1="' + cy + '" x2="' + nx + '" y2="' + ny + '" stroke="' + color + '" stroke-width="2"/>';
        }
      }
      s += '</svg>';
      return s;
    }
    if (idx === 2) {
      // Fullerene — 32 atom sphere
      var s2 = '<svg viewBox="0 0 200 160" width="100%">';
      for (var i = 0; i < 32; i++) {
        var phi = Math.acos(1 - 2 * (i + 0.5) / 32);
        var theta = Math.PI * (1 + Math.sqrt(5)) * i;
        var x = 80 + Math.sin(phi) * Math.cos(theta) * 60;
        var y = 80 + Math.sin(phi) * Math.sin(theta) * 60;
        var z = Math.cos(phi);
        s2 += '<circle cx="' + x + '" cy="' + y + '" r="' + (z > 0 ? 6 : 4) + '" fill="' + atom + '" opacity="' + (z > 0 ? 1 : 0.5) + '"/>';
      }
      s2 += '</svg>';
      return s2;
    }
    // Nanotube
    var s3 = '<svg viewBox="0 0 200 160" width="100%">';
    for (var r = 0; r < 4; r++) {
      for (var j2 = 0; j2 < 6; j2++) {
        var a = (60 * j2 + 30 * (r % 2)) * Math.PI / 180;
        var cx2 = 100 + Math.cos(a) * 35, cy2 = 40 + r * 25 + Math.sin(a) * 15;
        s3 += '<circle cx="' + cx2 + '" cy="' + cy2 + '" r="6" fill="' + atom + '"/>';
      }
    }
    s3 += '</svg>';
    return s3;
  }

  function initM6(root) {
    var sec = root.querySelector('section[data-renderer="m6"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m6-wrap');
    if (!wrap) return;
    var names = ['الماس', 'گرافیت', 'فولرن (ساده‌شده)', 'نانولوله'];
    var briefs = [
      'هر اتم به ۴ اتم پیوند دارد؛ بسیار سخت',
      'لایه‌های شش‌ضلعی روی هم؛ نرم و لغزنده',
      'اتم‌ها روی سطح یک گوی توخالی',
      'کربنِ لوله‌ای‌شکل؛ بسیار محکم و سبک'
    ];
    var details = [
      'الماس: هر اتم کربن با چهار پیوند به چهار اتم دیگر وصل است. شفاف و درخشان و سخت‌ترین مادهٔ طبیعی است.',
      'گرافیت: اتم‌ها در لایه‌های شش‌ضلعی قرار دارند. نرم است؛ مغز مداد از آن ساخته می‌شود.',
      'فولرن: اتم‌های کربن روی سطح یک گوی توخالی قرار می‌گیرند.',
      'نانولوله: اتم‌های کربن در حلقه‌های شش‌ضلعی پشت سر هم، یک لولهٔ بسیار محکم و سبک می‌سازند.'
    ];
    var dalton = 'بر اساس نظریهٔ دالتون، اتم‌های کربن در همهٔ این شکل‌ها یکسان‌اند. هیچ اتمی ساخته یا نابود نمی‌شود؛ فقط آرایش و تعداد پیوندهای آن فرق می‌کند.';

    wrap.innerHTML = '';
    wrap.appendChild(el('div', 'm6-intro', 'روی هر شکل کلیک کنید تا توضیحات کامل را ببینید'));
    var grid = el('div', 'm6-grid');
    for (var i = 0; i < 4; i++) {
      var card = el('div', 'm6-card');
      card.appendChild(el('div', 'm6-card-title', names[i]));
      var svgBox = el('div');
      svgBox.innerHTML = carbonSvg(i);
      card.appendChild(svgBox);
      card.appendChild(el('div', 'm6-card-brief', briefs[i]));
      (function (idx) {
        card.onclick = function () { showDetail(idx); };
      })(i);
      grid.appendChild(card);
    }
    wrap.appendChild(grid);
    var daltonEl = el('div', 'm6-intro', dalton);
    daltonEl.style.marginTop = '16px';
    daltonEl.style.color = '#3C5AC8';
    wrap.appendChild(daltonEl);

    function showDetail(idx) {
      var ov = el('div', 'm6-detail-overlay');
      var box = el('div', 'm6-detail');
      box.appendChild(el('h3', null, names[idx]));
      var svgBox = el('div');
      svgBox.innerHTML = carbonSvg(idx);
      box.appendChild(svgBox);
      box.appendChild(el('p', null, details[idx]));
      box.appendChild(el('p', null, dalton));
      ov.appendChild(box);
      ov.onclick = function (e) { if (e.target === ov) ov.remove(); };
      document.body.appendChild(ov);
    }
  }

  // ============================================================
  // M7 — MATCH MATERIAL AND USE
  // ============================================================
  var M7_LEFT = ['آهن', 'مس', 'طلا', 'هلیم', 'کلر', 'اکسیژن', 'کربن', 'نیتروژن'];
  var M7_RIGHT = [
    'ساخت پل و ماشین‌آلات',
    'سیم‌های برق',
    'جواهرسازی',
    'پر کردن بالن‌ها',
    'ضدعفونی آب استخر',
    'تنفس موجودات زنده',
    'مغز مداد و الکترود',
    'ساخت کود شیمیایی'
  ];

  function initM7(root) {
    var sec = root.querySelector('section[data-renderer="m7"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m7-wrap');
    if (!wrap) return;
    var rightOrder = shuffle([0, 1, 2, 3, 4, 5, 6, 7]);
    var done = [false, false, false, false, false, false, false, false];
    var selectedLeft = -1;
    var score = 0;

    function render() {
      wrap.innerHTML = '';
      wrap.appendChild(el('div', 'quiz-meta', 'یک ماده را انتخاب کنید، سپس کاربردش را بزنید'));
      var cols = el('div', 'm7-cols');
      var left = el('div', 'm7-col');
      var right = el('div', 'm7-col');

      M7_LEFT.forEach(function (name, i) {
        var b = el('button', 'm7-item left' + (selectedLeft === i && !done[i] ? ' sel' : '') + (done[i] ? ' done' : ''), name);
        if (done[i]) b.disabled = true;
        b.onclick = function () { if (done[i]) return; selectedLeft = i; render(); };
        left.appendChild(b);
      });
      rightOrder.forEach(function (origIdx, s) {
        var b = el('button', 'm7-item right' + (done[origIdx] ? ' done' : ''), M7_RIGHT[origIdx]);
        if (done[origIdx]) b.disabled = true;
        b.onclick = function () {
          if (selectedLeft < 0 || done[origIdx]) return;
          if (selectedLeft === origIdx) {
            done[origIdx] = true;
            score++;
            selectedLeft = -1;
            render();
            if (score >= 8) {
              setTimeout(function () {
                wrap.appendChild(el('div', 'quiz-meta', 'آفرین! همه را درست تطبیق دادی'));
                confettiBurst();
              }, 200);
            }
          } else {
            b.style.background = '#EF4444';
            selectedLeft = -1;
            setTimeout(render, 400);
          }
        };
        right.appendChild(b);
      });
      cols.appendChild(left);
      cols.appendChild(right);
      wrap.appendChild(cols);
      wrap.appendChild(el('div', 'm7-score', 'امتیاز: ' + toFa(score) + ' از ۸'));
    }
    render();
  }

  // ============================================================
  // M8 — EVIDENCE (ink diffusion + questions)
  // ============================================================
  var M8_QS = [
    {
      q: 'این پدیده چه چیزی را نشان می‌دهد؟',
      opts: ['آب ساکن است', 'ماده از ذره‌های در حال حرکت ساخته شده', 'جوهر زنده است', 'آب و جوهر ذره ندارند'],
      c: 1,
      e: 'جوهر خودبه‌خود در آب پخش می‌شود؛ پس ذره‌ها همیشه در حرکت‌اند.'
    },
    {
      q: 'اگر آب گرم‌تر بود، پخش شدن جوهر چگونه می‌شد؟',
      opts: ['کندتر', 'سریع‌تر', 'بدون تغییر', 'متوقف می‌شد'],
      c: 1,
      e: 'با گرما ذره‌ها سریع‌تر حرکت می‌کنند.'
    },
    {
      q: 'چرا ذره‌های آب و جوهر را با چشم نمی‌بینیم؟',
      opts: ['بسیار ریزند', 'شفاف‌اند', 'خیلی دورند', 'وجود ندارند'],
      c: 0,
      e: 'ذره‌ها بسیار ریزند و از رفتار ماده به وجود آن‌ها پی می‌بریم.'
    }
  ];

  function initM8(root) {
    var sec = root.querySelector('section[data-renderer="m8"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m8-wrap');
    if (!wrap) return;
    var stage = el('div', 'm8-stage');
    wrap.appendChild(stage);
    var dots = [];
    for (var i = 0; i < 80; i++) {
      var d = el('div', 'm8-drop');
      d._x = stage.clientWidth / 2 + (Math.random() - 0.5) * 20;
      d._y = 30 + (Math.random() - 0.5) * 20;
      d.style.left = d._x + 'px';
      d.style.top = d._y + 'px';
      stage.appendChild(d);
      dots.push(d);
    }

    var hint = el('div', 'm8-hint', 'یک قطره جوهر در آب ریخته شد؛ نگاه کنید...');
    wrap.appendChild(hint);

    var startTime = Date.now();
    var finished = false;
    var cur = 0, score = 0;

    function anim() {
      var t = (Date.now() - startTime) / 1000;
      var W = stage.clientWidth, H = stage.clientHeight;
      dots.forEach(function (d) {
        d._x += (Math.random() - 0.5) * 4;
        d._y += (Math.random() - 0.5) * 4 + 0.1;
        d._x = clamp(d._x, 8, W - 8);
        d._y = clamp(d._y, 8, H - 8);
        d.style.left = d._x + 'px';
        d.style.top = d._y + 'px';
      });
      if (t > 7 && !finished) {
        finished = true;
        hint.textContent = '';
        renderQuestion();
      }
      if (!finished) requestAnimationFrame(anim);
    }
    requestAnimationFrame(anim);

    function renderQuestion() {
      wrap.innerHTML = '';
      if (cur >= M8_QS.length) {
        var f = el('div', 'quiz-final');
        f.appendChild(el('h3', null, 'نتیجه'));
        f.appendChild(el('div', 'score-line', toFa(score) + ' از ۳'));
        var again = el('button', 'btn-sm green', 'شروع دوباره');
        again.style.marginTop = '20px';
        again.onclick = function () {
          cur = 0; score = 0; finished = false; startTime = Date.now();
          wrap.innerHTML = '';
          wrap.appendChild(stage);
          wrap.appendChild(hint);
          stage.innerHTML = '';
          dots = [];
          for (var k = 0; k < 80; k++) {
            var dd = el('div', 'm8-drop');
            dd._x = stage.clientWidth / 2 + (Math.random() - 0.5) * 20;
            dd._y = 30 + (Math.random() - 0.5) * 20;
            dd.style.left = dd._x + 'px';
            dd.style.top = dd._y + 'px';
            stage.appendChild(dd);
            dots.push(dd);
          }
          requestAnimationFrame(anim);
        };
        f.appendChild(again);
        wrap.appendChild(f);
        if (score === 3) confettiBurst();
        return;
      }
      var q = M8_QS[cur];
      var qBox = el('div', 'm8-q');
      qBox.appendChild(el('div', 'm8-q-text', toFa(cur + 1) + '. ' + q.q));
      var perm = shuffle([0, 1, 2, 3]);
      var answered = false;
      perm.forEach(function (origIdx) {
        var b = el('button', 'm8-opt', q.opts[origIdx]);
        b.onclick = function () {
          if (answered) return;
          answered = true;
          var ok = origIdx === q.c;
          if (ok) score++;
          qBox.querySelectorAll('.m8-opt').forEach(function (btn, bi) {
            btn.disabled = true;
            if (perm[bi] === q.c) btn.classList.add('correct');
            else if (bi === perm.indexOf(origIdx)) btn.classList.add('wrong');
          });
          var ex = el('div', 'quiz-expl', q.e);
          qBox.appendChild(ex);
          var nx = el('button', 'btn-sm green', cur === M8_QS.length - 1 ? 'نتیجه' : 'بعدی');
          nx.style.marginTop = '10px';
          nx.onclick = function () { cur++; renderQuestion(); };
          qBox.appendChild(nx);
        };
        qBox.appendChild(b);
      });
      wrap.appendChild(qBox);
    }
  }

  // ============================================================
  // M9 — COUNT ATOMS
  // ============================================================
  var M9_MOLS = [
    { f: 'CO₂', atoms: [{ t: 'o', x: 50, y: 50 }, { t: 'c', x: 120, y: 50 }, { t: 'o', x: 190, y: 50 }] },
    { f: 'H₂O', atoms: [{ t: 'h', x: 70, y: 90 }, { t: 'h', x: 170, y: 90 }, { t: 'o', x: 120, y: 40 }] },
    { f: 'CH₄', atoms: [{ t: 'c', x: 120, y: 90 }, { t: 'h', x: 50, y: 30 }, { t: 'h', x: 190, y: 30 }, { t: 'h', x: 50, y: 150 }, { t: 'h', x: 190, y: 150 }] },
    { f: 'CO', atoms: [{ t: 'c', x: 80, y: 80 }, { t: 'o', x: 160, y: 80 }] },
    { f: 'H₂O₂', atoms: [{ t: 'h', x: 40, y: 60 }, { t: 'o', x: 90, y: 100 }, { t: 'o', x: 150, y: 100 }, { t: 'h', x: 200, y: 60 }] },
    { f: 'C₂H₆', atoms: [{ t: 'c', x: 90, y: 90 }, { t: 'c', x: 150, y: 90 }, { t: 'h', x: 40, y: 30 }, { t: 'h', x: 40, y: 150 }, { t: 'h', x: 90, y: 30 }, { t: 'h', x: 150, y: 30 }, { t: 'h', x: 200, y: 30 }, { t: 'h', x: 200, y: 150 }] }
  ];

  function initM9(root) {
    var sec = root.querySelector('section[data-renderer="m9"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m9-wrap');
    if (!wrap) return;
    var order = shuffle([0, 1, 2, 3, 4, 5]);
    var cur = 0, score = 0, done = false;

    function render() {
      if (done) {
        wrap.innerHTML = '';
        var f = el('div', 'quiz-final');
        f.appendChild(el('h3', null, 'نتیجه'));
        f.appendChild(el('div', 'score-line', toFa(score) + ' از ۶'));
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () {
          order = shuffle([0, 1, 2, 3, 4, 5]); cur = 0; score = 0; done = false; render();
        };
        f.appendChild(again);
        wrap.appendChild(f);
        if (score >= 4) confettiBurst();
        return;
      }
      wrap.innerHTML = '';
      wrap.appendChild(el('div', 'quiz-meta', 'مولکول ' + toFa(cur + 1) + ' از ۶'));
      var m = M9_MOLS[order[cur]];
      wrap.appendChild(el('div', 'm9-formula', m.f));

      var mol = el('div', 'm9-mol');
      m.atoms.forEach(function (a) {
        var node = el('div', 'm9-atom', a.t === 'h' ? 'H' : (a.t === 'o' ? 'O' : 'C'));
        var size = a.t === 'h' ? 30 : (a.t === 'o' ? 42 : 46);
        node.style.width = size + 'px';
        node.style.height = size + 'px';
        node.style.left = a.x + 'px';
        node.style.top = a.y + 'px';
        node.style.background = a.t === 'h' ? '#DDDDDD' : (a.t === 'o' ? '#DC3C3C' : '#282D3C');
        node.style.color = a.t === 'h' ? '#1A1A1A' : '#fff';
        node.style.fontSize = '12px';
        mol.appendChild(node);
      });
      wrap.appendChild(mol);

      var counts = {};
      m.atoms.forEach(function (a) { counts[a.t] = (counts[a.t] || 0) + 1; });
      var keys = Object.keys(counts);
      var types = keys.slice(0, 2);
      if (types.length < 2) types.push(types[0]);

      wrap.appendChild(el('div', 'm9-q',
        'این مولکول از چند اتم ' + (types[0] === 'h' ? 'هیدروژن' : types[0] === 'o' ? 'اکسیژن' : 'کربن') +
        ' و چند اتم ' + (types[1] === 'h' ? 'هیدروژن' : types[1] === 'o' ? 'اکسیژن' : 'کربن') + ' تشکیل شده است؟'));

      var inputs = el('div', 'm9-inputs');
      var in0 = document.createElement('input');
      in0.type = 'number'; in0.className = 'm9-input'; in0.min = '0'; in0.max = '10';
      var in1 = document.createElement('input');
      in1.type = 'number'; in1.className = 'm9-input'; in1.min = '0'; in1.max = '10';
      var row0 = el('div', 'm9-input-row');
      row0.appendChild(el('label', null, 'تعداد ' + (types[0] === 'h' ? 'هیدروژن' : types[0] === 'o' ? 'اکسیژن' : 'کربن') + ':'));
      row0.appendChild(in0);
      var row1 = el('div', 'm9-input-row');
      row1.appendChild(el('label', null, 'تعداد ' + (types[1] === 'h' ? 'هیدروژن' : types[1] === 'o' ? 'اکسیژن' : 'کربن') + ':'));
      row1.appendChild(in1);
      inputs.appendChild(row0);
      inputs.appendChild(row1);
      wrap.appendChild(inputs);

      var msg = el('div', 'm9-msg');
      wrap.appendChild(msg);

      var btn = el('button', 'btn-sm green', 'بررسی');
      btn.onclick = function () {
        if (!in0.value || !in1.value) return;
        var v0 = parseInt(in0.value, 10);
        var v1 = parseInt(in1.value, 10);
        var c0 = counts[types[0]] || 0;
        var c1 = counts[types[1]] || 0;
        if (types[0] === types[1]) { c1 = 0; }
        var ok = v0 === c0 && (types[0] === types[1] || v1 === c1);
        in0.classList.add(ok ? 'ok' : 'bad');
        in1.classList.add(ok ? 'ok' : 'bad');
        if (ok) {
          score++;
          msg.className = 'm9-msg ok';
          msg.textContent = 'آفرین!';
        } else {
          msg.className = 'm9-msg bad';
          msg.textContent = 'درست: ' + c0 + ' و ' + (types[0] === types[1] ? '—' : c1);
        }
        var nx = el('button', 'btn-sm green', cur === 5 ? 'نتیجه' : 'بعدی');
        nx.style.marginTop = '12px';
        nx.onclick = function () { cur++; if (cur >= 6) { done = true; render(); } else render(); };
        wrap.appendChild(nx);
        btn.disabled = true;
        in0.disabled = true;
        in1.disabled = true;
      };
      wrap.appendChild(btn);
    }
    render();
  }

  // ============================================================
  // M10 — ELEMENT FILE
  // ============================================================
  var M10_ELEMS = [
    { sym: 'Fe', name: 'آهن', z: 26, cat: 'metal', use: 'ساخت سازه‌ها، پل‌ها، ماشین‌آلات' },
    { sym: 'Cu', name: 'مس', z: 29, cat: 'metal', use: 'سیم‌های برق و لوله‌کشی' },
    { sym: 'Au', name: 'طلا', z: 79, cat: 'metal', use: 'جواهرسازی، قطعات الکترونیکی' },
    { sym: 'O', name: 'اکسیژن', z: 8, cat: 'nonmetal', use: 'تنفس، سوختن' },
    { sym: 'C', name: 'کربن', z: 6, cat: 'nonmetal', use: 'سوخت، مغز مداد، الماس' },
    { sym: 'H', name: 'هیدروژن', z: 1, cat: 'nonmetal', use: 'سوخت موشک، آمونیاک' },
    { sym: 'N', name: 'نیتروژن', z: 7, cat: 'nonmetal', use: 'ساخت کود شیمیایی' },
    { sym: 'Na', name: 'سدیم', z: 11, cat: 'metal', use: 'نمک خوراکی با کلر' },
    { sym: 'Cl', name: 'کلر', z: 17, cat: 'nonmetal', use: 'ضدعفونی آب استخر' },
    { sym: 'He', name: 'هلیم', z: 2, cat: 'noble', use: 'پر کردن بالن‌ها' }
  ];

  function initM10(root) {
    var sec = root.querySelector('section[data-renderer="m10"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m10-wrap');
    if (!wrap) return;
    var sel = -1;

    function render() {
      wrap.innerHTML = '';
      wrap.appendChild(el('div', 'quiz-meta', 'روی یک عنصر کلیک کنید'));
      var grid = el('div', 'm10-grid');
      M10_ELEMS.forEach(function (e, i) {
        var cls = 'm10-tile ' + e.cat + (sel === i ? ' sel' : '');
        var b = el('div', cls);
        b.appendChild(el('div', null, e.sym));
        b.appendChild(el('div', null, e.name));
        b.onclick = function () { sel = i; render(); };
        grid.appendChild(b);
      });
      wrap.appendChild(grid);

      var panel = el('div', 'm10-panel');
      if (sel < 0) {
        panel.textContent = 'یک عنصر را انتخاب کنید';
      } else {
        var e = M10_ELEMS[sel];
        panel.innerHTML =
          '<h3>' + e.name + '</h3>' +
          '<div class="sym">' + e.sym + '</div>' +
          '<div>عدد اتمی: ' + toFa(e.z) + '</div>' +
          '<div style="color:#2563EB;margin-top:8px">کاربرد: ' + e.use + '</div>';
      }
      wrap.appendChild(panel);
    }
    render();
  }

  // ============================================================
  // M11 — CHALLENGE (20 questions from 24)
  // ============================================================
  var M11_BANK = [
    { q: 'کوچک‌ترین ذره سازنده یک عنصر چه نام دارد؟', o: ['مولکول', 'اتم', 'سلول', 'یون'], c: 1 },
    { q: 'کدام ذره در هسته اتم بار مثبت دارد؟', o: ['الکترون', 'نوترون', 'پروتون', 'نور'], c: 2 },
    { q: 'الکترون‌ها در اتم چه می‌کنند؟', o: ['درون هسته ثابت‌اند', 'به دور هسته می‌چرخند', 'بار مثبت دارند', 'جرم اتم را تعیین می‌کنند'], c: 1 },
    { q: 'نوترون چه باری دارد؟', o: ['مثبت', 'منفی', 'خنثی', 'متغیر'], c: 2 },
    { q: 'کدام یک عنصر است؟', o: ['آب', 'نمک', 'آهن', 'شکر'], c: 2 },
    { q: 'کدام یک ترکیب است؟', o: ['اکسیژن', 'طلا', 'مس', 'کربن دی‌اکسید'], c: 3 },
    { q: 'فرمول شیمیایی آب کدام است؟', o: ['CO₂', 'H₂O', 'O₂', 'NaCl'], c: 1 },
    { q: 'مولکول کربن دی‌اکسید چند اتم دارد؟', o: ['۲', '۳', '۴', '۵'], c: 1 },
    { q: 'کدام ویژگی مربوط به فلزهاست؟', o: ['شکننده بودن', 'رسانایی الکتریکی خوب', 'مات بودن', 'عایق بودن'], c: 1 },
    { q: 'کدام یک نافلز است؟', o: ['آهن', 'مس', 'گوگرد', 'طلا'], c: 2 },
    { q: 'الماس و گرافیت از کدام عنصر ساخته شده‌اند؟', o: ['سیلیسیم', 'کربن', 'آهن', 'اکسیژن'], c: 1 },
    { q: 'سخت‌ترین ماده طبیعی کدام است؟', o: ['گرافیت', 'الماس', 'آهن', 'مس'], c: 1 },
    { q: 'در حالت جامد ذره‌ها چگونه‌اند؟', o: ['دور از هم و آزاد', 'منظم و نزدیک به هم', 'فقط می‌چرخند', 'وجود ندارند'], c: 1 },
    { q: 'در حالت گاز ذره‌ها چگونه‌اند؟', o: ['در جای خود می‌لرزند', 'به‌آرامی می‌لغزند', 'سریع حرکت می‌کنند و دورند', 'بی‌حرکت‌اند'], c: 2 },
    { q: 'تبدیل مایع به گاز چه نام دارد؟', o: ['ذوب', 'انجماد', 'تبخیر', 'میعان'], c: 2 },
    { q: 'تبدیل گاز به مایع چه نام دارد؟', o: ['تبخیر', 'میعان', 'ذوب', 'انجماد'], c: 1 },
    { q: 'پخش شدن جوهر در آب چه چیزی را نشان می‌دهد؟', o: ['آب زنده است', 'ذره‌ها در حرکت‌اند', 'جوهر سنگین است', 'آب ساکن است'], c: 1 },
    { q: 'اتم‌ها را با چشم نمی‌بینیم؛ از کجا پی می‌بریم؟', o: ['از شواهد غیرمستقیم', 'از حدس بی‌دلیل', 'از ظاهر ماده', 'از رنگ ماده'], c: 0 },
    { q: 'یک مولکول آب چند اتم هیدروژن دارد؟', o: ['۱', '۲', '۳', '۴'], c: 1 },
    { q: 'نماد شیمیایی طلا کدام است؟', o: ['Ag', 'Au', 'Fe', 'Cu'], c: 1 },
    { q: 'نماد شیمیایی آهن کدام است؟', o: ['Fe', 'Ir', 'Cu', 'F'], c: 0 },
    { q: 'گاز هلیم برای چه کاری استفاده می‌شود؟', o: ['پر کردن بالن‌ها', 'ساخت سیم', 'ساخت پل', 'ساخت جواهر'], c: 0 },
    { q: 'مولکول متان از چه اتم‌هایی ساخته شده است؟', o: ['کربن و هیدروژن', 'کربن و اکسیژن', 'هیدروژن و اکسیژن', 'نیتروژن و هیدروژن'], c: 0 },
    { q: 'گرافیت برای چه کاری به کار می‌رود؟', o: ['ساخت مغز مداد', 'ساخت جواهر', 'ساخت بالن', 'ساخت لوله آب'], c: 0 }
  ];

  function initM11(root) {
    var sec = root.querySelector('section[data-renderer="m11"]');
    if (!sec) return;
    var wrap = sec.querySelector('#m11-wrap');
    if (!wrap) return;
    var order = shuffle([...Array(24).keys()]).slice(0, 20);
    var cur = 0, answers = new Array(20).fill(-1), perms = [], done = false;

    function render() {
      if (done) {
        var score = 0;
        for (var i = 0; i < 20; i++) if (answers[i] === M11_BANK[order[i]].c) score++;
        var pct = Math.round(score * 100 / 20);
        wrap.innerHTML = '';
        var f = el('div', 'quiz-final');
        f.appendChild(el('h3', null, 'نتیجه چالش'));
        var bar = el('div', 'score-bar');
        var fill = el('div');
        fill.style.width = pct + '%';
        bar.appendChild(fill);
        f.appendChild(bar);
        f.appendChild(el('div', 'score-line', toFa(score) + ' از ۲۰'));
        f.appendChild(el('div', 'score-line', 'درصد: ' + toFa(pct) + '٪'));
        var again = el('button', 'btn-sm green', 'چالش جدید');
        again.style.marginTop = '20px';
        again.onclick = function () {
          order = shuffle([...Array(24).keys()]).slice(0, 20);
          cur = 0; answers = new Array(20).fill(-1); perms = []; done = false; render();
        };
        f.appendChild(again);
        wrap.appendChild(f);
        if (pct >= 70) confettiBurst();
        return;
      }
      wrap.innerHTML = '';
      var prog = el('div', 'm11-progress');
      var fill = el('div');
      fill.style.width = ((cur + 1) / 20 * 100) + '%';
      prog.appendChild(fill);
      wrap.appendChild(prog);
      wrap.appendChild(el('div', 'm11-meta', 'سوال ' + toFa(cur + 1) + ' از ۲۰'));

      var q = M11_BANK[order[cur]];
      wrap.appendChild(el('div', 'quiz-question', q.q));
      if (!perms[cur]) perms[cur] = shuffle([0, 1, 2, 3]);
      var opts = el('div', 'quiz-options');
      perms[cur].forEach(function (origIdx) {
        var b = el('button', 'quiz-opt', q.o[origIdx]);
        if (answers[cur] === origIdx) b.classList.add(origIdx === q.c ? 'correct' : 'wrong');
        b.onclick = function () { answers[cur] = origIdx; render(); };
        opts.appendChild(b);
      });
      wrap.appendChild(opts);

      var nav = el('div', 'quiz-nav');
      if (cur > 0) {
        var prev = el('button', 'btn-sm gray', 'قبلی');
        prev.onclick = function () { cur--; render(); };
        nav.appendChild(prev);
      }
      if (cur < 19) {
        var next = el('button', 'btn-sm green', 'بعدی');
        next.onclick = function () { cur++; render(); };
        nav.appendChild(next);
      } else {
        var fin = el('button', 'btn-sm red', 'اتمام');
        fin.onclick = function () { done = true; render(); };
        nav.appendChild(fin);
      }
      wrap.appendChild(nav);
    }
    render();
  }

})();