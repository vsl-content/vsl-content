(() => {
  "use strict";

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const app = $("#app");

  const sections = [
    "home", "matter", "atom", "elemcomp", "molbuild", "metal",
    "carbon", "match", "evidence", "count", "element", "challenge"
  ];

  const sectionNames = {
    home: "خانه", matter: "ماده و ذره‌ها", atom: "ساختار اتم",
    elemcomp: "عنصر یا ترکیب", molbuild: "مولکول‌ساز",
    metal: "فلز و نافلز", carbon: "شکل‌های کربن",
    match: "بازی جورکردنی", evidence: "شواهد غیرمستقیم",
    count: "شمارش اتم‌ها", element: "شناسنامه عنصرها",
    challenge: "چالش پایانی"
  };

  let completed = new Set();
  let soundOn = true;
  let challengeQuestions = [];
  let challengeIndex = 0;
  let challengeScore = 0;
  let challengeAnswered = false;
  let matchSelected = null;
  let matchFound = new Set();
  let evidenceIndex = 0;
  let evidenceAnswers = {};

  const atomData = {
    H: { name: "هیدروژن", number: 1, color: "#f7f7ff" },
    C: { name: "کربن", number: 6, color: "#555d70" },
    N: { name: "نیتروژن", number: 7, color: "#4887ed" },
    O: { name: "اکسیژن", number: 8, color: "#ed5a5a" },
    Na: { name: "سدیم", number: 11, color: "#a88cf2" },
    Cl: { name: "کلر", number: 17, color: "#65bd78" }
  };

  const elements = [
    { symbol: "H", name: "هیدروژن", number: 1, category: "نافلز", use: "در تولید برخی سوخت‌ها و ترکیبات شیمیایی" },
    { symbol: "He", name: "هلیم", number: 2, category: "گاز نجیب", use: "در بالن‌ها و تجهیزات سرمایشی" },
    { symbol: "C", name: "کربن", number: 6, category: "نافلز", use: "در نوک مداد، زغال و مواد آلی" },
    { symbol: "N", name: "نیتروژن", number: 7, category: "نافلز", use: "بخش عمده هوای اطراف ما را تشکیل می‌دهد" },
    { symbol: "O", name: "اکسیژن", number: 8, category: "نافلز", use: "برای تنفس و سوختن بسیاری از مواد ضروری است" },
    { symbol: "Na", name: "سدیم", number: 11, category: "فلز", use: "در ترکیب‌های گوناگون، مانند نمک خوراکی" },
    { symbol: "Al", name: "آلومینیم", number: 13, category: "فلز", use: "در ساخت قوطی، فویل و وسایل سبک" },
    { symbol: "Si", name: "سیلیسیم", number: 14, category: "شبه‌فلز", use: "در ساخت تراشه‌های الکترونیکی" },
    { symbol: "Cl", name: "کلر", number: 17, category: "نافلز", use: "در گندزدایی آب و ساخت برخی مواد" },
    { symbol: "Fe", name: "آهن", number: 26, category: "فلز", use: "در ساخت ابزارها و سازه‌های فلزی" }
  ];

  const formulas = {
    CO2: { name: "کربن‌دی‌اکسید", atoms: { C: 1, O: 2 }, note: "یک اتم کربن و دو اتم اکسیژن" },
    H2O: { name: "آب", atoms: { H: 2, O: 1 }, note: "دو اتم هیدروژن و یک اتم اکسیژن" },
    CH4: { name: "متان", atoms: { C: 1, H: 4 }, note: "یک اتم کربن و چهار اتم هیدروژن" },
    CO: { name: "کربن‌مونوکسید", atoms: { C: 1, O: 1 }, note: "یک اتم کربن و یک اتم اکسیژن" },
    H2O2: { name: "هیدروژن پراکسید", atoms: { H: 2, O: 2 }, note: "دو اتم هیدروژن و دو اتم اکسیژن" },
    C2H6: { name: "اتان", atoms: { C: 2, H: 6 }, note: "دو اتم کربن و شش اتم هیدروژن" }
  };

  const quizBank = [
    { q: "کوچک‌ترین ذره سازنده یک عنصر که ویژگی‌های آن عنصر را دارد چیست؟", a: ["اتم", "مولکول آب", "سلول", "بلور"], correct: 0, why: "اتم کوچک‌ترین ذره سازنده عنصر است که ویژگی‌های آن را حفظ می‌کند." },
    { q: "کدام ذره بار الکتریکی مثبت دارد؟", a: ["الکترون", "پروتون", "نوترون", "مولکول"], correct: 1, why: "پروتون بار مثبت دارد." },
    { q: "کدام ذره در هسته اتم قرار دارد و بار ندارد؟", a: ["نوترون", "الکترون", "پروتون", "یون"], correct: 0, why: "نوترون در هسته قرار دارد و بدون بار الکتریکی است." },
    { q: "عدد اتمی هر عنصر برابر تعداد کدام ذره است؟", a: ["نوترون", "مولکول", "پروتون", "لایه"], correct: 2, why: "عدد اتمی برابر تعداد پروتون‌های هسته است." },
    { q: "آب از چه نوع ماده‌ای است؟", a: ["عنصر", "ترکیب", "مخلوط فلزی", "اتم تنها"], correct: 1, why: "آب از دو نوع اتم هیدروژن و اکسیژن ساخته شده است." },
    { q: "نماد شیمیایی اکسیژن کدام است؟", a: ["Ox", "O", "Og", "C"], correct: 1, why: "نماد شیمیایی اکسیژن O است." },
    { q: "کدام مورد یک عنصر است؟", a: ["آب", "نمک", "آهن", "کربن‌دی‌اکسید"], correct: 2, why: "آهن از یک نوع اتم ساخته شده و عنصر است." },
    { q: "در مولکول CO2 چند اتم اکسیژن وجود دارد؟", a: ["۱", "۲", "۳", "۴"], correct: 1, why: "عدد کوچک ۲ پس از O تعداد اتم‌های اکسیژن را نشان می‌دهد." },
    { q: "کدام ویژگی معمولاً در فلزها دیده می‌شود؟", a: ["شکنندگی همیشگی", "رسانایی الکتریکی", "نداشتن جلای فلزی", "گاز بودن"], correct: 1, why: "بسیاری از فلزها رسانای خوب گرما و برق هستند." },
    { q: "کدام شکل کربن در نوک مداد به کار می‌رود؟", a: ["الماس", "گرافیت", "نمک", "گوگرد"], correct: 1, why: "مغز مداد از گرافیت و مواد دیگر ساخته می‌شود." },
    { q: "الکترون‌ها در کدام بخش اتم قرار دارند؟", a: ["هسته", "اطراف هسته", "داخل پروتون", "داخل نوترون"], correct: 1, why: "الکترون‌ها در ناحیه اطراف هسته قرار دارند." },
    { q: "کدام گزینه مولکول یک عنصر است؟", a: ["H2", "H2O", "CO2", "NaCl"], correct: 0, why: "مولکول H2 از دو اتم یکسان هیدروژن تشکیل شده است." },
    { q: "در اتم خنثی تعداد پروتون‌ها با تعداد کدام ذره برابر است؟", a: ["نوترون", "الکترون", "مولکول", "هسته"], correct: 1, why: "در اتم خنثی تعداد بارهای مثبت و منفی برابر است." },
    { q: "کدام ذره جرم بسیار کمی در مقایسه با پروتون دارد؟", a: ["نوترون", "الکترون", "هسته", "اتم"], correct: 1, why: "جرم الکترون بسیار کمتر از جرم پروتون است." },
    { q: "نماد شیمیایی کربن چیست؟", a: ["K", "Ca", "C", "Co"], correct: 2, why: "نماد کربن C است." },
    { q: "در فرمول H2O مجموع اتم‌ها چند عدد است؟", a: ["۲", "۳", "۴", "۵"], correct: 1, why: "دو اتم هیدروژن به‌علاوه یک اتم اکسیژن، سه اتم می‌شود." },
    { q: "کدام ماده از دو یا چند نوع اتم تشکیل شده است؟", a: ["عنصر", "ترکیب", "پروتون", "نوترون"], correct: 1, why: "ترکیب از پیوند شیمیایی بین اتم‌های عناصر متفاوت تشکیل می‌شود." },
    { q: "کدام گزینه نافلز است؟", a: ["آهن", "مس", "اکسیژن", "آلومینیم"], correct: 2, why: "اکسیژن یک نافلز است." },
    { q: "در هسته اتم چه ذره‌هایی وجود دارند؟", a: ["پروتون و نوترون", "الکترون و پروتون", "فقط الکترون", "فقط نوترون"], correct: 0, why: "هسته از پروتون‌ها و نوترون‌ها تشکیل شده است." },
    { q: "در فرمول CH4 تعداد کل اتم‌ها چند است؟", a: ["۳", "۴", "۵", "۶"], correct: 2, why: "یک کربن و چهار هیدروژن، در مجموع پنج اتم هستند." },
    { q: "کدام ماده از اتم‌های یکسان تشکیل شده است؟", a: ["اکسیژن خالص", "آب", "شکر", "نمک خوراکی"], correct: 0, why: "اکسیژن یک عنصر است و فقط از اتم‌های اکسیژن تشکیل می‌شود." },
    { q: "در نماد O عدد اتمی اکسیژن چند است؟", a: ["۶", "۷", "۸", "۱۶"], correct: 2, why: "عدد اتمی اکسیژن ۸ است." },
    { q: "کدام شکل کربن بسیار سخت است؟", a: ["گرافیت", "الماس", "دوده", "زغال چوب"], correct: 1, why: "الماس ساختار شبکه‌ای محکمی دارد و بسیار سخت است." },
    { q: "چرا حرکت ذره‌های عطر در اتاق قابل مشاهده نیست؟", a: ["ذره‌ها حرکت نمی‌کنند", "ذره‌ها بسیار کوچک‌اند", "عطر جامد است", "هوا وجود ندارد"], correct: 1, why: "ذره‌ها بسیار کوچک‌اند؛ اثر پخش شدن آن‌ها را می‌توانیم مشاهده کنیم." }
  ];

  function fa(number) {
    return String(number).replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
  }

  function go(section) {
    if (!sections.includes(section)) section = "home";
    app.dataset.section = section;
    $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.section === section));
    $("#mobileNavigation").value = section;
    render(section);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function markComplete(section) {
    completed.add(section);
    updateProgress();
  }

  function updateProgress() {
    $("#progressLabel").textContent = `${fa(completed.size)} از ۱۲ بخش`;
    $$(".nav-item").forEach(button => {
      const old = $(".done-mark", button);
      if (old) old.remove();
      if (completed.has(button.dataset.section)) {
        const mark = document.createElement("span");
        mark.className = "done-mark";
        mark.textContent = "✓";
        button.append(mark);
      }
    });
  }

  function header(kicker, title, description) {
    return `<div class="section-header">
      <div class="eyebrow">${kicker}</div>
      <h1>${title}</h1>
      <p>${description}</p>
    </div>`;
  }

  function card(title, content, extra = "") {
    return `<section class="card ${extra}"><h3>${title}</h3>${content}</section>`;
  }

  function button(label, action, cls = "primary-button") {
    return `<button class="${cls}" data-action="${action}">${label}</button>`;
  }

  function completeButton(section) {
    return `<button class="complete-button" data-complete="${section}">✓ این بخش را یاد گرفتم</button>`;
  }

  function render(section) {
    const renderers = {
      home: renderHome, matter: renderMatter, atom: renderAtom,
      elemcomp: renderElemcomp, molbuild: renderMolbuild,
      metal: renderMetal, carbon: renderCarbon, match: renderMatch,
      evidence: renderEvidence, count: renderCount, element: renderElement,
      challenge: renderChallenge
    };
    (renderers[section] || renderHome)();
  }

  function renderHome() {
    app.innerHTML = `
      <section class="hero">
        <div class="hero-copy">
          <div class="eyebrow light">ماجراجویی علمی پایه هفتم</div>
          <h1>دنیای شگفت‌انگیز<br><span>اتم‌ها</span></h1>
          <p>همه چیز از ذره‌های بسیار ریز ساخته شده است. آماده‌ای به دنیای اتم‌ها سفر کنی؟</p>
          <button class="hero-button" data-section="matter">شروع یادگیری <span>←</span></button>
        </div>
        <div class="atom-art" aria-hidden="true">
          <div class="orbit orbit-one"><i></i></div>
          <div class="orbit orbit-two"><i></i></div>
          <div class="orbit orbit-three"><i></i></div>
          <div class="nucleus"><b>+</b><b>+</b><b>+</b></div>
        </div>
        <div class="hero-stars">✦　·　✧　　·　✦</div>
      </section>
      <div class="welcome-row">
        <div><span class="eyebrow">نقشه راه</span><h2>از مشاهده تا کشف</h2></div>
        <span class="muted">۱۲ بخش برای یادگیری و تمرین</span>
      </div>
      <div class="section-grid">
        ${[
          ["matter","◉","ماده و ذره‌ها","با دنیای ذره‌های سازنده ماده آشنا شو."],
          ["atom","⚛","ساختار اتم","پروتون، نوترون و الکترون را بشناس."],
          ["elemcomp","◇","عنصر یا ترکیب","تفاوت عنصر و ترکیب را کشف کن."],
          ["molbuild","⚗","مولکول‌ساز","اتم‌ها را کنار هم قرار بده."],
          ["metal","▣","فلز و نافلز","ویژگی‌های مواد را مقایسه کن."],
          ["carbon","⬡","شکل‌های کربن","الماس و گرافیت را بررسی کن."],
          ["match","⇄","بازی جورکردنی","هر ماده را به کاربردش وصل کن."],
          ["evidence","〰","شواهد غیرمستقیم","وجود ذره‌ها را از اثرشان بفهم."],
          ["count","∑","شمارش اتم‌ها","فرمول‌های شیمیایی را بخوان."],
          ["element","▦","شناسنامه عنصرها","با چند عنصر مهم آشنا شو."],
          ["challenge","🏆","چالش پایانی","دانسته‌هایت را امتحان کن."]
        ].map(([id, icon, title, desc], i) => `
          <button class="section-card" data-section="${id}">
            <span class="section-icon">${icon}</span>
            <span class="section-number">${fa(i + 1)}</span>
            <strong>${title}</strong><small>${desc}</small><span class="card-arrow">←</span>
          </button>`).join("")}
      </div>
      <div class="tip-strip"><span>💡</span><p><strong>دانشمند کوچک!</strong> در هر بخش، بخوان، آزمایش کن و در پایان دانسته‌هایت را با یک فعالیت کوتاه بررسی کن.</p></div>`;
  }

  function renderMatter() {
    app.innerHTML = header("بخش ۱ · مشاهده و کشف", "ماده و ذره‌ها", "هر چیزی که جرم دارد و فضا اشغال می‌کند، ماده نامیده می‌شود.") + `
      <div class="two-column">
        ${card("ماده از چه ساخته شده است؟", `<p>مواد از ذره‌های بسیار ریزی ساخته شده‌اند. این ذره‌ها آن‌قدر کوچک‌اند که با چشم دیده نمی‌شوند.</p><div class="particle-scene" id="particleScene"><span>●</span><span>●</span><span>●</span><span>●</span><span>●</span><span>●</span><span>●</span><span>●</span><span>●</span><span>●</span></div><button class="secondary-button" data-action="particles">حرکت ذره‌ها را ببین</button>`, "visual-card")}
        ${card("سه حالت آشنای ماده", `<div class="state-list">
          <div><span class="state-icon solid">▦</span><p><b>جامد</b><small>شکل و حجم تقریباً ثابت؛ ذره‌ها نزدیک هم‌اند.</small></p></div>
          <div><span class="state-icon liquid">◉</span><p><b>مایع</b><small>حجم تقریباً ثابت؛ شکل ظرف را می‌گیرد.</small></p></div>
          <div><span class="state-icon gas">✧</span><p><b>گاز</b><small>شکل و حجم ثابت ندارد؛ ذره‌ها پراکنده‌اند.</small></p></div>
        </div>`)}
      </div>
      ${card("آزمایش فکری: عطر در اتاق", `<p>اگر در گوشه‌ای از اتاق عطر اسپری کنیم، پس از مدتی بوی آن را در بخش‌های دیگر اتاق هم حس می‌کنیم. ذره‌های عطر در هوا پخش شده‌اند.</p><div class="experiment-visual"><span class="perfume">♧</span><span class="diffusion-dots">· · · · · · · · · · · ·</span><span class="nose">◡</span></div><p class="muted">این پخش شدن را انتشار می‌نامیم.</p>`)}
      ${card("یک پرسش برای فکر کردن", `<p>چرا بوی عطر پس از مدتی در بخش‌های مختلف اتاق احساس می‌شود؟</p><div class="choice-list" data-quiz="matter"><button data-choice="0">چون ذره‌های عطر در هوا حرکت و پخش می‌شوند.</button><button data-choice="1">چون عطر به ماده دیگری تبدیل می‌شود.</button><button data-choice="2">چون هوا از بین می‌رود.</button></div><div class="feedback" id="matterFeedback"></div>`)}
      ${completeButton("matter")}`;
  }

  function renderAtom() {
    app.innerHTML = header("بخش ۲ · ساختار ماده", "ساختار اتم", "اتم از هسته و ذره‌هایی تشکیل شده است که در اطراف آن قرار دارند.") + `
      <div class="atom-layout">
        ${card("مدل ساده اتم", `<div class="large-atom"><div class="large-orbit o1"></div><div class="large-orbit o2"></div><div class="large-orbit o3"></div><div class="large-nucleus"><b>+</b><b>۰</b><b>+</b><b>۰</b></div><i class="electron e1">−</i><i class="electron e2">−</i><i class="electron e3">−</i></div><p class="muted center">مدل نمایشی و ساده‌شده اتم</p>`, "atom-card")}
        ${card("سه ذره اصلی اتم", `<div class="particle-table">
          <div><span class="particle proton">+</span><b>پروتون</b><span>بار مثبت</span><small>در هسته</small></div>
          <div><span class="particle neutron">۰</span><b>نوترون</b><span>بدون بار</span><small>در هسته</small></div>
          <div><span class="particle electron">−</span><b>الکترون</b><span>بار منفی</span><small>اطراف هسته</small></div>
        </div>`)}
      </div>
      ${card("عدد اتمی چیست؟", `<p>عدد اتمی هر عنصر برابر تعداد پروتون‌های موجود در هسته اتم آن عنصر است. در یک اتم خنثی، تعداد الکترون‌ها و پروتون‌ها برابر است.</p><div class="formula-highlight">عدد اتمی = تعداد پروتون‌ها</div>`)}
      ${card("آزمایش تعاملی: اتم ساده بساز", `<p>تعداد ذره‌ها را تغییر بده و یک اتم خنثی ساده بساز.</p><div class="atom-builder">
        <div class="builder-nucleus"><span id="protonCount">۳</span><small>پروتون</small><span id="neutronCount">۴</span><small>نوترون</small></div>
        <div class="builder-controls">
          <label>پروتون‌ها <input id="protons" type="range" min="1" max="10" value="3"></label>
          <label>الکترون‌ها <input id="electrons" type="range" min="0" max="10" value="3"></label>
          <label>نوترون‌ها <input id="neutrons" type="range" min="0" max="12" value="4"></label>
        </div>
        <div class="builder-result" id="atomResult">اتم خنثی است.</div>
      </div>`)}
      ${completeButton("atom")}`;
    updateAtomBuilder();
  }

  function updateAtomBuilder() {
    const p = $("#protons"), e = $("#electrons"), n = $("#neutrons");
    if (!p) return;
    const update = () => {
      const pv = +p.value, ev = +e.value, nv = +n.value;
      $("#protonCount").textContent = fa(pv);
      $("#neutronCount").textContent = fa(nv);
      $("#atomResult").textContent = pv === ev ? "✓ اتم خنثی است؛ تعداد پروتون‌ها و الکترون‌ها برابر است." :
        pv > ev ? "بار کلی مثبت است؛ پروتون‌ها بیشترند." : "بار کلی منفی است؛ الکترون‌ها بیشترند.";
      $("#atomResult").className = "builder-result " + (pv === ev ? "success-text" : "warning-text");
    };
    [p, e, n].forEach(el => el.addEventListener("input", update));
    update();
  }

  function renderElemcomp() {
    app.innerHTML = header("بخش ۳ · دسته‌بندی مواد", "عنصر یا ترکیب؟", "مواد را می‌توان بر اساس نوع اتم‌های سازنده آن‌ها دسته‌بندی کرد.") + `
      <div class="compare-grid">
        ${card("عنصر", `<div class="mini-molecules"><i class="same"></i><i class="same"></i><i class="same"></i></div><p>ماده‌ای که از یک نوع اتم ساخته شده باشد.</p><div class="example-chips"><span>آهن Fe</span><span>اکسیژن O₂</span><span>طلا Au</span></div>`)}
        ${card("ترکیب", `<div class="mini-molecules mixed"><i></i><i></i><i></i><i></i></div><p>ماده‌ای که از پیوند شیمیایی دو یا چند نوع اتم متفاوت تشکیل شده باشد.</p><div class="example-chips"><span>آب H₂O</span><span>CO₂</span><span>نمک NaCl</span></div>`)}
      </div>
      ${card("تفاوت را به خاطر بسپار", `<ul class="fact-list"><li>در عنصر، همه اتم‌ها از یک نوع‌اند.</li><li>در ترکیب، دست‌کم دو نوع اتم با نسبت مشخص به هم پیوند دارند.</li><li>خواص ترکیب می‌تواند با خواص عنصرهای سازنده آن متفاوت باشد.</li></ul>`)}
      ${card("خودت را امتحان کن", `<p>هر مورد را به دسته درست منتقل کن.</p><div class="sort-game"><div class="sort-items" id="sortItems">
        <button data-kind="element">آهن</button><button data-kind="compound">آب</button><button data-kind="element">طلا</button><button data-kind="compound">کربن‌دی‌اکسید</button><button data-kind="element">اکسیژن</button><button data-kind="compound">نمک خوراکی</button>
      </div><div class="sort-targets"><div class="sort-target" data-target="element"><b>عنصر</b><div class="dropped"></div></div><div class="sort-target" data-target="compound"><b>ترکیب</b><div class="dropped"></div></div></div><div class="feedback" id="sortFeedback"></div></div>`)}
      ${completeButton("elemcomp")}`;
  }

  function renderMolbuild() {
    app.innerHTML = header("بخش ۴ · کارگاه ساخت مولکول", "مولکول‌ساز", "با انتخاب اتم‌ها، یک مدل ساده از مولکول بساز.") + `
      ${card("اتم‌های مورد نیاز را انتخاب کن", `<div class="atom-palette">
        ${Object.entries(atomData).map(([symbol, data]) => `<button class="atom-choice" data-atom="${symbol}" style="--atom-color:${data.color}"><i>${symbol}</i><span>${data.name}</span></button>`).join("")}
      </div><div class="molecule-workbench"><div class="workbench-title">فضای ساخت مولکول</div><div class="molecule-atoms" id="moleculeAtoms"><span class="empty-state">برای افزودن اتم، روی یکی از گزینه‌های بالا بزن.</span></div></div>
      <div class="molecule-actions"><button class="secondary-button" data-action="undoAtom">حذف آخرین اتم</button><button class="secondary-button" data-action="clearMolecule">پاک کردن همه</button><button class="primary-button" data-action="inspectMolecule">بررسی مولکول</button></div><div class="feedback" id="moleculeFeedback"></div>`)}
      ${card("چند مولکول آشنا", `<div class="molecule-examples"><button data-formula="H2O"><b>H₂O</b><span>آب</span></button><button data-formula="CO2"><b>CO₂</b><span>کربن‌دی‌اکسید</span></button><button data-formula="CH4"><b>CH₄</b><span>متان</span></button></div>`)}
      <p class="note">این فعالیت برای شناخت فرمول و تعداد اتم‌هاست؛ نمایش پیوندها و شکل مولکول‌ها در این مدل ساده‌شده است.</p>
      ${completeButton("molbuild")}`;
    window.molecule = [];
    drawMolecule();
  }

  function drawMolecule() {
    const host = $("#moleculeAtoms");
    if (!host) return;
    if (!window.molecule.length) {
      host.innerHTML = '<span class="empty-state">برای افزودن اتم، روی یکی از گزینه‌های بالا بزن.</span>';
      return;
    }
    host.innerHTML = window.molecule.map((s, i) => `<span class="molecule-bubble" style="--atom-color:${atomData[s].color}">${s}<small>${fa(i + 1)}</small></span>`).join("");
  }

  function renderMetal() {
    app.innerHTML = header("بخش ۵ · مقایسه مواد", "فلز و نافلز", "فلزها و نافلزها ویژگی‌های متفاوتی دارند؛ البته همه مواد یکسان نیستند.") + `
      <div class="compare-grid">
        ${card("فلزها", `<div class="material-art metal-art">▧</div><ul class="fact-list"><li>بیشتر آن‌ها جلای فلزی دارند.</li><li>بسیاری از آن‌ها رسانای گرما و برق‌اند.</li><li>بیشتر فلزها در دمای اتاق جامدند.</li><li>بسیاری از آن‌ها چکش‌خوار و مفتول‌پذیرند.</li></ul><div class="example-chips"><span>آهن</span><span>مس</span><span>آلومینیم</span></div>`)}
        ${card("نافلزها", `<div class="material-art nonmetal-art">✧</div><ul class="fact-list"><li>معمولاً جلای فلزی ندارند.</li><li>بسیاری از آن‌ها رسانایی کمی دارند.</li><li>در حالت‌های جامد، مایع و گاز یافت می‌شوند.</li><li>برخی نافلزهای جامد شکننده‌اند.</li></ul><div class="example-chips"><span>اکسیژن</span><span>گوگرد</span><span>کربن</span></div>`)}
      </div>
      ${card("آزمون تشخیص", `<p>کدام ویژگی بیشتر با فلزها سازگار است؟</p><div class="choice-list" data-quiz="metal"><button data-choice="0">رسانایی خوب الکتریکی</button><button data-choice="1">همیشه گاز بودن</button><button data-choice="2">شکننده بودن همه آن‌ها</button></div><div class="feedback" id="metalFeedback"></div>`)}
      <div class="tip-strip"><span>⚠️</span><p>ویژگی‌ها کلی هستند و استثنا وجود دارد؛ برای مثال جیوه فلزی مایع در دمای اتاق است.</p></div>
      ${completeButton("metal")}`;
  }

  function renderCarbon() {
    app.innerHTML = header("بخش ۶ · یک عنصر، چند ساختار", "شکل‌های گوناگون کربن", "اتم‌های کربن می‌توانند با آرایش‌های متفاوت، موادی با ویژگی‌های متفاوت بسازند.") + `
      <div class="carbon-grid">
        <article class="carbon-card"><div class="carbon-visual diamond">◇</div><h3>الماس</h3><p>اتم‌های کربن در شبکه‌ای محکم به هم متصل‌اند. الماس بسیار سخت است.</p><span class="tag">بسیار سخت</span></article>
        <article class="carbon-card"><div class="carbon-visual graphite">▤</div><h3>گرافیت</h3><p>اتم‌های کربن در لایه‌هایی قرار دارند که می‌توانند روی هم بلغزند.</p><span class="tag">نرم و لایه‌ای</span></article>
        <article class="carbon-card"><div class="carbon-visual fullerene">⬡</div><h3>فولرن</h3><p>در برخی شکل‌های فولرن، اتم‌های کربن ساختارهای قفس‌مانند می‌سازند.</p><span class="tag">ساختار قفس‌مانند</span></article>
      </div>
      ${card("چرا خواص آن‌ها متفاوت است؟", `<p>در هر یک از این شکل‌ها، اتم‌های کربن به روش متفاوتی کنار هم قرار گرفته‌اند. تفاوت در آرایش اتم‌ها باعث تفاوت در ویژگی‌های ماده می‌شود.</p><div class="formula-highlight">یک عنصر + آرایش متفاوت اتم‌ها = ویژگی‌های متفاوت</div>`)}
      ${card("پرسش", `<p>کدام شکل کربن به دلیل ساختار لایه‌ای در نوک مداد کاربرد دارد؟</p><div class="choice-list" data-quiz="carbon"><button data-choice="0">الماس</button><button data-choice="1">گرافیت</button><button data-choice="2">فولرن</button></div><div class="feedback" id="carbonFeedback"></div>`)}
      ${completeButton("carbon")}`;
  }

  const matchPairs = [
    ["اکسیژن", "تنفس جانداران"], ["آهن", "ساخت ابزار و سازه"],
    ["گرافیت", "مغز مداد"], ["آلومینیم", "قوطی و فویل"],
    ["هلیم", "بالن"], ["سیلیسیم", "تراشه الکترونیکی"]
  ];

  function renderMatch() {
    matchSelected = null;
    matchFound = new Set();
    const left = matchPairs.map((p, i) => ({ text: p[0], id: i })).sort(() => Math.random() - .5);
    const right = matchPairs.map((p, i) => ({ text: p[1], id: i })).sort(() => Math.random() - .5);
    app.innerHTML = header("بخش ۷ · بازی آموزشی", "بازی جورکردنی", "هر ماده را به کاربرد یا ویژگی مناسب آن وصل کن.") + `
      ${card("دو ستون را با هم جور کن", `<div class="match-board"><div class="match-column"><h3>ماده</h3>${left.map(x => `<button class="match-tile" data-match-side="left" data-match-id="${x.id}">${x.text}</button>`).join("")}</div><div class="match-column"><h3>کاربرد</h3>${right.map(x => `<button class="match-tile" data-match-side="right" data-match-id="${x.id}">${x.text}</button>`).join("")}</div></div><div class="match-status" id="matchStatus">هنوز هیچ موردی جور نشده است.</div><button class="secondary-button" data-action="resetMatch">شروع دوباره</button>`)}
      ${completeButton("match")}`;
  }

  function renderEvidence() {
    evidenceIndex = 0;
    evidenceAnswers = {};
    const questions = [
      { title: "پخش شدن عطر", text: "در یک سمت اتاق عطر اسپری می‌کنیم. کمی بعد، فردی در سمت دیگر اتاق نیز بوی عطر را احساس می‌کند.", q: "این مشاهده چه چیزی را نشان می‌دهد؟", options: ["ذره‌های عطر در هوا پخش می‌شوند.", "ذره‌های عطر ناپدید می‌شوند.", "هوا از حرکت می‌ایستد."], correct: 0, why: "پخش شدن بو نشانه حرکت و پراکنده شدن ذره‌های عطر در هواست." },
      { title: "حل شدن رنگ در آب", text: "یک قطره رنگ خوراکی را در آب می‌ریزیم. پس از مدتی رنگ در سراسر آب پخش می‌شود.", q: "کدام توضیح مناسب‌تر است؟", options: ["ذره‌های رنگ در آب پخش شده‌اند.", "آب به رنگ جامد تبدیل شده است.", "قطره رنگ بزرگ‌تر شده است."], correct: 0, why: "ذره‌های ماده می‌توانند در مایع پخش شوند؛ حتی اگر خود ذره‌ها دیده نشوند." },
      { title: "فشرده کردن هوا", text: "وقتی هوای داخل سرنگِ بسته را فشار می‌دهیم، حجم آن کمتر می‌شود.", q: "این آزمایش درباره ذره‌های گاز چه می‌گوید؟", options: ["ذره‌ها هیچ فاصله‌ای ندارند.", "بین ذره‌های گاز فضای خالی وجود دارد.", "ذره‌ها از بین می‌روند."], correct: 1, why: "با نزدیک‌تر شدن ذره‌ها، حجم گاز کاهش می‌یابد؛ پس میان آن‌ها فاصله وجود دارد." }
    ];
    window.evidenceQuestions = questions;
    showEvidenceQuestion();
    app.innerHTML = header("بخش ۸ · از اثر به علت", "شواهد غیرمستقیم", "گاهی چیزی را مستقیم نمی‌بینیم، اما از اثرهای آن به وجودش پی می‌بریم.") + `
      ${card("مشاهده و نتیجه‌گیری", `<div id="evidenceContent"></div><div class="evidence-progress" id="evidenceProgress"></div><div class="feedback" id="evidenceFeedback"></div><div class="button-row"><button class="secondary-button" id="evidenceNext" disabled>مورد بعدی ←</button></div>`)}
      <div class="tip-strip"><span>🔎</span><p>در علم، مشاهده دقیق و نتیجه‌گیری بر اساس شواهد اهمیت زیادی دارد.</p></div>
      ${completeButton("evidence")}`;
    showEvidenceQuestion();
  }

  function showEvidenceQuestion() {
    const host = $("#evidenceContent");
    if (!host) return;
    const q = window.evidenceQuestions[evidenceIndex];
    host.innerHTML = `<div class="evidence-count">مشاهده ${fa(evidenceIndex + 1)} از ۳</div><h3>${q.title}</h3><div class="observation-box">${q.text}</div><p><strong>${q.q}</strong></p><div class="choice-list" id="evidenceChoices">${q.options.map((o, i) => `<button data-evidence-choice="${i}">${o}</button>`).join("")}</div>`;
    $("#evidenceProgress").innerHTML = window.evidenceQuestions.map((_, i) => `<i class="${i <= evidenceIndex ? "active" : ""}"></i>`).join("");
    $("#evidenceFeedback").textContent = "";
    $("#evidenceNext").disabled = true;
    $("#evidenceNext").textContent = evidenceIndex === 2 ? "پایان فعالیت" : "مورد بعدی ←";
  }

  function renderCount() {
    app.innerHTML = header("بخش ۹ · خواندن فرمول", "شمارش اتم‌ها", "عدد کوچک کنار نماد عنصر، تعداد اتم‌های آن عنصر را در فرمول نشان می‌دهد.") + `
      ${card("نمونه: مولکول آب", `<div class="formula-large">H<sub>2</sub>O</div><p>در این فرمول، دو اتم هیدروژن و یک اتم اکسیژن وجود دارد؛ پس مجموعاً سه اتم داریم.</p>`)}
      ${card("تمرین شمارش اتم‌ها", `<p>یک فرمول را انتخاب کن و تعداد اتم‌های هر عنصر را وارد کن.</p><div class="formula-selector">${Object.entries(formulas).map(([key, f]) => `<button data-count-formula="${key}">${key.replace(/(\d)/g, "<sub>$1</sub>")}<small>${f.name}</small></button>`).join("")}</div><div id="countExercise" class="count-exercise"><span class="muted">برای شروع یکی از فرمول‌ها را انتخاب کن.</span></div><div class="feedback" id="countFeedback"></div>`)}
      ${card("نکته مهم", `<p>اگر کنار نماد عنصر عددی نوشته نشده باشد، تعداد آن عنصر یک اتم است. عدد پایین فقط به نماد پیش از خودش مربوط می‌شود.</p>`)}
      ${completeButton("count")}`;
  }

  let currentFormula = null;
  function showCountExercise(key) {
    currentFormula = key;
    const f = formulas[key];
    const inputs = Object.keys(f.atoms).map(symbol => `<label>${symbol} (${atomData[symbol].name})<input type="number" min="0" max="20" id="count-${symbol}" placeholder="تعداد"></label>`).join("");
    $("#countExercise").innerHTML = `<div class="selected-formula"><strong>${key.replace(/(\d)/g, "<sub>$1</sub>")}</strong><span>${f.name}</span></div><div class="count-inputs">${inputs}<label>مجموع اتم‌ها<input type="number" min="0" max="30" id="count-total" placeholder="مجموع"></label></div><button class="primary-button" data-action="checkCount">بررسی پاسخ</button>`;
    $("#countFeedback").textContent = "";
  }

  function renderElement() {
    app.innerHTML = header("بخش ۱۰ · آشنایی با عنصرها", "شناسنامه عنصرها", "هر عنصر نام، نماد و عدد اتمی مخصوص به خود را دارد.") + `
      ${card("جدول عنصرهای منتخب", `<p>روی هر خانه بزن تا شناسنامه آن عنصر را ببینی.</p><div class="element-grid">${elements.map(el => `<button class="element-tile ${el.category === "فلز" ? "is-metal" : el.category === "شبه‌فلز" ? "is-metalloid" : ""}" data-element="${el.symbol}"><span>${fa(el.number)}</span><b>${el.symbol}</b><small>${el.name}</small></button>`).join("")}</div>`)}
      <div class="element-detail card" id="elementDetail"><span class="muted">یک عنصر را انتخاب کن.</span></div>
      ${card("چگونه شناسنامه را بخوانیم؟", `<ul class="fact-list"><li><b>نماد:</b> نمایش کوتاه نام عنصر است.</li><li><b>عدد اتمی:</b> تعداد پروتون‌های هسته را نشان می‌دهد.</li><li><b>دسته‌بندی:</b> عنصر می‌تواند فلز، نافلز یا شبه‌فلز باشد.</li></ul>`)}
      ${completeButton("element")}`;
  }

  function renderChallenge() {
    challengeQuestions = [...quizBank].sort(() => Math.random() - .5).slice(0, 20);
    challengeIndex = 0;
    challengeScore = 0;
    challengeAnswered = false;
    app.innerHTML = header("بخش ۱۱ · سنجش آموخته‌ها", "چالش پایانی", "۲۰ پرسش از فصل اتم‌ها؛ با دقت پاسخ بده و نتیجه‌ات را ببین.") + `
      <div class="quiz-shell card" id="challengeQuiz">
        <div class="quiz-top"><span id="quizCounter">پرسش ۱ از ۲۰</span><span id="quizScore">امتیاز: ۰</span></div>
        <div class="quiz-progress"><i id="quizProgress"></i></div>
        <div id="quizQuestion"></div>
        <div class="feedback" id="quizFeedback"></div>
        <div class="quiz-bottom"><button class="primary-button" id="quizNext" disabled>پرسش بعدی ←</button></div>
      </div>`;
    showChallengeQuestion();
  }

  function showChallengeQuestion() {
    const q = challengeQuestions[challengeIndex];
    challengeAnswered = false;
    $("#quizCounter").textContent = `پرسش ${fa(challengeIndex + 1)} از ۲۰`;
    $("#quizScore").textContent = `امتیاز: ${fa(challengeScore)}`;
    $("#quizProgress").style.width = `${(challengeIndex / 20) * 100}%`;
    $("#quizQuestion").innerHTML = `<h2>${q.q}</h2><div class="quiz-options">${q.a.map((a, i) => `<button data-challenge-choice="${i}"><span>${"الفبج"[i]}</span>${a}</button>`).join("")}</div>`;
    $("#quizFeedback").textContent = "";
    $("#quizNext").disabled = true;
    $("#quizNext").textContent = challengeIndex === 19 ? "دیدن نتیجه" : "پرسش بعدی ←";
  }

  function finishChallenge() {
    $("#challengeQuiz").innerHTML = `<div class="result-screen"><div class="trophy">🏆</div><div class="eyebrow">نتیجه چالش</div><h2>${fa(challengeScore)} از ۲۰ پاسخ درست</h2><div class="result-ring">${fa(Math.round(challengeScore / 20 * 100))}<small>درصد</small></div><p>${challengeScore >= 17 ? "فوق‌العاده! به دنیای اتم‌ها مسلط شده‌ای." : challengeScore >= 12 ? "آفرین! با کمی مرور بهتر هم می‌شوی." : "تلاش خوبی بود! بخش‌ها را دوباره مرور کن و باز امتحان بده."}</p><button class="primary-button" data-action="restartChallenge">آزمون دوباره</button><button class="secondary-button" data-section="home">بازگشت به خانه</button></div>`;
    markComplete("challenge");
  }

  function checkChoice(group, index) {
    const configs = {
      matter: { correct: 0, feedback: "#matterFeedback", yes: "آفرین! ذره‌های عطر در هوا حرکت می‌کنند و پخش می‌شوند.", no: "دوباره فکر کن؛ بوی عطر چگونه به بخش‌های دیگر اتاق می‌رسد؟" },
      metal: { correct: 0, feedback: "#metalFeedback", yes: "درست است! فلزها معمولاً رسانای خوب برق هستند.", no: "به یکی از ویژگی‌های مهم فلزها فکر کن: رسانایی." },
      carbon: { correct: 1, feedback: "#carbonFeedback", yes: "آفرین! گرافیت ساختار لایه‌ای دارد.", no: "پاسخ درست گرافیت است؛ لایه‌های آن می‌توانند روی هم بلغزند." }
    };
    const c = configs[group];
    const host = $(`[data-quiz="${group}"]`);
    if (!host || host.dataset.answered) return;
    host.dataset.answered = "true";
    $$("button", host).forEach((b, i) => {
      b.disabled = true;
      if (i === c.correct) b.classList.add("correct");
      else if (i === index) b.classList.add("incorrect");
    });
    $(c.feedback).textContent = index === c.correct ? c.yes : c.no;
    $(c.feedback).className = "feedback " + (index === c.correct ? "success-text" : "warning-text");
  }

  function selectElement(symbol) {
    const el = elements.find(x => x.symbol === symbol);
    if (!el) return;
    $("#elementDetail").innerHTML = `<div class="detail-symbol">${el.symbol}</div><div class="detail-info"><div class="eyebrow">شناسنامه عنصر</div><h2>${el.name}</h2><p>عدد اتمی: <strong>${fa(el.number)}</strong></p><p>دسته: <strong>${el.category}</strong></p><p>کاربرد: ${el.use}</p></div>`;
    $$(".element-tile").forEach(b => b.classList.toggle("selected", b.dataset.element === symbol));
  }

  function chooseMatch(button) {
    if (button.classList.contains("matched")) return;
    const side = button.dataset.matchSide;
    const id = button.dataset.matchId;
    if (!matchSelected) {
      matchSelected = { side, id, button };
      button.classList.add("selected");
      return;
    }
    if (matchSelected.side === side) {
      matchSelected.button.classList.remove("selected");
      matchSelected = { side, id, button };
      button.classList.add("selected");
      return;
    }
    const first = matchSelected;
    first.button.classList.remove("selected");
    matchSelected = null;
    if (first.id === id) {
      first.button.classList.add("matched");
      button.classList.add("matched");
      matchFound.add(id);
      $("#matchStatus").textContent = `آفرین! ${fa(matchFound.size)} مورد از ۶ مورد درست جور شد.`;
      if (matchFound.size === 6) {
        $("#matchStatus").textContent = "🎉 عالی! همه موارد را درست جور کردی.";
        markComplete("match");
      }
    } else {
      button.classList.add("incorrect");
      first.button.classList.add("incorrect");
      setTimeout(() => {
        button.classList.remove("incorrect");
        first.button.classList.remove("incorrect");
      }, 650);
      $("#matchStatus").textContent = "این دو مورد با هم جور نیستند؛ دوباره تلاش کن.";
    }
  }

  function checkCount() {
    if (!currentFormula) return;
    const f = formulas[currentFormula];
    let correct = true;
    let sum = 0;
    Object.entries(f.atoms).forEach(([symbol, count]) => {
      const input = $(`#count-${symbol}`);
      const value = input.value.trim() === "" ? NaN : Number(input.value);
      if (value !== count) correct = false;
      sum += count;
    });
    const total = $("#count-total").value.trim() === "" ? NaN : Number($("#count-total").value);
    if (total !== sum) correct = false;
    $("#countFeedback").textContent = correct
      ? `✓ آفرین! ${f.note}؛ در مجموع ${fa(sum)} اتم وجود دارد.`
      : `هنوز درست نیست. راهنمایی: ${f.note}؛ مجموع اتم‌ها ${fa(sum)} است.`;
    $("#countFeedback").className = "feedback " + (correct ? "success-text" : "warning-text");
    if (correct) markComplete("count");
  }

  function handleAction(action) {
    if (action === "particles") {
      $("#particleScene")?.classList.toggle("moving");
    } else if (action === "undoAtom") {
      window.molecule?.pop(); drawMolecule();
    } else if (action === "clearMolecule") {
      window.molecule = []; drawMolecule(); $("#moleculeFeedback").textContent = "";
    } else if (action === "inspectMolecule") {
      const counts = {};
      (window.molecule || []).forEach(s => counts[s] = (counts[s] || 0) + 1);
      const description = Object.entries(counts).map(([s, n]) => `${fa(n)} اتم ${atomData[s].name}`).join("، ");
      $("#moleculeFeedback").textContent = window.molecule.length ? `در مدل تو ${description} وجود دارد؛ مجموعاً ${fa(window.molecule.length)} اتم.` : "هنوز اتمی انتخاب نکرده‌ای.";
    } else if (action === "resetMatch") {
      renderMatch();
    } else if (action === "checkCount") {
      checkCount();
    } else if (action === "restartChallenge") {
      renderChallenge();
    }
  }

  function loadFormula(key) {
    if (!formulas[key]) return;
    window.molecule = [];
    Object.entries(formulas[key].atoms).forEach(([symbol, count]) => {
      for (let i = 0; i < count; i++) window.molecule.push(symbol);
    });
    drawMolecule();
    $("#moleculeFeedback").textContent = `${formulas[key].name}: ${formulas[key].note}.`;
  }

  document.addEventListener("click", event => {
    const sectionButton = event.target.closest("[data-section]");
    if (sectionButton) {
      go(sectionButton.dataset.section);
      return;
    }

    const complete = event.target.closest("[data-complete]");
    if (complete) {
      markComplete(complete.dataset.complete);
      complete.textContent = "✓ این بخش را یاد گرفته‌ای";
      complete.classList.add("is-complete");
      return;
    }

    const action = event.target.closest("[data-action]");
    if (action) {
      handleAction(action.dataset.action);
      return;
    }

    const quiz = event.target.closest("[data-quiz] button");
    if (quiz) {
      checkChoice(quiz.closest("[data-quiz]").dataset.quiz, Number(quiz.dataset.choice));
      return;
    }

    const atom = event.target.closest("[data-atom]");
    if (atom) {
      window.molecule = window.molecule || [];
      window.molecule.push(atom.dataset.atom);
      drawMolecule();
      return;
    }

    const formula = event.target.closest("[data-formula]");
    if (formula) {
      loadFormula(formula.dataset.formula);
      return;
    }

    const match = event.target.closest("[data-match-side]");
    if (match) {
      chooseMatch(match);
      return;
    }

    const evidence = event.target.closest("[data-evidence-choice]");
    if (evidence) {
      const q = window.evidenceQuestions[evidenceIndex];
      const choice = Number(evidence.dataset.evidenceChoice);
      if (evidenceAnswers[evidenceIndex] !== undefined) return;
      evidenceAnswers[evidenceIndex] = choice;
      $$("button", $("#evidenceChoices")).forEach((b, i) => {
        b.disabled = true;
        if (i === q.correct) b.classList.add("correct");
        if (i === choice && choice !== q.correct) b.classList.add("incorrect");
      });
      $("#evidenceFeedback").textContent = choice === q.correct ? `✓ درست است! ${q.why}` : `پاسخ درست: ${q.options[q.correct]} ${q.why}`;
      $("#evidenceFeedback").className = "feedback " + (choice === q.correct ? "success-text" : "warning-text");
      $("#evidenceNext").disabled = false;
      return;
    }

    const countFormula = event.target.closest("[data-count-formula]");
    if (countFormula) {
      showCountExercise(countFormula.dataset.countFormula);
      return;
    }

    const element = event.target.closest("[data-element]");
    if (element) {
      selectElement(element.dataset.element);
      return;
    }

    const challengeChoice = event.target.closest("[data-challenge-choice]");
    if (challengeChoice) {
      if (challengeAnswered) return;
      challengeAnswered = true;
      const q = challengeQuestions[challengeIndex];
      const choice = Number(challengeChoice.dataset.challengeChoice);
      if (choice === q.correct) challengeScore++;
      $$("[data-challenge-choice]").forEach((b, i) => {
        b.disabled = true;
        if (i === q.correct) b.classList.add("correct");
        if (i === choice && choice !== q.correct) b.classList.add("incorrect");
      });
      $("#quizScore").textContent = `امتیاز: ${fa(challengeScore)}`;
      $("#quizFeedback").textContent = `${choice === q.correct ? "آفرین، درست است!" : "پاسخ درست: " + q.a[q.correct] + "."} ${q.why}`;
      $("#quizFeedback").className = "feedback " + (choice === q.correct ? "success-text" : "warning-text");
      $("#quizNext").disabled = false;
      return;
    }

    const sortItem = event.target.closest("#sortItems button");
    if (sortItem) {
      const target = sortItem.dataset.kind;
      const zone = $(`.sort-target[data-target="${target}"] .dropped`);
      zone.append(sortItem);
      sortItem.disabled = true;
      sortItem.classList.add("sorted");
      const remaining = $$("#sortItems button:not(:disabled)");
      if (!remaining.length) {
        $("#sortFeedback").textContent = "آفرین! همه مواد را دسته‌بندی کردی.";
        $("#sortFeedback").className = "feedback success-text";
        markComplete("elemcomp");
      }
    }
  });

  document.addEventListener("change", event => {
    if (event.target.id === "mobileNavigation") go(event.target.value);
  });

  document.addEventListener("click", event => {
    if (event.target.id === "evidenceNext") {
      if (evidenceIndex < 2) {
        evidenceIndex++;
        showEvidenceQuestion();
      } else {
        $("#evidenceContent").innerHTML = `<div class="result-screen"><div class="trophy">🔎</div><h2>فعالیت تمام شد!</h2><p>تو سه نمونه از شواهد غیرمستقیم را بررسی کردی.</p></div>`;
        $("#evidenceNext").disabled = true;
        markComplete("evidence");
      }
    }
    if (event.target.id === "quizNext") {
      if (!challengeAnswered) return;
      if (challengeIndex < 19) {
        challengeIndex++;
        showChallengeQuestion();
      } else {
        finishChallenge();
      }
    }
  });

  document.addEventListener("click", event => {
    if (event.target.id === "soundButton") {
      soundOn = !soundOn;
      event.target.textContent = soundOn ? "🔊" : "🔇";
      event.target.title = soundOn ? "صدای رابط روشن" : "صدای رابط خاموش";
    }
  });

  updateProgress();
  go("home");
})(); 
