(function () {
'use strict';
var D = {"tools": [["خط‌کش", "اندازه‌گیری طول", "سانتی‌متر", 0, 0], ["کولیس", "اندازه‌گیری دقیق طول", "میلی‌متر", 1, 0], ["ریزسنج", "اندازه‌گیری قطر دقیق", "میلی‌متر (۰.۰۱)", 2, 0], ["ترازو", "اندازه‌گیری جرم", "گرم / کیلوگرم", 3, 1], ["نیروسنج", "اندازه‌گیری وزن", "نیوتن", 4, 2], ["استوانه مدرج", "اندازه‌گیری حجم مایع", "میلی‌لیتر", 5, 3], ["پی‌پت", "برداشتن حجم دقیق", "میلی‌لیتر", 6, 3], ["دماسنج", "اندازه‌گیری دما", "درجه سلسیوس", 7, 4]], "mtools": [["خط‌کش", "cm", 1, 15, 0.1, 0.5, 1], ["کولیس", "mm", 5, 25, 0.1, 0.5, 1], ["ریزسنج", "mm", 0.1, 2.5, 0.01, 0.05, 2], ["ترازو", "g", 10, 500, 0.1, 2, 1], ["نیروسنج", "N", 0.5, 20, 0.1, 0.2, 1], ["استوانه مدرج", "ml", 10, 100, 1, 3, 0], ["پی‌پت", "ml", 1, 10, 0.1, 0.3, 1], ["دماسنج", "°C", -10, 60, 1, 1, 0], ["متر نواری", "cm", 50, 500, 1, 2, 0], ["کرنومتر", "s", 1, 30, 0.1, 0.2, 2]], "masses": [0.1, 0.5, 1, 5], "massLabels": ["۱۰۰ گرم", "۵۰۰ گرم", "۱ کیلوگرم", "۵ کیلوگرم"], "planets": [["زمین", 9.8, [60, 140, 220, 255]], ["ماه", 1.6, [180, 180, 180, 255]], ["مریخ", 3.7, [200, 100, 60, 255]], ["مشتری", 24.8, [200, 160, 100, 255]]], "mats": [["چوب", 0.6, [160, 110, 60, 255]], ["یخ", 0.9, [190, 225, 240, 255]], ["پلاستیک", 0.95, [110, 180, 220, 255]], ["آلومینیوم", 2.7, [180, 180, 190, 255]], ["آهن", 7.8, [80, 80, 90, 255]], ["طلا", 19.3, [220, 180, 50, 255]]], "quiz": [["کدام یک از موارد زیر «کمیت» است؟", ["خط‌کش", "طول", "اندازه‌گیری", "متر"], 1], ["یکای جرم در SI چیست؟", ["نیوتن", "کیلوگرم", "متر", "لیتر"], 1], ["وزن یک جسم روی ماه نسبت به زمین چگونه است؟", ["بیشتر", "کمتر", "یکسان", "صفر"], 1], ["یکای وزن در SI چیست؟", ["کیلوگرم", "نیوتن", "گرم", "ژول"], 1], ["حجم مایع با کدام ابزار اندازه‌گیری می‌شود؟", ["ترازو", "خط‌کش", "استوانه مدرج", "دماسنج"], 2], ["چگالی آب چند گرم بر سانتی‌متر مکعب است؟", ["0.5", "1.0", "7.8", "19.3"], 1], ["جسمی با چگالی ۰.۸ در آب چه می‌کند؟", ["غرق می‌شود", "شناور می‌ماند", "محو می‌شود", "منفجر می‌شود"], 1], ["دقت خط‌کش معمولی چقدر است؟", ["۱ سانتی‌متر", "۱ میلی‌متر", "۰.۰۱ میلی‌متر", "۱ متر"], 1], ["کدام یک از ابزارهای دقیق اندازه‌گیری طول است؟", ["خط‌کش", "متر نواری", "ریزسنج", "پارچه‌ای"], 2], ["هنگام خواندن استوانه مدرج به چه چیزی باید دقت کرد؟", ["رنگ مایع", "هلال سطح مایع", "دمای اتاق", "ارتفاع استوانه"], 1], ["جرم ۵۰۰ گرم روی زمین، وزنش تقریباً چند نیوتن است؟", ["۰.۵", "۵", "۵۰", "۵۰۰"], 1], ["کدام مورد خطای اندازه‌گیری نیست؟", ["خطای ابزار", "خطای خواندن", "خطای انسانی", "خطای محاسبه ذهنی"], 3], ["دماسنج برای اندازه‌گیری چه کمیتی است؟", ["جرم", "طول", "دما", "حجم"], 2], ["چگالی آهن تقریباً چند برابر آب است؟", ["همان اندازه", "دو برابر", "حدود ۸ برابر", "حدود ۲۰ برابر"], 2], ["کدام کمیت با نیروسنج اندازه‌گیری می‌شود؟", ["جرم", "وزن", "حجم", "طول"], 1], ["واحد میلی‌لیتر برای اندازه‌گیری چه چیزی است؟", ["جرم", "طول", "حجم", "زمان"], 2]]};
var FAD = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
function toFa(n) { return String(n).replace(/\d/g, function (c) { return FAD[+c]; }); }
function fmt(v, d) { return toFa(Number(v).toFixed(d)).replace('.', '٫'); }
function parseNum(s) {
  s = String(s).replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 1776); })
    .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); })
    .replace(/[٫،,]/g, '.').replace(/[−–]/g, '-');
  var v = parseFloat(s);
  return isNaN(v) ? null : v;
}
function shuffle(a) {
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}
function faText(s) { return String(s).replace(/\b\d+(?:\.\d+)?\b/g, function (m) { return toFa(m).replace('.', '٫'); }); }
function rnd(n) { return Math.floor(Math.random() * n); }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}
function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); }
function btn(text, cls, fn) {
  var b = el('button', 'btn-sm' + (cls ? ' ' + cls : ''), text);
  b.type = 'button';
  if (fn) b.addEventListener('click', fn);
  return b;
}
function css(c) { return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; }
function subHtml(f) { return f.replace(/(\d+)/g, function (m) { return '<sub>' + toFa(m) + '</sub>'; }); }
var dead = false, timeouts = [], docHandlers = [];
function later(fn, ms) { var t = setTimeout(fn, ms); timeouts.push(t); return t; }
function onDoc(type, fn, opts) { document.addEventListener(type, fn, opts); docHandlers.push([type, fn, opts]); }
function loop(fn) {
  var last = 0;
  function tick(t) {
    if (dead) return;
    var dt = last ? Math.min(0.05, (t - last) / 1000) : 0.016;
    last = t;
    try { fn(dt, t); } catch (e) { console.error(e); }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}
function visible(n) { return !!(n && n.offsetParent !== null); }
function showError(root, e) {
  var d = el('div', 'err-box', 'خطا: ' + (e && e.message ? e.message : e));
  root.insertBefore(d, root.firstChild);
}
function confettiBurst() {
  var colors = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
  for (var i = 0; i < 80; i++) {
    var p = document.createElement('div');
    p.className = 'confetti-piece';
    p.style.left = (30 + Math.random() * 40) + '%';
    p.style.background = colors[Math.floor(Math.random() * colors.length)];
    p.style.animationDelay = (Math.random() * 0.3) + 's';
    document.body.appendChild(p);
    setTimeout(function (node) { return function () { if (node.parentNode) node.parentNode.removeChild(node); }; }(p), 3500);
  }
}
function secOf(root, type, renderer) {
  var ss = root.querySelectorAll('section');
  for (var i = 0; i < ss.length; i++) {
    if (ss[i].getAttribute('data-type') === type && (!renderer || ss[i].getAttribute('data-renderer') === renderer)) return ss[i];
  }
  return null;
}
function buildHome(root, cards) {
  var g = root.querySelector('#home-grid');
  if (!g) throw new Error('home-grid not found');
  clear(g);
  cards.forEach(function (c) {
    var b = el('button', 'home-card');
    b.type = 'button';
    b.appendChild(el('span', 'icon', c.icon));
    b.appendChild(document.createTextNode(c.label));
    b.addEventListener('click', function () {
      var t = secOf(root, c.type, c.renderer);
      if (t) window.__openSection(t);
    });
    g.appendChild(b);
  });
}
function hit(node, x, y) {
  var r = node.getBoundingClientRect();
  return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
}
function ptOf(e) {
  var t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
  return { x: t.clientX, y: t.clientY };
}
// drag with transform (mouse + touch). hooks.end(x, y) returns true when the node was placed somewhere else
function makeDrag(node, h) {
  var sx = 0, sy = 0, active = false;
  function down(e) {
    if (h.canStart && !h.canStart()) return;
    var p = ptOf(e);
    active = true; sx = p.x; sy = p.y;
    node.style.transition = 'none'; node.style.zIndex = '50';
    node.classList.add('dragging');
    if (h.start) h.start(p.x, p.y);
    if (e.cancelable) e.preventDefault();
  }
  function move(e) {
    if (!active) return;
    var p = ptOf(e);
    node.style.transform = 'translate(' + (p.x - sx) + 'px,' + (p.y - sy) + 'px)';
    if (h.move) h.move(p.x, p.y);
    if (e.cancelable) e.preventDefault();
  }
  function up(e) {
    if (!active) return;
    active = false;
    var p = ptOf(e);
    node.classList.remove('dragging'); node.style.zIndex = '';
    var ok = h.end ? h.end(p.x, p.y) : false;
    if (!ok) { node.style.transition = 'transform .22s ease-out'; node.style.transform = 'translate(0px,0px)'; }
  }
  node.addEventListener('mousedown', down);
  node.addEventListener('touchstart', down, { passive: false });
  onDoc('mousemove', move); onDoc('touchmove', move, { passive: false });
  onDoc('mouseup', up); onDoc('touchend', up); onDoc('touchcancel', up);
}
// free dragging inside a stage (sets left/top)
function dragFree(node, stage, onChange) {
  var active = false, ox = 0, oy = 0;
  function down(e) {
    var p = ptOf(e), r = node.getBoundingClientRect();
    active = true; ox = p.x - (r.left + r.width / 2); oy = p.y - (r.top + r.height / 2);
    node.classList.add('dragging');
    if (e.cancelable) e.preventDefault();
  }
  function move(e) {
    if (!active) return;
    var p = ptOf(e), s = stage.getBoundingClientRect();
    node.style.left = clamp(p.x - ox - s.left, 24, s.width - 24) + 'px';
    node.style.top = clamp(p.y - oy - s.top, 24, s.height - 24) + 'px';
    if (onChange) onChange();
    if (e.cancelable) e.preventDefault();
  }
  function up() { if (active) { active = false; node.classList.remove('dragging'); if (onChange) onChange(); } }
  node.addEventListener('mousedown', down);
  node.addEventListener('touchstart', down, { passive: false });
  onDoc('mousemove', move); onDoc('touchmove', move, { passive: false });
  onDoc('mouseup', up); onDoc('touchend', up); onDoc('touchcancel', up);
}
function resultBox(parent, score, total, restart, title) {
  var box = el('div', 'quiz-final');
  box.appendChild(el('div', 'res-title', title || 'نتیجه'));
  var pct = total ? Math.round(score * 100 / total) : 0;
  box.appendChild(el('div', 'res-pct', toFa(pct) + '٪'));
  var bar = el('div', 'res-bar'), fill = el('div', 'res-fill');
  fill.style.width = pct + '%';
  fill.style.background = pct >= 70 ? '#10B981' : (pct >= 40 ? '#F59E0B' : '#EF4444');
  bar.appendChild(fill); box.appendChild(bar);
  box.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(total)));
  var row = el('div', 'quiz-nav');
  row.appendChild(btn('بازی جدید', 'green', restart));
  box.appendChild(row);
  parent.appendChild(box);
  if (total && score / total >= 0.7) confettiBurst();
  return box;
}
function progressBar(frac) {
  var b = el('div', 'prog'), f = el('div', 'prog-fill');
  f.style.width = Math.round(clamp(frac, 0, 1) * 100) + '%';
  b.appendChild(f);
  return b;
}
// multiple choice engine: questions [{q, o[4], c, e, scen}]
function mcq(host, cfg) {
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var pool, idx, score;
  function start() {
    pool = cfg.shuffleQ ? shuffle(cfg.questions.slice()) : cfg.questions.slice();
    if (cfg.count) pool = pool.slice(0, cfg.count);
    idx = 0; score = 0;
    show();
  }
  function show() {
    clear(wrap);
    if (idx >= pool.length) { resultBox(wrap, score, pool.length, start, cfg.finalTitle); return; }
    var q = pool[idx];
    wrap.appendChild(progressBar(idx / pool.length));
    wrap.appendChild(el('div', 'mc-count', 'سوال ' + toFa(idx + 1) + ' از ' + toFa(pool.length)));
    if (q.scen) wrap.appendChild(el('div', 'scenario-card', faText(q.scen)));
    wrap.appendChild(el('div', 'quiz-question', faText(q.q)));
    var opts = el('div', 'quiz-options');
    var order = shuffle([0, 1, 2, 3]), buttons = [], locked = false;
    var expl = el('div', 'quiz-expl');
    expl.style.display = 'none';
    var nav = el('div', 'quiz-nav');
    order.forEach(function (oi) {
      var b = el('button', 'quiz-opt', faText(q.o[oi]));
      b.type = 'button';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (oi === q.c);
        if (ok) score++;
        buttons.forEach(function (x) { x.btn.disabled = true; if (x.oi === q.c) x.btn.classList.add('correct'); });
        if (!ok) b.classList.add('wrong');
        expl.textContent = (ok ? '✓ ' : '✗ ') + faText(q.e || (ok ? 'درست است!' : 'پاسخ درست با رنگ سبز مشخص شد.'));
        expl.style.display = 'block';
        nav.appendChild(btn(idx === pool.length - 1 ? 'نتیجه' : 'بعدی', '', function () { idx++; show(); }));
      });
      buttons.push({ btn: b, oi: oi });
      opts.appendChild(b);
    });
    wrap.appendChild(opts); wrap.appendChild(expl); wrap.appendChild(nav);
  }
  start();
  return { restart: start };
}
// matching: left[i] <-> right[i]; icons optional (array of css colours)
function matchGame(host, left, right, icons) {
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var done, sel, score, rorder, busy;
  function start() {
    clear(wrap);
    done = []; sel = -1; score = 0; busy = false;
    rorder = shuffle(left.map(function (_, i) { return i; }));
    var count = el('div', 'mc-count', 'امتیاز: ' + toFa(0) + ' از ' + toFa(left.length));
    wrap.appendChild(count);
    var cols = el('div', 'match-cols'), lc = el('div', 'match-col'), rc = el('div', 'match-col');
    var lb = [], rb = [];
    left.forEach(function (t, i) {
      var b = el('button', 'match-item');
      b.type = 'button';
      if (icons) { var d = el('span', 'dot'); d.style.background = icons[i]; b.appendChild(d); }
      b.appendChild(document.createTextNode(t));
      b.addEventListener('click', function () {
        if (busy || done[i]) return;
        sel = (sel === i) ? -1 : i;
        lb.forEach(function (x, k) { x.classList.toggle('sel', k === sel); });
      });
      lb.push(b); lc.appendChild(b);
    });
    rorder.forEach(function (ri) {
      var b = el('button', 'match-item', right[ri]);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (busy || done[ri] || sel < 0) return;
        if (sel === ri) {
          done[ri] = true; score++;
          lb[ri].className = 'match-item ok'; b.className = 'match-item ok';
          sel = -1;
          lb.forEach(function (x) { x.classList.remove('sel'); });
          count.textContent = 'امتیاز: ' + toFa(score) + ' از ' + toFa(left.length);
          if (score === left.length) later(function () { resultBox(wrap, score, left.length, start); }, 500);
        } else {
          busy = true;
          var cur = sel;
          lb[cur].classList.add('bad'); b.classList.add('bad');
          later(function () { lb[cur].classList.remove('bad', 'sel'); b.classList.remove('bad'); sel = -1; busy = false; }, 500);
        }
      });
      rb.push(b); rc.appendChild(b);
    });
    cols.appendChild(lc); cols.appendChild(rc); wrap.appendChild(cols);
  }
  start();
}
// one card + several choice buttons per round: items [{html|text, a, why}]
function choiceGame(host, items, choices, opts) {
  opts = opts || {};
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var pool, idx, score;
  function start() { pool = shuffle(items.slice()); if (opts.count) pool = pool.slice(0, opts.count); idx = 0; score = 0; show(); }
  function show() {
    clear(wrap);
    if (idx >= pool.length) { resultBox(wrap, score, pool.length, start); return; }
    var it = pool[idx];
    wrap.appendChild(progressBar(idx / pool.length));
    wrap.appendChild(el('div', 'mc-count', toFa(idx + 1) + ' از ' + toFa(pool.length)));
    if (opts.prompt) wrap.appendChild(el('div', 'mc-prompt', opts.prompt));
    var card = el('div', 'choice-card');
    if (it.html) card.innerHTML = it.html; else card.textContent = it.text;
    wrap.appendChild(card);
    var row = el('div', 'choice-row'), bs = [], locked = false;
    choices.forEach(function (c, ci) {
      var b = el('button', 'choice-btn', c);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (ci === it.a);
        if (ok) score++;
        bs.forEach(function (x, k) { x.disabled = true; if (k === it.a) x.classList.add('correct'); });
        if (!ok) b.classList.add('wrong');
        fb.textContent = ok ? '✓ درست است' : '✗ پاسخ درست: ' + choices[it.a];
        fb.className = 'choice-fb ' + (ok ? 'ok' : 'bad');
        later(function () { idx++; show(); }, ok ? 900 : 1500);
      });
      bs.push(b); row.appendChild(b);
    });
    wrap.appendChild(row);
    var fb = el('div', 'choice-fb', '');
    wrap.appendChild(fb);
  }
  start();
}

var DK = '#334155';
function svgWrap(w, h, inner, minW) {
  return '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="width:100%;' + (minW ? 'min-width:' + minW + 'px;' : 'max-width:420px;') + '" font-family="Vazirmatn, Tahoma, sans-serif">' + inner + '</svg>';
}
function sT(x, y, text, size, anchor, fill) {
  return '<text x="' + x + '" y="' + y + '" font-size="' + (size || 11) + '" text-anchor="' + (anchor || 'middle') + '" fill="' + (fill || DK) + '">' + text + '</text>';
}
function sR(x, y, w, h, fill, stroke) {
  return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + fill + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="2"' : '') + '/>';
}
function sP(d, color, w) { return '<path d="' + d + '" stroke="' + (color || DK) + '" stroke-width="' + (w || 1) + '" fill="none"/>'; }

var CATS = ['طول', 'جرم', 'وزن', 'حجم', 'دما'];
function fmtG(v) { var r = Math.round(v * 10) / 10; return Math.abs(v - r) < 0.001 ? fmt(v, 1) : fmt(v, 2); }
// drawing of measuring tool t (0..9) showing value v
function measureSvg(t, v) {
  var s = '', d = '', k;
  if (t === 0) {
    var L = 20;
    s += sR(L, 110, 320, 60, '#F5D746', DK) + sR(L, 70, v * 20, 24, '#8C50B4');
    s += '<line x1="' + (L + v * 20) + '" y1="70" x2="' + (L + v * 20) + '" y2="130" stroke="#8C50B4" stroke-dasharray="3 3"/>';
    for (k = 0; k <= 160; k++) { var x = L + k * 2, len = (k % 10 === 0) ? 24 : ((k % 5 === 0) ? 16 : 9); d += 'M' + x + ' 110L' + x + ' ' + (110 + len); }
    s += sP(d);
    for (k = 0; k <= 15; k++) s += sT(L + k * 20, 150, toFa(k), 11);
    return svgWrap(360, 200, s);
  }
  if (t === 1) {
    var x0 = 60, dd = v * 6;
    s += sR(30, 184, 300, 26, '#BEC3CD', DK);
    s += '<circle cx="' + (x0 + dd / 2) + '" cy="100" r="' + (dd / 2) + '" fill="#D25A5A" stroke="#782828" stroke-width="2"/>';
    s += sR(x0 - 10, 20, 10, 190, '#828796') + sR(x0 + dd, 20, 10, 190, '#646982');
    for (k = 0; k <= 45; k++) d += 'M' + (x0 + k * 6) + ' 184L' + (x0 + k * 6) + ' ' + (184 + ((k % 5 === 0) ? 16 : 9));
    s += sP(d);
    for (k = 0; k <= 45; k += 5) s += sT(x0 + k * 6, 228, toFa(k), 11);
    s += '<line x1="' + (x0 + dd) + '" y1="170" x2="' + (x0 + dd) + '" y2="200" stroke="#D22828" stroke-width="2"/>';
    return svgWrap(360, 240, s);
  }
  if (t === 2) {
    var m0 = 45, pd = v * 60;
    s += sR(m0 - 26, 40, 26, 130, '#6E788C', DK) + sR(m0 - 26, 28, 300, 16, '#6E788C');
    s += sR(m0, 72, pd, 56, '#288C82');
    s += sR(m0 + pd, 88, 80, 24, '#C8CDD7', DK) + sR(m0 + pd + 80, 66, 70, 68, '#969BAA', DK);
    for (k = 0; k <= 25; k++) d += 'M' + (m0 + k * 6) + ' 180L' + (m0 + k * 6) + ' ' + (180 + ((k % 5 === 0) ? 16 : 9));
    s += sP(d) + '<line x1="' + m0 + '" y1="180" x2="' + (m0 + 150) + '" y2="180" stroke="' + DK + '"/>';
    for (k = 0; k <= 25; k += 5) s += sT(m0 + k * 6, 212, fmt(k / 10, 1), 11);
    s += '<line x1="' + (m0 + pd) + '" y1="150" x2="' + (m0 + pd) + '" y2="176" stroke="#D22828" stroke-width="2"/>';
    return svgWrap(360, 240, s);
  }
  if (t === 3) {
    s += sR(60, 120, 240, 90, '#464B5A') + sR(170, 104, 20, 18, '#78808C') + sR(70, 92, 220, 12, '#B4B9C8', DK);
    s += sR(150, 40, 60, 50, '#DCAA32', '#966E14') + sR(90, 136, 180, 58, '#14181E', '#788090');
    s += sT(180, 176, fmt(v, 1) + ' g', 26, 'middle', '#50FF78');
    return svgWrap(360, 240, s);
  }
  if (t === 4) {
    s += sR(150, 10, 60, 170, '#EBECF2', DK);
    for (k = 0; k <= 20; k++) d += 'M150 ' + (18 + k * 7.8) + 'L' + (150 + ((k % 5 === 0) ? 22 : 12)) + ' ' + (18 + k * 7.8);
    s += sP(d);
    for (k = 0; k <= 20; k += 5) s += sT(144, 22 + k * 7.8, toFa(k), 11, 'end');
    s += '<line x1="150" y1="' + (18 + v * 7.8) + '" x2="210" y2="' + (18 + v * 7.8) + '" stroke="#D22828" stroke-width="3"/>';
    d = 'M180 180';
    for (k = 1; k <= 6; k++) d += 'L' + (180 + ((k % 2 === 0) ? -9 : 9)) + ' ' + (180 + k * 4.5);
    s += sP(d, '#788094', 2) + sR(160, 208, 40, 28, '#5A6EBE');
    return svgWrap(360, 240, s);
  }
  if (t === 5) {
    s += sR(150, 20, 70, 200, '#E1EEFA', DK) + sR(152, 220 - v * 2, 66, v * 2, '#468CE6');
    for (k = 0; k <= 100; k += 5) d += 'M150 ' + (220 - k * 2) + 'L' + (150 + ((k % 10 === 0) ? 20 : 11)) + ' ' + (220 - k * 2);
    s += sP(d);
    for (k = 0; k <= 100; k += 10) s += sT(144, 224 - k * 2, toFa(k), 11, 'end');
    s += sR(135, 220, 100, 8, '#788294');
    return svgWrap(360, 240, s);
  }
  if (t === 6) {
    s += '<circle cx="180" cy="28" r="16" fill="#C83C3C"/>' + sR(168, 40, 24, 170, '#EBF2FA', DK) + sR(170, 200 - v * 18, 20, v * 18 + 10, '#5096E6');
    s += '<path d="M168 210L192 210L184 232L176 232Z" fill="#5096E6" stroke="' + DK + '" stroke-width="2"/>';
    for (k = 0; k <= 20; k++) d += 'M192 ' + (200 - k * 9) + 'L' + (192 + ((k % 2 === 0) ? 16 : 9)) + ' ' + (200 - k * 9);
    s += sP(d);
    for (k = 0; k <= 10; k++) s += sT(216, 204 - k * 18, toFa(k), 11, 'start');
    return svgWrap(360, 240, s);
  }
  if (t === 7) {
    var yT = function (T) { return 190 - (T + 10) * 170 / 70; };
    s += '<circle cx="180" cy="208" r="22" fill="#D22828" stroke="' + DK + '" stroke-width="2"/>' + sR(170, 16, 20, 190, '#FAFAFC', DK) + sR(176, yT(v), 8, 210 - yT(v), '#D22828');
    for (k = -10; k <= 60; k += 5) d += 'M190 ' + yT(k) + 'L' + (190 + ((k % 10 === 0) ? 18 : 10)) + ' ' + yT(k);
    s += sP(d);
    for (k = -10; k <= 60; k += 10) s += sT(214, yT(k) + 4, toFa(k), 11, 'start');
    return svgWrap(360, 240, s);
  }
  if (t === 8) {
    s += sR(20, 50, 500, 40, '#F5D746', DK) + sR(20, 24, v, 10, '#288C82');
    s += '<line x1="' + (20 + v) + '" y1="24" x2="' + (20 + v) + '" y2="60" stroke="#288C82" stroke-dasharray="3 3"/>';
    for (k = 0; k <= 500; k += 5) d += 'M' + (20 + k) + ' 50L' + (20 + k) + ' ' + (50 + ((k % 50 === 0) ? 20 : ((k % 10 === 0) ? 13 : 7)));
    s += sP(d);
    for (k = 0; k <= 500; k += 50) s += sT(20 + k, 114, toFa(k), 11);
    return svgWrap(540, 130, s, 540);
  }
  s += '<circle cx="180" cy="124" r="104" fill="#334155"/><circle cx="180" cy="124" r="99" fill="#fff"/>' + sR(172, 6, 16, 14, '#78808C');
  for (k = 0; k < 300; k++) {
    var a = (k * 1.2 - 90) * Math.PI / 180, len = (k % 25 === 0) ? 14 : ((k % 5 === 0) ? 8 : 4);
    d += 'M' + (180 + 98 * Math.cos(a)).toFixed(1) + ' ' + (124 + 98 * Math.sin(a)).toFixed(1) + 'L' + (180 + (98 - len) * Math.cos(a)).toFixed(1) + ' ' + (124 + (98 - len) * Math.sin(a)).toFixed(1);
  }
  s += sP(d);
  for (k = 0; k < 60; k += 5) { var b = (k * 6 - 90) * Math.PI / 180; s += sT((180 + 76 * Math.cos(b)).toFixed(1), (128 + 76 * Math.sin(b)).toFixed(1), toFa(k), 12); }
  var ha = (v * 6 - 90) * Math.PI / 180;
  s += '<line x1="180" y1="124" x2="' + (180 + 86 * Math.cos(ha)).toFixed(1) + '" y2="' + (124 + 86 * Math.sin(ha)).toFixed(1) + '" stroke="#D22828" stroke-width="3"/><circle cx="180" cy="124" r="6" fill="' + DK + '"/>';
  return svgWrap(360, 240, s);
}

// ---------- tools ----------
function initTools(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var preset = [7.3, 12.4, 1.37, 152.6, 8.4, 54, 6.2, 23];
  var sel = 0;
  function explore() {
    clear(wrap);
    var row = el('div', 'chip-row');
    D.tools.forEach(function (t, k) {
      var c = el('button', 'chip' + (k === sel ? ' on' : ''), t[0]);
      c.type = 'button';
      c.addEventListener('click', function () { sel = k; explore(); });
      row.appendChild(c);
    });
    wrap.appendChild(row);
    var t = D.tools[sel];
    var box = el('div', 'svg-box');
    box.innerHTML = measureSvg(t[3], preset[t[3]]);
    wrap.appendChild(box);
    var info = el('div', 'card-box');
    info.appendChild(el('div', 'tech-name', t[0]));
    info.appendChild(el('div', 'mc-prompt', 'کاربرد: ' + t[1]));
    info.appendChild(el('div', 'mc-prompt', 'یکا: ' + t[2]));
    wrap.appendChild(info);
    var nav = el('div', 'quiz-nav');
    nav.appendChild(btn('بازی تطبیق', 'green', game));
    wrap.appendChild(nav);
  }
  function game() {
    var order = shuffle(D.tools.map(function (_, k) { return k; })), r = 0, score = 0;
    function round() {
      clear(wrap);
      if (r >= 8) { resultBox(wrap, score, 8, game, 'نتیجه بازی'); return; }
      var t = D.tools[order[r]];
      wrap.appendChild(progressBar(r / 8));
      wrap.appendChild(el('div', 'mc-count', 'دور ' + toFa(r + 1) + ' از ' + toFa(8)));
      var box = el('div', 'svg-box');
      box.innerHTML = measureSvg(t[3], preset[t[3]]);
      wrap.appendChild(box);
      wrap.appendChild(el('div', 'tech-name', t[0]));
      wrap.appendChild(el('div', 'mc-prompt', 'این ابزار برای اندازه‌گیری چه کمیتی است؟'));
      var cats = shuffle([0, 1, 2, 3, 4].filter(function (c) { return c !== t[4]; })).slice(0, 3);
      cats.push(t[4]); shuffle(cats);
      var row = el('div', 'choice-row'), bs = [], locked = false;
      cats.forEach(function (c) {
        var b = el('button', 'choice-btn', CATS[c]);
        b.type = 'button';
        b.addEventListener('click', function () {
          if (locked) return;
          locked = true;
          var ok = (c === t[4]);
          if (ok) score++;
          bs.forEach(function (x, k) { x.disabled = true; if (cats[k] === t[4]) x.classList.add('correct'); });
          if (!ok) b.classList.add('wrong');
          later(function () { r++; round(); }, 900);
        });
        bs.push(b); row.appendChild(b);
      });
      wrap.appendChild(row);
    }
    round();
  }
  explore();
}

// ---------- measure: read the tool and type the number ----------
function initMeasure(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var ti, score;
  function restart() { ti = 0; score = 0; round(); }
  function round() {
    clear(wrap);
    if (ti >= D.mtools.length) { resultBox(wrap, score, D.mtools.length, restart, 'نتیجه اندازه‌گیری'); return; }
    var t = D.mtools[ti], n = Math.round((t[3] - t[2]) / t[4]);
    var val = Number((Math.round((t[2] + rnd(n + 1) * t[4]) / t[4]) * t[4]).toFixed(t[6]));
    wrap.appendChild(progressBar(ti / D.mtools.length));
    wrap.appendChild(el('div', 'mc-count', t[0] + ' — ابزار ' + toFa(ti + 1) + ' از ' + toFa(D.mtools.length) + ' — امتیاز: ' + toFa(score)));
    var box = el('div', 'svg-box');
    box.innerHTML = measureSvg(ti, val);
    wrap.appendChild(box);
    wrap.appendChild(el('div', 'mc-prompt', 'عدد روی ' + t[0] + ' را بخوانید و وارد کنید'));
    var row = el('div', 'in-row');
    var inp = el('input', 'num-in');
    inp.type = 'text'; inp.setAttribute('inputmode', 'decimal'); inp.setAttribute('placeholder', 'عدد را وارد کنید');
    row.appendChild(inp); row.appendChild(el('span', '', t[1]));
    wrap.appendChild(row);
    var fb = el('div', 'fb-line', ''), locked = false;
    function next(ms) { later(function () { ti++; round(); }, ms); }
    var nav = el('div', 'quiz-nav');
    nav.appendChild(btn('تایید', 'green', function () {
      if (locked) return;
      var u = parseNum(inp.value);
      if (u === null) { fb.textContent = 'یک عدد وارد کنید'; fb.className = 'fb-line bad'; return; }
      locked = true;
      if (Math.abs(u - val) <= t[5] + 0.0001) { score++; fb.textContent = 'آفرین!'; fb.className = 'fb-line ok'; next(800); }
      else { fb.textContent = 'جواب درست: ' + fmt(val, t[6]) + ' ' + t[1]; fb.className = 'fb-line bad'; next(1600); }
    }));
    nav.appendChild(btn('رد کردن', 'gray', function () { if (locked) return; locked = true; ti++; round(); }));
    wrap.appendChild(nav); wrap.appendChild(fb);
  }
  restart();
}

// ---------- mass and weight ----------
function initMass(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var mass = D.masses[0], custom = false, onScale = false;
  var chips = el('div', 'chip-row'), chipEls = [];
  D.massLabels.forEach(function (lb, k) {
    var c = el('button', 'chip' + (k === 0 ? ' on' : ''), lb);
    c.type = 'button';
    c.addEventListener('click', function () { mass = D.masses[k]; custom = false; refresh(); });
    chipEls.push(c); chips.appendChild(c);
  });
  wrap.appendChild(chips);
  var crow = el('div', 'in-row');
  crow.appendChild(el('span', '', 'یا جرم دلخواه (کیلوگرم):'));
  var cin = el('input', 'num-in');
  cin.type = 'text'; cin.setAttribute('inputmode', 'decimal'); cin.setAttribute('placeholder', 'مثلاً ۲٫۵');
  crow.appendChild(cin);
  crow.appendChild(btn('محاسبه', 'green', function () {
    var v = parseNum(cin.value);
    if (v === null || v <= 0) return;
    mass = Math.min(1000, v); custom = true; refresh();
  }));
  wrap.appendChild(crow);
  wrap.appendChild(el('div', 'mc-prompt', 'جسم را روی ترازو بکشید'));
  var stage = el('div', 'stage mass-stage');
  var homeSlot = el('div', 'slot home-slot'), scaleBox = el('div', 'scale-box');
  var panSlot = el('div', 'slot pan-slot'), pan = el('div', 'scale-pan'), body = el('div', 'scale-body'), disp = el('div', 'scale-disp', '۰٫۰ kg');
  scaleBox.appendChild(panSlot); scaleBox.appendChild(pan); scaleBox.appendChild(body); body.appendChild(disp);
  var block = el('div', 'mass-block', '');
  homeSlot.appendChild(block);
  stage.appendChild(homeSlot); stage.appendChild(scaleBox);
  wrap.appendChild(stage);
  var bars = el('div', 'bars'), fills = [], vals = [];
  var maxG = 24.8;
  D.planets.forEach(function (p) {
    var row = el('div', 'bar-row'), nm = el('div', 'bar-name');
    var n1 = el('span', '', p[0]); n1.style.color = css(p[2]);
    nm.appendChild(n1); nm.appendChild(el('span', 'bar-g', 'g = ' + fmt(p[1], 1)));
    var tr = el('div', 'bar-track'), f = el('div', 'bar-fill'), v = el('div', 'bar-val', '');
    f.style.background = css(p[2]);
    tr.appendChild(f); row.appendChild(nm); row.appendChild(tr); row.appendChild(v);
    fills.push(f); vals.push(v); bars.appendChild(row);
  });
  wrap.appendChild(bars);
  wrap.appendChild(el('div', 'formula', 'W = m × g'));
  function refresh() {
    chipEls.forEach(function (c, k) { c.classList.toggle('on', !custom && mass === D.masses[k]); });
    block.textContent = fmtG(mass) + ' kg';
    disp.textContent = onScale ? fmtG(mass) + ' kg' : '۰٫۰ kg';
    D.planets.forEach(function (p, k) {
      var w = mass * p[1];
      fills[k].style.width = onScale ? (p[1] / maxG * 100) + '%' : '0%';
      vals[k].textContent = onScale ? fmt(w, w < 10 ? 2 : 1) + ' N' : '';
    });
  }
  makeDrag(block, {
    start: function () { if (onScale) { onScale = false; refresh(); } },
    end: function (x, y) {
      if (hit(scaleBox, x, y)) { panSlot.appendChild(block); block.style.transform = ''; block.style.transition = ''; onScale = true; refresh(); return true; }
      if (block.parentNode === panSlot) { homeSlot.appendChild(block); block.style.transform = ''; block.style.transition = ''; return true; }
      return false;
    }
  });
  refresh();
}

// ---------- volume and density ----------
function initDensity(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var sel = -1, stage = 0, falling = false, floating = false, settled = false, settleT = 0, oy = 0;
  var chips = el('div', 'chip-row'), chipEls = [];
  D.mats.forEach(function (m, k) {
    var c = el('button', 'chip', m[0]);
    c.type = 'button';
    c.addEventListener('click', function () { sel = k; resetObj(); });
    chipEls.push(c); chips.appendChild(c);
  });
  wrap.appendChild(chips);
  var panel = el('div', 'card-box', '');
  wrap.appendChild(panel);
  var st = el('div', 'stage dens-stage');
  var homeSlot = el('div', 'slot home-slot'), scaleBox = el('div', 'scale-box small'), panSlot = el('div', 'slot pan-slot'), pan = el('div', 'scale-pan'), body = el('div', 'scale-body'), disp = el('div', 'scale-disp', '۰ g');
  scaleBox.appendChild(panSlot); scaleBox.appendChild(pan); scaleBox.appendChild(body); body.appendChild(disp);
  var beaker = el('div', 'beaker'), water = el('div', 'beaker-water');
  beaker.appendChild(water);
  var obj = el('div', 'dens-obj');
  homeSlot.appendChild(obj);
  st.appendChild(homeSlot); st.appendChild(scaleBox); st.appendChild(beaker);
  wrap.appendChild(st);
  var nav = el('div', 'quiz-nav');
  nav.appendChild(btn('شروع مجدد', 'red', function () { resetObj(); }));
  wrap.appendChild(nav);
  var chart = el('div', 'bars dens-chart'), rows = [];
  D.mats.forEach(function (m) {
    var row = el('div', 'bar-row'), nm = el('div', 'bar-name', m[0]), tr = el('div', 'bar-track'), f = el('div', 'bar-fill'), v = el('div', 'bar-val', fmtG(m[1]) + ' g/cm³');
    f.style.width = Math.max(2, m[1] / 19.3 * 100) + '%'; f.style.background = css(m[2]); f.style.transition = 'none';
    var wl = el('div', 'water-line'); wl.style.left = (1 / 19.3 * 100) + '%';
    tr.appendChild(f); tr.appendChild(wl); row.appendChild(nm); row.appendChild(tr); row.appendChild(v);
    rows.push(row); chart.appendChild(row);
  });
  wrap.appendChild(el('div', 'mc-prompt', 'مقایسه چگالی مواد (خط آبی: چگالی آب = ۱)'));
  wrap.appendChild(chart);
  function text() {
    clear(panel);
    if (sel < 0) { panel.appendChild(el('div', 'mc-prompt', 'ماده‌ای را انتخاب کنید و جسم را بکشید')); return; }
    var m = D.mats[sel], mm = m[1] * 8;
    panel.appendChild(el('div', 'tech-name', m[0]));
    if (stage === 0) panel.appendChild(el('div', 'mc-prompt', 'جسم را روی ترازو بکشید'));
    else if (stage === 1) {
      panel.appendChild(el('div', 'mc-prompt', 'جرم: ' + fmtG(mm) + ' g'));
      panel.appendChild(el('div', 'mc-prompt', 'حالا جسم را بالای لیوان ببرید و رها کنید'));
    } else if (settled && Date.now() - settleT >= 2000) {
      panel.appendChild(el('div', 'mc-prompt', 'چگالی: ' + fmtG(m[1]) + ' g/cm³'));
      panel.appendChild(el('div', 'mc-prompt', 'چگالی = ' + fmtG(mm) + ' ÷ ' + toFa(8)));
      var r = el('div', 'tech-name', m[1] < 1 ? 'شناور می‌ماند' : 'غرق می‌شود');
      r.style.color = m[1] < 1 ? '#059669' : '#DC2626';
      panel.appendChild(r);
      panel.appendChild(el('div', 'mc-prompt', fmt(m[1], 2) + ' برابر آب'));
    } else panel.appendChild(el('div', 'mc-prompt', 'ببینید جسم چه می‌کند ...'));
  }
  function resetObj() {
    stage = 0; falling = false; floating = false; settled = false; settleT = 0;
    homeSlot.appendChild(obj);
    obj.style.position = ''; obj.style.left = ''; obj.style.top = ''; obj.style.transform = ''; obj.style.transition = '';
    obj.style.display = sel < 0 ? 'none' : 'block';
    if (sel >= 0) obj.style.background = css(D.mats[sel][2]);
    disp.textContent = '۰ g';
    chipEls.forEach(function (c, k) { c.classList.toggle('on', k === sel); });
    rows.forEach(function (r, k) { r.style.opacity = (sel < 0 || k === sel) ? '1' : '0.55'; });
    text();
  }
  makeDrag(obj, {
    canStart: function () { return sel >= 0 && stage < 2; },
    end: function (x, y) {
      if (stage === 0 && hit(scaleBox, x, y)) {
        panSlot.appendChild(obj); obj.style.transform = ''; obj.style.transition = '';
        stage = 1; disp.textContent = 'جرم: ' + fmtG(D.mats[sel][1] * 8) + ' g'; text(); return true;
      }
      if (stage === 1 && hit(beaker, x, y)) {
        stage = 2;
        beaker.appendChild(obj);
        obj.style.transform = ''; obj.style.transition = '';
        obj.style.position = 'absolute'; obj.style.left = '40px'; obj.style.top = '-60px'; oy = -60;
        falling = true; text(); return true;
      }
      if (stage === 1 && obj.parentNode !== panSlot) { panSlot.appendChild(obj); obj.style.transform = ''; return true; }
      return false;
    }
  });
  var BH = 200, WY = 80, OB = 40;
  loop(function (dt) {
    if (stage !== 2 || sel < 0) return;
    var d = D.mats[sel][1];
    if (falling) {
      var wasIn = oy + OB >= WY, sp = (wasIn && d >= 1) ? 90 : 150;
      oy += sp * dt;
      var nowIn = oy + OB >= WY;
      if (d < 1) { if (nowIn) { falling = false; floating = true; } }
      else if (oy + OB >= BH - 3) { oy = BH - 3 - OB; falling = false; settled = true; settleT = Date.now(); }
    } else if (floating) {
      var target = WY - OB * (1 - d);
      if (!settled) { oy += (target - oy) * Math.min(1, dt * 5); if (Math.abs(target - oy) < 0.5) { settled = true; settleT = Date.now(); } }
      else oy = target + Math.sin(Date.now() * 0.003) * 3;
    }
    obj.style.top = oy + 'px';
    if (settled && Date.now() - settleT >= 2000 && panel.textContent.indexOf('چگالی:') < 0) text();
  });
  resetObj();
}

// ---------- error and precision ----------
function rulerSvg(o) {
  var s = sR(0, 50, 280, 64, '#F5D746', DK) + sR(0, 22, 212, 22, '#8C50B4'), d = '', k;
  if (o === 0) for (k = 0; k <= 7; k++) d += 'M' + (k * 40) + ' 50L' + (k * 40) + ' 80';
  else if (o === 1) for (k = 0; k <= 70; k++) d += 'M' + (k * 4) + ' 50L' + (k * 4) + ' ' + (50 + ((k % 10 === 0) ? 30 : ((k % 5 === 0) ? 20 : 12)));
  else for (k = 0; k < 280; k++) d += 'M' + k + ' 50L' + k + ' ' + (50 + ((k % 40 === 0) ? 30 : ((k % 4 === 0) ? 14 : 7)));
  s += sP(d);
  for (k = 0; k <= 6; k++) s += sT(k * 40 + (k === 0 ? 6 : 0), 102, toFa(k), 11);
  return svgWrap(280, 124, s);
}
function thermoSvg(o) {
  var yy = function (T) { return 215 - T * 3.8; }, s = '', d = '', k;
  s += '<circle cx="60" cy="232" r="18" fill="#D22828" stroke="' + DK + '" stroke-width="2"/>' + sR(48, 20, 24, 205, '#FAFAFC', DK) + sR(55, yy(25), 10, 232 - yy(25), '#D22828');
  if (o === 0) for (k = 0; k <= 50; k += 10) { d += 'M72 ' + yy(k) + 'L90 ' + yy(k); s += sT(94, yy(k) + 4, toFa(k), 11, 'start'); }
  else {
    for (k = 0; k <= 50; k++) d += 'M72 ' + yy(k) + 'L' + (72 + ((k % 5 === 0) ? 18 : 9)) + ' ' + yy(k);
    for (k = 0; k <= 50; k += 10) s += sT(94, yy(k) + 4, toFa(k), 11, 'start');
  }
  return svgWrap(130, 260, s + sP(d), 0).replace('max-width:420px;', 'max-width:130px;');
}
function scaleSvg(o) {
  if (o === 1) return svgWrap(240, 140, sR(20, 20, 200, 90, '#14181E', '#788090') + sT(120, 78, '۲۵٫۳۴ g', 30, 'middle', '#50FF78'));
  var s = '<circle cx="120" cy="80" r="76" fill="#334155"/><circle cx="120" cy="80" r="72" fill="#fff"/>', k;
  for (k = 0; k <= 50; k += 5) {
    var a = (-225 + k / 50 * 270) * Math.PI / 180;
    s += '<line x1="' + (120 + 72 * Math.cos(a)).toFixed(1) + '" y1="' + (80 + 72 * Math.sin(a)).toFixed(1) + '" x2="' + (120 + 60 * Math.cos(a)).toFixed(1) + '" y2="' + (80 + 60 * Math.sin(a)).toFixed(1) + '" stroke="' + DK + '" stroke-width="2"/>';
    if (k % 10 === 0) s += sT((120 + 46 * Math.cos(a)).toFixed(1), (84 + 46 * Math.sin(a)).toFixed(1), toFa(k), 11);
  }
  s += '<line x1="120" y1="80" x2="120" y2="22" stroke="#D22828" stroke-width="3"/><circle cx="120" cy="80" r="5" fill="' + DK + '"/>';
  return svgWrap(240, 170, s);
}
function initError(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var sc, score;
  var prompts = ['روی خط‌کشی که دقیق‌ترین گزارش را می‌دهد کلیک کنید', 'کدام دماسنج دقیق‌تر است؟', 'کدام ترازو دقیق‌تر است؟'];
  var reports = [['۵ سانتی‌متر', '۵.۳ سانتی‌متر', '۵.۳۰ سانتی‌متر'], ['گزارش: ۲۵ درجه', 'گزارش: ۲۵ درجه'], ['گزارش: ۲۵ g', 'گزارش: ۲۵٫۳۴ g']];
  var reveal = [['دقت: ۱ سانتی‌متر', 'دقت: ۱ میلی‌متر', 'دقت: ۰٫۱ میلی‌متر'], ['تقسیمات ۱۰ درجه‌ای', 'تقسیمات ۱ درجه‌ای'], ['ترازوی عقربه‌ای', 'ترازوی دیجیتال']];
  var okMsg = ['درست! دقیق‌ترین خط‌کش', 'درست! دماسنج با تقسیمات کوچک‌تر دقیق‌تر است', 'درست! ترازوی دیجیتال دقیق‌تر است'];
  var badMsg = ['این خط‌کش دقت کمتری دارد', 'این دماسنج دقت کمتری دارد', 'این ترازو دقت کمتری دارد'];
  function restart() { sc = 0; score = 0; show(); }
  function show() {
    clear(wrap);
    if (sc >= 3) { resultBox(wrap, score, 3, restart, 'نتیجه خطا و دقت'); return; }
    wrap.appendChild(progressBar(sc / 3));
    wrap.appendChild(el('div', 'mc-count', 'سناریو ' + toFa(sc + 1) + ' از ' + toFa(3)));
    wrap.appendChild(el('div', 'mc-prompt', prompts[sc]));
    var n = sc === 0 ? 3 : 2, order = shuffle(n === 3 ? [0, 1, 2] : [0, 1]), row = el('div', 'err-row'), locked = false, opts = [];
    var fb = el('div', 'fb-line', ''), nav = el('div', 'quiz-nav');
    order.forEach(function (o, slot) {
      var b = el('button', 'err-opt');
      b.type = 'button';
      var svg = (sc === 0) ? rulerSvg(o) : (sc === 1 ? thermoSvg(o) : scaleSvg(o));
      b.innerHTML = '<div class="err-name">' + (sc === 0 ? 'خط‌کش ' : (sc === 1 ? 'دماسنج ' : 'ترازو ')) + 'ABC'.charAt(slot) + '</div>' + svg + '<div class="err-rep">' + (sc === 0 ? 'گزارش: ' : '') + reports[sc][o] + '</div><div class="err-reveal"></div>';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (o === n - 1);
        if (ok) score++;
        opts.forEach(function (x) {
          x.b.disabled = true;
          var rv = x.b.querySelector('.err-reveal');
          if (rv) rv.textContent = reveal[sc][x.o];
          if (x.o === n - 1) x.b.classList.add('correct');
        });
        if (!ok) b.classList.add('wrong');
        fb.textContent = ok ? okMsg[sc] : badMsg[sc];
        fb.className = 'fb-line ' + (ok ? 'ok' : 'bad');
        nav.appendChild(btn(sc === 2 ? 'نتیجه' : 'بعدی', '', function () { sc++; show(); }));
      });
      opts.push({ b: b, o: o }); row.appendChild(b);
    });
    wrap.appendChild(row); wrap.appendChild(fb); wrap.appendChild(nav);
  }
  restart();
}

// ---------- clock + stopwatch ----------
function clockSvg(h, m) {
  var s = '<circle cx="130" cy="130" r="122" fill="#fff" stroke="' + DK + '" stroke-width="4"/>', d = '', k;
  for (k = 0; k < 60; k++) {
    var a = k * 6 * Math.PI / 180, len = (k % 5 === 0) ? 12 : 6;
    d += 'M' + (130 + 116 * Math.cos(a)).toFixed(1) + ' ' + (130 + 116 * Math.sin(a)).toFixed(1) + 'L' + (130 + (116 - len) * Math.cos(a)).toFixed(1) + ' ' + (130 + (116 - len) * Math.sin(a)).toFixed(1);
  }
  s += sP(d);
  for (k = 1; k <= 12; k++) { var b = (k * 30 - 90) * Math.PI / 180; s += sT((130 + 92 * Math.cos(b)).toFixed(1), (136 + 92 * Math.sin(b)).toFixed(1), toFa(k), 18); }
  var ha = ((h % 12) * 30 + m * 0.5 - 90) * Math.PI / 180, ma = (m * 6 - 90) * Math.PI / 180;
  s += '<line x1="130" y1="130" x2="' + (130 + 60 * Math.cos(ha)).toFixed(1) + '" y2="' + (130 + 60 * Math.sin(ha)).toFixed(1) + '" stroke="' + DK + '" stroke-width="6" stroke-linecap="round"/>';
  s += '<line x1="130" y1="130" x2="' + (130 + 88 * Math.cos(ma)).toFixed(1) + '" y2="' + (130 + 88 * Math.sin(ma)).toFixed(1) + '" stroke="#D22828" stroke-width="4" stroke-linecap="round"/><circle cx="130" cy="130" r="6" fill="' + DK + '"/>';
  return svgWrap(260, 260, s).replace('max-width:420px;', 'max-width:260px;');
}
function initClock(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var tabs = el('div', 'chip-row'), body = el('div', '');
  var t1 = el('button', 'chip on', 'ساعت عقربه‌ای'), t2 = el('button', 'chip', 'کرنومتر');
  t1.type = 'button'; t2.type = 'button';
  tabs.appendChild(t1); tabs.appendChild(t2);
  wrap.appendChild(tabs); wrap.appendChild(body);
  var mode = 0;
  function tm(h, m) { return toFa(h + ':' + (m < 10 ? '0' : '') + m); }
  var qn, score, cur;
  function newQ() {
    var mins = [0, 15, 30, 45], h = 1 + rnd(12), m = mins[rnd(4)], opts = [tm(h, m)];
    var guard = 0;
    while (opts.length < 4 && guard++ < 200) {
      var h2 = h, m2 = m, kind = rnd(3);
      if (kind === 0) h2 = ((h - 1 + (rnd(2) ? 1 : 11)) % 12) + 1;
      else if (kind === 1) m2 = mins[rnd(4)];
      else { h2 = 1 + rnd(12); m2 = mins[rnd(4)]; }
      var s = tm(h2, m2);
      if (opts.indexOf(s) < 0) opts.push(s);
    }
    cur = { h: h, m: m, ans: tm(h, m), opts: shuffle(opts) };
  }
  function analog(restart) {
    clear(body);
    if (restart) { qn = 0; score = 0; }
    if (qn >= 10) { resultBox(body, score, 10, function () { analog(true); newQ(); analog(false); }, 'نتیجه ساعت'); return; }
    if (!cur || restart) newQ();
    body.appendChild(progressBar(qn / 10));
    body.appendChild(el('div', 'mc-count', 'سوال ' + toFa(qn + 1) + ' از ' + toFa(10)));
    var box = el('div', 'svg-box'); box.innerHTML = clockSvg(cur.h, cur.m); body.appendChild(box);
    body.appendChild(el('div', 'mc-prompt', 'ساعت چند است؟'));
    var row = el('div', 'choice-row'), bs = [], locked = false;
    cur.opts.forEach(function (o) {
      var b = el('button', 'choice-btn', o);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (o === cur.ans);
        if (ok) score++;
        bs.forEach(function (x) { x.disabled = true; if (x.textContent === cur.ans) x.classList.add('correct'); });
        if (!ok) b.classList.add('wrong');
        later(function () { qn++; newQ(); analog(false); }, 900);
      });
      bs.push(b); row.appendChild(b);
    });
    body.appendChild(row);
  }
  var running = false, startT = 0, elapsed = 0, disp;
  function stopwatch() {
    clear(body);
    disp = el('div', 'sw-disp', '۰۰:۰۰٫۰۰');
    body.appendChild(disp);
    var row = el('div', 'quiz-nav'), go = btn('شروع', 'green', null);
    go.addEventListener('click', function () {
      if (!running) { startT = Date.now() - elapsed; running = true; go.textContent = 'توقف'; go.className = 'btn-sm red'; }
      else { elapsed = Date.now() - startT; running = false; go.textContent = 'شروع'; go.className = 'btn-sm green'; render(); }
    });
    row.appendChild(go);
    row.appendChild(btn('صفر', 'gray', function () { running = false; elapsed = 0; go.textContent = 'شروع'; go.className = 'btn-sm green'; render(); }));
    body.appendChild(row);
    render();
  }
  function render() {
    if (!disp) return;
    var ms = running ? Date.now() - startT : elapsed;
    var mm = Math.floor(ms / 60000), ss = Math.floor(ms / 1000) % 60, cc = Math.floor((ms % 1000) / 10);
    function p2(n) { return (n < 10 ? '0' : '') + n; }
    disp.textContent = toFa(p2(mm) + ':' + p2(ss)) + '٫' + toFa(p2(cc));
  }
  t1.addEventListener('click', function () { mode = 0; t1.className = 'chip on'; t2.className = 'chip'; disp = null; analog(false); });
  t2.addEventListener('click', function () { mode = 1; t2.className = 'chip on'; t1.className = 'chip'; stopwatch(); });
  loop(function () { if (mode === 1 && running && visible(body)) render(); });
  qn = 0; score = 0; newQ(); analog(false);
}

function safe(root, fn, section) {
  try { if (section) fn(section); } catch (e) { showError(root, e); }
}
window.chapterInit = function (root) {
  dead = false;
  try {
    buildHome(root, [
      { icon: '🔧', label: 'ابزارها و کاربردها', type: 'tools' },
      { icon: '📏', label: 'اندازه‌گیری دقیق', type: 'measure' },
      { icon: '⚖️', label: 'جرم و وزن', type: 'mass' },
      { icon: '🧪', label: 'حجم و چگالی', type: 'density' },
      { icon: '🎯', label: 'خطا و دقت', type: 'error' },
      { icon: '⏰', label: 'ساعت', type: 'clock' },
      { icon: '📝', label: 'آزمون جامع', type: 'quiz' }
    ]);
  } catch (e) { showError(root, e); return; }
  safe(root, initTools, secOf(root, 'tools'));
  safe(root, initMeasure, secOf(root, 'measure'));
  safe(root, initMass, secOf(root, 'mass'));
  safe(root, initDensity, secOf(root, 'density'));
  safe(root, initError, secOf(root, 'error'));
  safe(root, initClock, secOf(root, 'clock'));
  safe(root, function (s) {
    mcq(s, { questions: D.quiz.map(function (x) { return { q: x[0], o: x[1], c: x[2] }; }), finalTitle: 'نتیجه آزمون' });
  }, secOf(root, 'quiz'));
};
window.chapterTeardown = function () {
  dead = true;
  timeouts.forEach(function (t) { clearTimeout(t); }); timeouts = [];
  docHandlers.forEach(function (h) { document.removeEventListener(h[0], h[1], h[2]); }); docHandlers = [];
};

})();
