﻿(function () {
  'use strict';

  window.chapterInit = function (root, chapterId) {
    initHome(root);
    initTools(root);
    initMeasure(root);
    initMass(root);
    initDensity(root);
    initError(root);
    initClock(root);
    initQuiz(root);
  };

  function toFa(n) {
    var fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return String(n).split('').map(function (c) {
      return /\d/.test(c) ? fa[parseInt(c, 10)] : c;
    }).join('');
  }
  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
  function confettiBurst() {
    var colors = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
    for (var i = 0; i < 80; i++) {
      var p = document.createElement('div');
      p.className = 'confetti-piece';
      p.style.left = (30 + Math.random() * 40) + '%';
      p.style.background = colors[Math.floor(Math.random() * colors.length)];
      p.style.animationDelay = (Math.random() * 0.3) + 's';
      p.style.animationDuration = (1.8 + Math.random() * 1.2) + 's';
      document.body.appendChild(p);
      (function (node) { setTimeout(function () { node.remove(); }, 3500); })(p);
    }
  }

  // ============================================================
  // HOME
  // ============================================================
  function initHome(root) {
    var grid = root.querySelector('#home-grid');
    if (!grid) return;
    var items = [
      { label: 'ابزارها و کاربردها', icon: '🔧', type: 'tools' },
      { label: 'اندازه‌گیری دقیق', icon: '📏', type: 'measure' },
      { label: 'جرم و وزن', icon: '⚖️', type: 'mass' },
      { label: 'حجم و چگالی', icon: '🧪', type: 'density' },
      { label: 'خطا و دقت', icon: '🎯', type: 'error' },
      { label: 'ساعت', icon: '⏰', type: 'clock' },
      { label: 'آزمون جامع', icon: '📝', type: 'quiz' }
    ];
    items.forEach(function (it) {
      var b = el('button', 'home-card');
      var ic = el('span', 'icon', it.icon);
      b.appendChild(ic);
      b.appendChild(document.createTextNode(it.label));
      b.onclick = function () {
        var sections = root.querySelectorAll('section');
        for (var i = 0; i < sections.length; i++) {
          if (sections[i].getAttribute('data-type') === it.type) {
            if (window.__openSection) window.__openSection(sections[i]);
            return;
          }
        }
      };
      grid.appendChild(b);
    });
  }

  // ============================================================
  // TOOLS — shapes + matching game
  // ============================================================
  var TOOLS = [
    { name: 'خط‌کش', purpose: 'اندازه‌گیری طول', unit: 'سانتی‌متر', cat: 'طول', kind: 'ruler' },
    { name: 'کولیس', purpose: 'اندازه‌گیری دقیق طول', unit: 'میلی‌متر', cat: 'طول', kind: 'caliper' },
    { name: 'ریزسنج', purpose: 'اندازه‌گیری قطر دقیق', unit: 'میلی‌متر (۰.۰۱)', cat: 'طول', kind: 'micrometer' },
    { name: 'ترازو', purpose: 'اندازه‌گیری جرم', unit: 'گرم / کیلوگرم', cat: 'جرم', kind: 'scale' },
    { name: 'نیروسنج', purpose: 'اندازه‌گیری وزن', unit: 'نیوتن', cat: 'وزن', kind: 'forcemeter' },
    { name: 'استوانه مدرج', purpose: 'اندازه‌گیری حجم مایع', unit: 'میلی‌لیتر', cat: 'حجم', kind: 'cylinder' },
    { name: 'پی‌پت', purpose: 'برداشتن حجم دقیق', unit: 'میلی‌لیتر', cat: 'حجم', kind: 'pipette' },
    { name: 'دماسنج', purpose: 'اندازه‌گیری دما', unit: 'درجه سلسیوس', cat: 'دما', kind: 'thermometer' }
  ];
  var CATS = ['طول', 'جرم', 'وزن', 'حجم', 'دما'];

  function toolSvg(kind) {
    var color = '#3C4458', light = '#E4E6EE';
    switch (kind) {
      case 'ruler':
        return '<svg viewBox="0 0 200 60" width="200"><rect x="0" y="10" width="200" height="40" fill="#F5D746" stroke="' + color + '" stroke-width="2"/>' + Array.from({length: 11}, function(_, k) { return '<line x1="' + (k * 20) + '" y1="10" x2="' + (k * 20) + '" y2="' + (k % 2 === 0 ? 30 : 24) + '" stroke="' + color + '" stroke-width="1.5"/>'; }).join('') + '</svg>';
      case 'caliper':
        return '<svg viewBox="0 0 200 80" width="200"><rect x="10" y="35" width="180" height="10" fill="#AAB0BE" stroke="' + color + '"/><rect x="10" y="10" width="10" height="60" fill="#8E94A4" stroke="' + color + '"/><rect x="180" y="10" width="10" height="60" fill="#8E94A4" stroke="' + color + '"/><circle cx="100" cy="30" r="14" fill="#fff" stroke="' + color + '"/><line x1="100" y1="30" x2="112" y2="18" stroke="#D03C3C" stroke-width="2"/></svg>';
      case 'micrometer':
        return '<svg viewBox="0 0 200 80" width="200"><rect x="10" y="30" width="20" height="30" fill="#7C8296" stroke="' + color + '"/><rect x="30" y="35" width="100" height="20" fill="' + light + '" stroke="' + color + '"/><rect x="130" y="25" width="50" height="40" fill="#8E94A4" stroke="' + color + '"/><line x1="130" y1="45" x2="180" y2="45" stroke="' + color + '" stroke-dasharray="2,2"/></svg>';
      case 'scale':
        return '<svg viewBox="0 0 200 100" width="200"><rect x="30" y="80" width="140" height="12" fill="#3E4450"/><rect x="95" y="30" width="10" height="50" fill="#7C8296"/><rect x="30" y="25" width="140" height="10" fill="#B4B9C6" stroke="' + color + '"/><rect x="70" y="5" width="20" height="20" fill="#E6A93C"/></svg>';
      case 'forcemeter':
        return '<svg viewBox="0 0 200 140" width="200"><rect x="80" y="10" width="40" height="110" fill="#ECEEF4" stroke="' + color + '" stroke-width="2"/>' + Array.from({length: 10}, function(_, k) { return '<line x1="80" y1="' + (20 + k * 10) + '" x2="' + (80 + (k % 5 === 0 ? 20 : 12)) + '" y2="' + (20 + k * 10) + '" stroke="' + color + '"/>'; }).join('') + '<line x1="80" y1="60" x2="120" y2="60" stroke="#D03C3C" stroke-width="3"/><circle cx="100" cy="130" r="8" fill="#7C8296" stroke="' + color + '"/></svg>';
      case 'cylinder':
        return '<svg viewBox="0 0 120 180" width="120"><rect x="20" y="10" width="80" height="150" fill="rgba(225,238,250,0.6)" stroke="' + color + '" stroke-width="2"/><rect x="22" y="90" width="76" height="68" fill="rgba(70,140,230,0.55)"/>' + Array.from({length: 10}, function(_, k) { return '<line x1="20" y1="' + (20 + k * 14) + '" x2="' + (20 + (k % 5 === 0 ? 16 : 8)) + '" y2="' + (20 + k * 14) + '" stroke="' + color + '"/>'; }).join('') + '</svg>';
      case 'pipette':
        return '<svg viewBox="0 0 80 160" width="80"><circle cx="40" cy="20" r="14" fill="#D03C3C"/><rect x="30" y="34" width="20" height="80" fill="#F0F6FB" stroke="' + color + '"/><rect x="32" y="70" width="16" height="42" fill="#5A9AE6"/><line x1="30" y1="114" x2="40" y2="140" stroke="' + color + '"/><line x1="50" y1="114" x2="40" y2="140" stroke="' + color + '"/><circle cx="40" cy="145" r="6" fill="#5A9AE6"/></svg>';
      case 'thermometer':
        return '<svg viewBox="0 0 80 180" width="80"><circle cx="40" cy="150" r="20" fill="#D03C3C" stroke="' + color + '" stroke-width="2"/><rect x="30" y="10" width="20" height="140" fill="#FAFAFC" stroke="' + color + '" stroke-width="2"/><rect x="36" y="60" width="8" height="90" fill="#D03C3C"/>' + Array.from({length: 10}, function(_, k) { return '<line x1="50" y1="' + (20 + k * 12) + '" x2="' + (50 + (k % 2 === 0 ? 14 : 8)) + '" y2="' + (20 + k * 12) + '" stroke="' + color + '"/>'; }).join('') + '</svg>';
      default:
        return '<div style="font-size:60px">🔧</div>';
    }
  }

  function initTools(root) {
    var sec = root.querySelector('section[data-renderer="tools8"]');
    if (!sec) return;
    var wrap = sec.querySelector('#tools-wrap');
    var mode = 0, sel = 0;
    var order = [], round = 0, score = 0, answered = false, clicked = -1, correctOpt = 0;

    function renderShow() {
      wrap.innerHTML = '';
      var list = el('div', 'tool-list');
      TOOLS.forEach(function (t, i) {
        var b = el('button', 'tool-item' + (i === sel ? ' sel' : ''), t.name);
        b.onclick = function () { sel = i; renderShow(); };
        list.appendChild(b);
      });
      wrap.appendChild(list);

      var card = el('div', 'tool-card');
      card.appendChild(el('div', 'name', TOOLS[sel].name));
      var svgDiv = el('div');
      svgDiv.innerHTML = toolSvg(TOOLS[sel].kind);
      card.appendChild(svgDiv);
      card.appendChild(el('div', 'purpose', 'کاربرد: ' + TOOLS[sel].purpose));
      card.appendChild(el('div', 'unit', 'یکا: ' + TOOLS[sel].unit));
      wrap.appendChild(card);
      wrap.appendChild(el('div', 'tool-hint', 'یک ابزار را انتخاب کنید تا شکل و کاربرد آن را ببینید'));

      var gb = el('button', 'btn-sm green', 'شروع بازی تطبیق');
      gb.style.marginTop = '12px';
      gb.onclick = function () {
        mode = 1;
        order = shuffle(TOOLS.map(function (_, i) { return i; }));
        round = 0; score = 0;
        setupRound();
      };
      wrap.appendChild(gb);
    }

    function setupRound() {
      var t = order[round];
      var correctCat = TOOLS[t].cat;
      var wrongCats = CATS.filter(function (c) { return c !== correctCat; });
      var opts = shuffle([correctCat, wrongCats[0], wrongCats[1], wrongCats[2]]);
      correctOpt = opts.indexOf(correctCat);
      answered = false;
      clicked = -1;
      renderGame(t, opts);
    }

    function renderGame(toolIdx, opts) {
      wrap.innerHTML = '';
      var info = el('div', 'tool-game-info');
      info.appendChild(document.createTextNode('دور ' + toFa(round + 1) + ' از ' + toFa(8) + ' — '));
      var sc = el('span', 'tool-game-score', 'امتیاز: ' + toFa(score));
      info.appendChild(sc);
      wrap.appendChild(info);

      var svgBox = el('div', 'tool-game-svg');
      svgBox.innerHTML = toolSvg(TOOLS[toolIdx].kind);
      wrap.appendChild(svgBox);

      wrap.appendChild(el('div', 'tool-game-info', 'این ابزار برای اندازه‌گیری چه کمیتی است؟ (' + TOOLS[toolIdx].name + ')'));

      var grid = el('div', 'tool-game-opts');
      opts.forEach(function (cat, i) {
        var b = el('button', 'tool-game-opt', cat);
        b.onclick = function () {
          if (answered) return;
          answered = true;
          clicked = i;
          var buttons = grid.querySelectorAll('.tool-game-opt');
          buttons.forEach(function (btn, bi) {
            btn.disabled = true;
            if (bi === correctOpt) btn.classList.add('correct');
            else if (bi === i) btn.classList.add('wrong');
          });
          if (i === correctOpt) score++;
          setTimeout(function () {
            round++;
            if (round >= 8) {
              renderFinal();
            } else setupRound();
          }, 900);
        };
        grid.appendChild(b);
      });
      wrap.appendChild(grid);
    }

    function renderFinal() {
      wrap.innerHTML = '';
      var f = el('div', 'quiz-final');
      f.appendChild(el('h3', null, 'نتیجه بازی'));
      var bar = el('div', 'score-bar');
      var fill = el('div');
      fill.style.width = (score / 8 * 100) + '%';
      bar.appendChild(fill);
      f.appendChild(bar);
      f.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(8)));
      var again = el('button', 'btn-sm green', 'بازی جدید');
      again.style.marginTop = '20px';
      again.onclick = function () {
        order = shuffle(TOOLS.map(function (_, i) { return i; }));
        round = 0; score = 0;
        setupRound();
      };
      f.appendChild(again);
      var back = el('button', 'btn-sm gray', 'بازگشت به ابزارها');
      back.style.marginTop = '10px';
      back.onclick = function () { mode = 0; renderShow(); };
      f.appendChild(back);
      wrap.appendChild(f);
      if (score >= 6) confettiBurst();
    }

    renderShow();
  }

  // ============================================================
  // MEASURE — read 10 tools
  // ============================================================
  var MTOOLS = [
    { name: 'خط‌کش', unit: 'cm', lo: 1, hi: 15, step: 0.1, tol: 0.5, dec: 1 },
    { name: 'کولیس', unit: 'mm', lo: 5, hi: 25, step: 0.1, tol: 0.5, dec: 1 },
    { name: 'ریزسنج', unit: 'mm', lo: 0.1, hi: 2.5, step: 0.01, tol: 0.05, dec: 2 },
    { name: 'ترازو', unit: 'g', lo: 10, hi: 500, step: 0.1, tol: 2, dec: 1 },
    { name: 'نیروسنج', unit: 'N', lo: 0.5, hi: 20, step: 0.1, tol: 0.2, dec: 1 },
    { name: 'استوانه مدرج', unit: 'ml', lo: 10, hi: 100, step: 1, tol: 3, dec: 0 },
    { name: 'پی‌پت', unit: 'ml', lo: 1, hi: 10, step: 0.1, tol: 0.3, dec: 1 },
    { name: 'دماسنج', unit: '°C', lo: -10, hi: 60, step: 1, tol: 1, dec: 0 },
    { name: 'متر نواری', unit: 'cm', lo: 50, hi: 500, step: 1, tol: 2, dec: 0 },
    { name: 'کرنومتر', unit: 's', lo: 1, hi: 30, step: 0.1, tol: 0.2, dec: 2 }
  ];

  function initMeasure(root) {
    var sec = root.querySelector('section[data-renderer="measure10"]');
    if (!sec) return;
    var wrap = sec.querySelector('#meas-wrap');
    var tool = 0, score = 0, value = 0, res = 0, done = false;

    function newValue() {
      var t = MTOOLS[tool];
      var n = Math.round((t.hi - t.lo) / t.step);
      value = t.lo + Math.floor(Math.random() * (n + 1)) * t.step;
      value = Math.round(value / t.step) * t.step;
    }

    function renderToolSvg(t, v) {
      var dk = '#282D3C';
      if (t.name === 'خط‌کش') {
        var left = 10, w = 340, h = 70;
        var bw = v * 20;
        var s = '<svg viewBox="0 0 360 100" width="100%"><rect x="' + left + '" y="20" width="' + w + '" height="50" fill="#F5D746" stroke="' + dk + '" stroke-width="2"/><rect x="' + left + '" y="0" width="' + bw + '" height="18" fill="#8C50B4" opacity="0.85"/>';
        for (var k = 0; k <= 160; k++) {
          var x = left + k * 2.1;
          var len = k % 10 === 0 ? 18 : (k % 5 === 0 ? 12 : 7);
          s += '<line x1="' + x + '" y1="20" x2="' + x + '" y2="' + (20 + len) + '" stroke="' + dk + '" stroke-width="0.8"/>';
        }
        for (var k2 = 0; k2 <= 15; k2++) {
          s += '<text x="' + (left + k2 * 21) + '" y="85" font-size="9" text-anchor="middle" fill="' + dk + '">' + k2 + '</text>';
        }
        s += '</svg>';
        return s;
      }
      if (t.name === 'دماسنج') {
        var bot = 140, pp = 100 / 70;
        var my = bot - (v + 10) * pp;
        var s = '<svg viewBox="0 0 120 180" width="120"><circle cx="60" cy="150" r="20" fill="#D03C3C" stroke="' + dk + '" stroke-width="2"/><rect x="50" y="10" width="20" height="140" fill="#FAFAFC" stroke="' + dk + '" stroke-width="2"/><rect x="56" y="' + my + '" width="8" height="' + (150 - my) + '" fill="#D03C3C"/>';
        for (var T = -10; T <= 60; T += 5) {
          var yy = bot - (T + 10) * pp;
          var len = T % 10 === 0 ? 16 : 8;
          s += '<line x1="70" y1="' + yy + '" x2="' + (70 + len) + '" y2="' + yy + '" stroke="' + dk + '"/>';
          if (T % 10 === 0) s += '<text x="' + (70 + len + 4) + '" y="' + (yy + 3) + '" font-size="8" fill="' + dk + '">' + T + '</text>';
        }
        s += '</svg>';
        return s;
      }
      if (t.name === 'استوانه مدرج' || t.name === 'پی‌پت') {
        var bot2 = 180;
        var h2 = v * 1.5;
        var s = '<svg viewBox="0 0 120 220" width="120"><rect x="30" y="10" width="60" height="180" fill="rgba(225,238,250,0.6)" stroke="' + dk + '" stroke-width="2"/><rect x="32" y="' + (bot2 - h2 + 10) + '" width="56" height="' + h2 + '" fill="rgba(70,140,230,0.6)"/>';
        for (var ml = 0; ml <= 100; ml += 10) {
          var yy2 = bot2 + 10 - ml * 1.5;
          s += '<line x1="30" y1="' + yy2 + '" x2="46" y2="' + yy2 + '" stroke="' + dk + '"/>';
          s += '<text x="50" y="' + (yy2 + 3) + '" font-size="7" fill="' + dk + '">' + ml + '</text>';
        }
        s += '</svg>';
        return s;
      }
      if (t.name === 'ترازو') {
        return '<svg viewBox="0 0 200 120" width="100%"><rect x="20" y="20" width="160" height="70" fill="#181C22" rx="4"/><text x="100" y="65" text-anchor="middle" font-size="20" font-family="monospace" fill="#50FF7A">' + v.toFixed(1) + ' g</text></svg>';
      }
      if (t.name === 'کرنومتر') {
        return '<svg viewBox="0 0 200 160" width="200"><circle cx="100" cy="85" r="70" fill="#282D3C" stroke="' + dk + '" stroke-width="3"/><circle cx="100" cy="85" r="64" fill="#fff"/><text x="100" y="95" text-anchor="middle" font-size="26" font-family="monospace" fill="' + dk + '">' + v.toFixed(2) + 's</text></svg>';
      }
      if (t.name === 'کولیس' || t.name === 'ریزسنج') {
        return '<svg viewBox="0 0 250 120" width="100%"><rect x="20" y="55" width="210" height="12" fill="#AAB0BE" stroke="' + dk + '"/><rect x="20" y="30" width="12" height="65" fill="#8E94A4" stroke="' + dk + '"/><rect x="218" y="30" width="12" height="65" fill="#8E94A4" stroke="' + dk + '"/><text x="125" y="110" text-anchor="middle" font-size="16" font-family="monospace" fill="' + dk + '">' + v.toFixed(2) + ' mm</text></svg>';
      }
      if (t.name === 'نیروسنج') {
        return '<svg viewBox="0 0 200 160" width="140"><rect x="70" y="10" width="60" height="140" fill="#ECEEF4" stroke="' + dk + '" stroke-width="2"/><text x="100" y="90" text-anchor="middle" font-size="22" font-family="monospace" fill="' + dk + '">' + v.toFixed(1) + 'N</text></svg>';
      }
      if (t.name === 'متر نواری') {
        return '<svg viewBox="0 0 200 100" width="100%"><rect x="20" y="40" width="160" height="20" fill="#F5D746" stroke="' + dk + '"/><text x="100" y="55" text-anchor="middle" font-size="12" fill="' + dk + '">' + v.toFixed(0) + ' cm</text></svg>';
      }
      return '<div>' + v + '</div>';
    }

    function renderQuestion() {
      wrap.innerHTML = '';
      var t = MTOOLS[tool];
      var head = el('div', 'meas-header');
      head.appendChild(el('div', null, 'ابزار ' + toFa(tool + 1) + ' از ۱۰'));
      head.appendChild(el('div', null, 'امتیاز: ' + toFa(score) + ' از ۱۰'));
      wrap.appendChild(head);

      wrap.appendChild(el('div', 'meas-tool-name', t.name));
      var svgBox = el('div', 'meas-svg');
      svgBox.innerHTML = renderToolSvg(t, value);
      wrap.appendChild(svgBox);

      wrap.appendChild(el('div', 'meas-tool-name', 'عدد روی ' + t.name + ' را بخوانید و وارد کنید'));

      var row = el('div', 'meas-input-row');
      var inp = document.createElement('input');
      inp.className = 'meas-input' + (res === 1 ? ' correct' : res === 2 ? ' wrong' : '');
      inp.type = 'text';
      inp.inputMode = 'decimal';
      inp.placeholder = 'عدد را وارد کنید';
      inp.disabled = res !== 0;
      row.appendChild(inp);
      row.appendChild(el('div', 'meas-unit', t.unit));
      wrap.appendChild(row);

      var actions = el('div', 'meas-actions');
      var ok = el('button', 'btn-sm green', 'تایید');
      ok.onclick = function () {
        if (res !== 0) return;
        var v = parseFloat(inp.value);
        if (isNaN(v)) return;
        if (Math.abs(v - value) <= t.tol + 0.0001) {
          res = 1; score++;
        } else {
          res = 2;
        }
        setTimeout(function () {
          tool++;
          if (tool >= 10) { done = true; renderFinal(); }
          else { newValue(); res = 0; renderQuestion(); }
        }, 1200);
      };
      actions.appendChild(ok);
      var skip = el('button', 'btn-sm gray', 'رد کردن');
      skip.onclick = function () {
        tool++;
        if (tool >= 10) { done = true; renderFinal(); }
        else { newValue(); res = 0; renderQuestion(); }
      };
      actions.appendChild(skip);
      wrap.appendChild(actions);

      if (res === 1) {
        wrap.appendChild(el('div', 'meas-feedback ok', 'آفرین!'));
      } else if (res === 2) {
        wrap.appendChild(el('div', 'meas-feedback bad', 'جواب درست: ' + value.toFixed(t.dec) + ' ' + t.unit));
      }
    }

    function renderFinal() {
      wrap.innerHTML = '';
      var f = el('div', 'quiz-final');
      f.appendChild(el('h3', null, 'نتیجه اندازه‌گیری'));
      var bar = el('div', 'score-bar');
      var fill = el('div');
      fill.style.width = (score / 10 * 100) + '%';
      bar.appendChild(fill);
      f.appendChild(bar);
      f.appendChild(el('div', 'score-line', toFa(score) + ' از ۱۰'));
      var again = el('button', 'btn-sm green', 'بازی جدید');
      again.style.marginTop = '20px';
      again.onclick = function () { tool = 0; score = 0; res = 0; newValue(); renderQuestion(); };
      f.appendChild(again);
      wrap.appendChild(f);
      if (score >= 7) confettiBurst();
    }

    newValue();
    renderQuestion();
  }

  // ============================================================
  // MASS — draw object to scale, compare planets
  // ============================================================
  var MASSES = [0.1, 0.5, 1.0, 5.0];
  var MASS_LABELS = ['۱۰۰ گرم', '۵۰۰ گرم', '۱ کیلوگرم', '۵ کیلوگرم'];
  var PLANETS = [
    { name: 'زمین', g: 9.8, color: '#3C8CDC' },
    { name: 'ماه', g: 1.6, color: '#B4B4B4' },
    { name: 'مریخ', g: 3.7, color: '#C8643C' },
    { name: 'مشتری', g: 24.8, color: '#C8A064' }
  ];

  function initMass(root) {
    var sec = root.querySelector('section[data-renderer="massplanet"]');
    if (!sec) return;
    var wrap = sec.querySelector('#mass-wrap');
    var massIdx = 0, useCustom = false, customMass = 0, onScale = false;

    function currentMass() { return useCustom ? customMass : MASSES[massIdx]; }

    function render() {
      wrap.innerHTML = '';
      var btnGrid = el('div', 'mass-mass-btns');
      MASS_LABELS.forEach(function (lb, i) {
        var b = el('button', 'mass-mass-btn' + (!useCustom && i === massIdx ? ' sel' : ''), lb);
        b.onclick = function () { massIdx = i; useCustom = false; render(); };
        btnGrid.appendChild(b);
      });
      wrap.appendChild(btnGrid);

      var row = el('div', 'mass-custom-row');
      var inp = document.createElement('input');
      inp.type = 'text';
      inp.inputMode = 'decimal';
      inp.placeholder = 'یا جرم دلخواه (kg) مثلاً 2.5';
      if (useCustom) inp.value = customMass;
      row.appendChild(inp);
      var go = el('button', null, 'محاسبه');
      go.onclick = function () {
        var v = parseFloat(inp.value);
        if (isNaN(v) || v <= 0) return;
        if (v > 1000) v = 1000;
        customMass = v;
        useCustom = true;
        render();
      };
      row.appendChild(go);
      wrap.appendChild(row);

      var area = el('div', 'mass-scale-area');
      var obj = el('div', 'mass-obj' + (onScale ? ' on-scale' : ''), currentMass() + ' kg');
      var display = el('div', 'mass-scale-display', onScale ? currentMass().toFixed(1) + ' kg' : '0.0 kg');
      var plate = el('div', 'mass-scale-plate');
      area.appendChild(obj);
      area.appendChild(plate);
      area.appendChild(display);
      wrap.appendChild(area);

      if (!onScale) {
        var dragStart = false;
        var offsetX = 0, offsetY = 0;
        function pointFromEvent(e) {
          var rect = area.getBoundingClientRect();
          var p = e.touches ? e.touches[0] : e;
          return { x: p.clientX - rect.left, y: p.clientY - rect.top };
        }
        function down(e) {
          var p = pointFromEvent(e);
          var orect = obj.getBoundingClientRect();
          var arect = area.getBoundingClientRect();
          offsetX = p.x - (orect.left - arect.left);
          offsetY = p.y - (orect.top - arect.top);
          dragStart = true;
          obj.classList.add('dragging');
          e.preventDefault();
        }
        function move(e) {
          if (!dragStart) return;
          var p = pointFromEvent(e);
          obj.style.left = (p.x - offsetX) + 'px';
          obj.style.top = (p.y - offsetY) + 'px';
          obj.style.right = 'auto';
          e.preventDefault();
        }
        function up() {
          if (!dragStart) return;
          dragStart = false;
          obj.classList.remove('dragging');
          var orect = obj.getBoundingClientRect();
          var prect = plate.getBoundingClientRect();
          if (Math.abs(orect.left + orect.width / 2 - (prect.left + prect.width / 2)) < 100 &&
              Math.abs(orect.top + orect.height - prect.top) < 80) {
            onScale = true;
            render();
          } else {
            obj.style.left = 'auto';
            obj.style.right = '20px';
            obj.style.top = '20px';
          }
        }
        obj.addEventListener('mousedown', down);
        obj.addEventListener('touchstart', down, { passive: false });
        document.addEventListener('mousemove', move);
        document.addEventListener('touchmove', move, { passive: false });
        document.addEventListener('mouseup', up);
        document.addEventListener('touchend', up);
      }

      var planets = el('div', 'mass-planets');
      var maxW = currentMass() * 24.8;
      PLANETS.forEach(function (p) {
        var weight = currentMass() * p.g;
        var row = el('div', 'mass-planet-row');
        var nm = el('div', 'mass-planet-name', p.name);
        nm.style.color = p.color;
        row.appendChild(nm);
        row.appendChild(el('div', 'mass-planet-g', 'g=' + p.g));
        var bar = el('div', 'mass-bar');
        var fill = el('div');
        fill.style.background = p.color;
        fill.style.width = onScale ? (weight / maxW * 100) + '%' : '0%';
        bar.appendChild(fill);
        row.appendChild(bar);
        row.appendChild(el('div', 'mass-weight-val', onScale ? weight.toFixed(weight < 10 ? 2 : 1) + ' N' : ''));
        planets.appendChild(row);
      });
      wrap.appendChild(planets);
    }
    render();
  }

  // ============================================================
  // DENSITY — pick material, weigh, drop in water
  // ============================================================
  var MATS = [
    { name: 'چوب', d: 0.6, color: '#A06E3C' },
    { name: 'یخ', d: 0.9, color: '#BEE1F0' },
    { name: 'پلاستیک', d: 0.95, color: '#6EB4DC' },
    { name: 'آلومینیوم', d: 2.7, color: '#B4B4BE' },
    { name: 'آهن', d: 7.8, color: '#50505A' },
    { name: 'طلا', d: 19.3, color: '#DCB432' }
  ];

  function initDensity(root) {
    var sec = root.querySelector('section[data-renderer="density6"]');
    if (!sec) return;
    var wrap = sec.querySelector('#dens-wrap');
    var sel = -1, stage = 0, measured = false, floating = false, settled = false;

    function render() {
      wrap.innerHTML = '';
      var grid = el('div', 'dens-mats');
      MATS.forEach(function (m, i) {
        var b = el('button', 'dens-mat' + (i === sel ? ' sel' : ''));
        var sw = el('div', 'dens-swatch');
        sw.style.background = m.color;
        b.appendChild(sw);
        b.appendChild(document.createTextNode(m.name));
        b.onclick = function () { sel = i; stage = 0; measured = false; floating = false; settled = false; render(); };
        grid.appendChild(b);
      });
      wrap.appendChild(grid);

      var area = el('div', 'dens-beaker-area');
      if (sel >= 0) {
        var obj = el('div', 'dens-obj');
        obj.style.background = MATS[sel].color;
        obj.style.border = '2px solid ' + darken(MATS[sel].color);
        var startTop = 10;
        var startLeft = 20;
        obj.style.top = startTop + 'px';
        obj.style.left = startLeft + 'px';
        if (stage === 2 && floating) {
          obj.style.left = 'calc(50% - 25px)';
          obj.style.top = (area.clientHeight - 100) + 'px';
        }
        area.appendChild(obj);

        var beaker = el('div', 'dens-beaker');
        var water = el('div', 'dens-water');
        beaker.appendChild(water);
        area.appendChild(beaker);

        var scaleDisp = el('div', 'dens-scale', measured ? (MATS[sel].d * 8).toFixed(1) + ' g' : '0.0 g');
        area.appendChild(scaleDisp);

        if (stage < 2) {
          var dragStart = false, offX = 0, offY = 0;
          function pointFromEvent(e) {
            var rect = area.getBoundingClientRect();
            var p = e.touches ? e.touches[0] : e;
            return { x: p.clientX - rect.left, y: p.clientY - rect.top };
          }
          function down(e) {
            var p = pointFromEvent(e);
            var orect = obj.getBoundingClientRect();
            var arect = area.getBoundingClientRect();
            offX = p.x - (orect.left - arect.left);
            offY = p.y - (orect.top - arect.top);
            dragStart = true;
            obj.classList.add('dragging');
            e.preventDefault();
          }
          function move(e) {
            if (!dragStart) return;
            var p = pointFromEvent(e);
            obj.style.left = (p.x - offX) + 'px';
            obj.style.top = (p.y - offY) + 'px';
            e.preventDefault();
          }
          function up() {
            if (!dragStart) return;
            dragStart = false;
            obj.classList.remove('dragging');
            var orect = obj.getBoundingClientRect();
            var arect = area.getBoundingClientRect();
            var cx = orect.left + orect.width / 2 - arect.left;
            var cy = orect.top + orect.height / 2 - arect.top;
            if (stage === 0) {
              if (cx < 80 && cy > arect.height - 120) {
                stage = 1; measured = true;
                render();
              } else {
                obj.style.top = '10px'; obj.style.left = '20px';
              }
            } else if (stage === 1) {
              if (Math.abs(cx - arect.width / 2) < 100 && cy > arect.height - 200) {
                stage = 2;
                floating = MATS[sel].d < 1;
                settled = floating ? false : true;
                setTimeout(function () { render(); }, 500);
              } else {
                obj.style.top = (arect.height - 100) + 'px'; obj.style.left = '20px';
              }
            }
          }
          obj.addEventListener('mousedown', down);
          obj.addEventListener('touchstart', down, { passive: false });
          document.addEventListener('mousemove', move);
          document.addEventListener('touchmove', move, { passive: false });
          document.addEventListener('mouseup', up);
          document.addEventListener('touchend', up);
        }
      }
      wrap.appendChild(area);

      if (sel >= 0) {
        if (stage === 0) wrap.appendChild(el('div', 'quiz-meta', 'جسم را روی ترازو بکشید (گوشه پایین چپ)'));
        else if (stage === 1) wrap.appendChild(el('div', 'quiz-meta', 'جسم را بالای لیوان بکشید و رها کنید'));
        else {
          var res = el('div', 'dens-result ' + (floating ? 'float' : 'sink'));
          res.textContent = (floating ? 'شناور می‌ماند' : 'غرق می‌شود') + ' — چگالی: ' + MATS[sel].d.toFixed(2) + ' g/cm³';
          wrap.appendChild(res);
        }
      }

      var bars = el('div', 'dens-bars');
      var maxD = 19.3;
      MATS.forEach(function (m) {
        var row = el('div', 'dens-bar-row');
        row.appendChild(el('div', 'dens-bar-name', m.name));
        var track = el('div', 'dens-bar-track');
        var fill = el('div', 'dens-bar-fill');
        fill.style.background = m.color;
        fill.style.width = (m.d / maxD * 100) + '%';
        track.appendChild(fill);
        row.appendChild(track);
        row.appendChild(el('div', 'dens-bar-val', m.d.toFixed(2) + ' g/cm³'));
        bars.appendChild(row);
      });
      wrap.appendChild(bars);
    }

    function darken(hex) {
      var h = hex.replace('#', '');
      var r = Math.max(0, parseInt(h.substring(0, 2), 16) - 60);
      var g = Math.max(0, parseInt(h.substring(2, 4), 16) - 60);
      var b = Math.max(0, parseInt(h.substring(4, 6), 16) - 60);
      return 'rgb(' + r + ',' + g + ',' + b + ')';
    }

    render();
  }

  // ============================================================
  // ERROR — 3 scenarios (ruler, thermometer, scale precision)
  // ============================================================
  function initError(root) {
    var sec = root.querySelector('section[data-renderer="error3"]');
    if (!sec) return;
    var wrap = sec.querySelector('#err-wrap');
    var scn = 0, sel = -1, score = 0, answered = false;
    var slots = [];

    var scenarios = [
      {
        q: 'روی خط‌کشی که دقیق‌ترین گزارش را می‌دهد کلیک کنید',
        n: 3,
        good: 2,
        labels: ['خط‌کش A', 'خط‌کش B', 'خط‌کش C'],
        render: function (o) {
          var reps = ['۵ سانتی‌متر', '۵.۳ سانتی‌متر', '۵.۳۰ سانتی‌متر'];
          var accs = ['۱ سانتی‌متر', '۱ میلی‌متر', '۰.۱ میلی‌متر'];
          return '<div style="padding:8px 0">' + rulerSvg(o) + '</div>' +
            '<div class="err-slot-report">گزارش: ' + reps[o] + '</div>' +
            (answered ? '<div class="err-slot-acc">دقت ابزار: ' + accs[o] + '</div>' : '');
        }
      },
      {
        q: 'کدام دماسنج دقیق‌تر است؟',
        n: 2,
        good: 1,
        labels: ['دماسنج A', 'دماسنج B'],
        render: function (o) {
          return '<div style="padding:8px 0">' + thermo(o) + '</div>' +
            '<div class="err-slot-report">گزارش: ۲۵ درجه</div>' +
            (answered ? '<div class="err-slot-acc">' + (o === 0 ? 'تقسیمات ۱۰ درجه‌ای' : 'تقسیمات ۱ درجه‌ای') + '</div>' : '');
        }
      },
      {
        q: 'کدام ترازو دقیق‌تر است؟',
        n: 2,
        good: 1,
        labels: ['ترازوی عقربه‌ای', 'ترازوی دیجیتال'],
        render: function (o) {
          if (o === 1) {
            return '<div style="padding:24px"><div style="background:#181C22;color:#50FF7A;padding:16px;border-radius:6px;font-family:monospace;font-size:20px;display:inline-block">25.34 g</div></div>';
          }
          return '<div style="padding:24px"><svg viewBox="0 0 200 120" width="200"><circle cx="100" cy="70" r="50" fill="#282D3C"/><circle cx="100" cy="70" r="46" fill="#fff"/><line x1="100" y1="70" x2="130" y2="40" stroke="#D03C3C" stroke-width="3"/><circle cx="100" cy="70" r="4" fill="#282D3C"/></svg></div>';
        }
      }
    ];

    function rulerSvg(o) {
      var dk = '#282D3C';
      var s = '<svg viewBox="0 0 260 70" width="100%"><rect x="0" y="30" width="260" height="30" fill="#F5D746" stroke="' + dk + '"/>';
      if (o === 0) {
        for (var k = 0; k <= 6; k++) s += '<line x1="' + (k * 43) + '" y1="30" x2="' + (k * 43) + '" y2="60" stroke="' + dk + '"/>';
      } else if (o === 1) {
        for (var k = 0; k <= 65; k++) s += '<line x1="' + (k * 4) + '" y1="30" x2="' + (k * 4) + '" y2="' + (30 + (k % 10 === 0 ? 30 : (k % 5 === 0 ? 20 : 12))) + '" stroke="' + dk + '"/>';
      } else {
        for (var k = 0; k <= 260; k++) s += '<line x1="' + k + '" y1="30" x2="' + k + '" y2="' + (30 + (k % 40 === 0 ? 30 : (k % 4 === 0 ? 14 : 7))) + '" stroke="' + dk + '"/>';
      }
      s += '</svg>';
      return s;
    }

    function thermo(o) {
      var dk = '#282D3C';
      var s = '<svg viewBox="0 0 80 180" width="80"><circle cx="40" cy="150" r="20" fill="#D03C3C" stroke="' + dk + '"/><rect x="30" y="10" width="20" height="140" fill="#FAFAFC" stroke="' + dk + '"/><rect x="36" y="100" width="8" height="50" fill="#D03C3C"/>';
      if (o === 0) {
        for (var T = 0; T <= 50; T += 10) {
          var yy = 150 - T * 2.6;
          s += '<line x1="50" y1="' + yy + '" x2="64" y2="' + yy + '" stroke="' + dk + '"/>';
          s += '<text x="66" y="' + (yy + 3) + '" font-size="8" fill="' + dk + '">' + T + '</text>';
        }
      } else {
        for (var T = 0; T <= 50; T++) {
          var yy = 150 - T * 2.6;
          s += '<line x1="50" y1="' + yy + '" x2="' + (50 + (T % 5 === 0 ? 16 : 8)) + '" y2="' + yy + '" stroke="' + dk + '"/>';
        }
        for (var T2 = 0; T2 <= 50; T2 += 10) {
          s += '<text x="68" y="' + (153 - T2 * 2.6) + '" font-size="8" fill="' + dk + '">' + T2 + '</text>';
        }
      }
      s += '</svg>';
      return s;
    }

    function render() {
      wrap.innerHTML = '';
      if (scn >= scenarios.length) {
        var f = el('div', 'quiz-final');
        f.appendChild(el('h3', null, 'نتیجه'));
        f.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(scenarios.length)));
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () { scn = 0; score = 0; answered = false; sel = -1; render(); };
        f.appendChild(again);
        wrap.appendChild(f);
        if (score === scenarios.length) confettiBurst();
        return;
      }
      var sc = scenarios[scn];
      wrap.appendChild(el('div', 'err-scenario', 'سناریو ' + toFa(scn + 1) + ' از ' + toFa(scenarios.length)));
      wrap.appendChild(el('div', 'err-question', sc.q));

      var slotsWrap = el('div', 'err-slots');
      for (var s = 0; s < sc.n; s++) {
        var slot = el('div', 'err-slot');
        var isCorrect = s === sc.good;
        var isSelected = answered && s === sel;
        if (isSelected) slot.classList.add(isCorrect ? 'sel-correct' : 'sel-wrong');
        if (answered && isCorrect) slot.classList.add('reveal-correct');
        slot.appendChild(el('div', 'err-slot-label', sc.labels[s]));
        var body = el('div');
        body.innerHTML = sc.render(s);
        slot.appendChild(body);
        (function (idx) {
          slot.onclick = function () {
            if (answered) return;
            sel = idx;
            answered = true;
            if (idx === sc.good) score++;
            render();
          };
        })(s);
        slotsWrap.appendChild(slot);
      }
      wrap.appendChild(slotsWrap);

      if (answered) {
        var ok = sel === sc.good;
        var fb = el('div', 'err-feedback ' + (ok ? 'ok' : 'bad'));
        fb.textContent = ok ? 'درست!' : 'این گزینه دقت کمتری دارد';
        wrap.appendChild(fb);
        var next = el('button', 'btn-sm green', scn === scenarios.length - 1 ? 'نتیجه' : 'بعدی');
        next.style.marginTop = '16px';
        next.onclick = function () { scn++; sel = -1; answered = false; render(); };
        wrap.appendChild(next);
      }
    }
    render();
  }

  // ============================================================
  // CLOCK — read analog clock + stopwatch
  // ============================================================
  function initClock(root) {
    var sec = root.querySelector('section[data-renderer="clockgame"]');
    if (!sec) return;
    var wrap = sec.querySelector('#clk-wrap');
    var mode = 0;
    var hour = 3, minute = 15, options = [], correctIdx = 0, selected = -1, answered = false;
    var score = 0, total = 0, done = false;
    var chronoStart = 0, chronoElapsed = 0, chronoRunning = false, chronoTimer = null;

    function newQuestion() {
      var mins = [0, 15, 30, 45];
      hour = Math.floor(Math.random() * 12) + 1;
      minute = mins[Math.floor(Math.random() * 4)];
      var correct = hour + ':' + (minute < 10 ? '0' : '') + minute;
      options = [correct];
      var guard = 0;
      while (options.length < 4 && guard < 200) {
        guard++;
        var h2 = hour, m2 = minute;
        var kind = Math.floor(Math.random() * 3);
        if (kind === 0) {
          h2 = ((hour - 1 + (Math.random() < 0.5 ? 1 : 11)) % 12) + 1;
        } else if (kind === 1) {
          m2 = mins[Math.floor(Math.random() * 4)];
        } else {
          h2 = Math.floor(Math.random() * 12) + 1;
          m2 = mins[Math.floor(Math.random() * 4)];
        }
        var s = h2 + ':' + (m2 < 10 ? '0' : '') + m2;
        if (options.indexOf(s) === -1) options.push(s);
      }
      var perm = shuffle([0, 1, 2, 3]);
      var tmp = options.slice();
      options = perm.map(function (i) { return tmp[i]; });
      correctIdx = options.indexOf(correct);
      selected = -1;
      answered = false;
    }

    function clockSvg(h, m) {
      var R = 130, cx = 130, cy = 130;
      var s = '<svg viewBox="0 0 260 260" width="260" height="260"><circle cx="' + cx + '" cy="' + cy + '" r="' + R + '" fill="#282D3C"/><circle cx="' + cx + '" cy="' + cy + '" r="' + (R - 4) + '" fill="#fff"/>';
      for (var i = 0; i < 60; i++) {
        var a = i * 6 * Math.PI / 180;
        var len = i % 5 === 0 ? 10 : 5;
        var x1 = cx + (R - 2) * Math.cos(a);
        var y1 = cy + (R - 2) * Math.sin(a);
        var x2 = cx + (R - 2 - len) * Math.cos(a);
        var y2 = cy + (R - 2 - len) * Math.sin(a);
        s += '<line x1="' + x1 + '" y1="' + y1 + '" x2="' + x2 + '" y2="' + y2 + '" stroke="#282D3C"/>';
      }
      for (var n = 1; n <= 12; n++) {
        var a2 = (n * 30 - 90) * Math.PI / 180;
        var nx = cx + 108 * Math.cos(a2);
        var ny = cy + 108 * Math.sin(a2);
        s += '<text x="' + nx + '" y="' + (ny + 6) + '" text-anchor="middle" font-size="16" font-weight="600" fill="#282D3C">' + n + '</text>';
      }
      var hAng = ((h % 12) * 30 + m * 0.5 - 90) * Math.PI / 180;
      var mAng = (m * 6 - 90) * Math.PI / 180;
      s += '<line x1="' + cx + '" y1="' + cy + '" x2="' + (cx + 65 * Math.cos(hAng)) + '" y2="' + (cy + 65 * Math.sin(hAng)) + '" stroke="#282D3C" stroke-width="5" stroke-linecap="round"/>';
      s += '<line x1="' + cx + '" y1="' + cy + '" x2="' + (cx + 92 * Math.cos(mAng)) + '" y2="' + (cy + 92 * Math.sin(mAng)) + '" stroke="#D03C3C" stroke-width="3" stroke-linecap="round"/>';
      s += '<circle cx="' + cx + '" cy="' + cy + '" r="6" fill="#282D3C"/></svg>';
      return s;
    }

    function render() {
      if (mode === 0) renderClockGame();
      else renderChrono();
    }

    function renderClockGame() {
      wrap.innerHTML = '';
      var tabs = el('div', 'clk-tabs');
      var t0 = el('button', 'clk-tab active', 'ساعت عقربه‌ای');
      t0.onclick = function () { mode = 0; render(); };
      var t1 = el('button', 'clk-tab', 'کرنومتر');
      t1.onclick = function () { mode = 1; render(); };
      tabs.appendChild(t0); tabs.appendChild(t1);
      wrap.appendChild(tabs);

      if (done) {
        var f = el('div', 'quiz-final');
        f.appendChild(el('h3', null, 'نتیجه'));
        f.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(10)));
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () { score = 0; total = 0; done = false; newQuestion(); render(); };
        f.appendChild(again);
        wrap.appendChild(f);
        return;
      }

      wrap.appendChild(el('div', 'clk-meta', 'سوال ' + toFa(total + (answered ? 0 : 1)) + ' از ۱۰'));
      var face = el('div', 'clk-face');
      face.innerHTML = clockSvg(hour, minute);
      wrap.appendChild(face);
      wrap.appendChild(el('div', 'clk-question', 'ساعت چند است؟'));

      var opts = el('div', 'clk-options');
      options.forEach(function (opt, i) {
        var b = el('button', 'clk-opt', opt);
        if (answered) {
          b.disabled = true;
          if (i === correctIdx) b.classList.add('correct');
          else if (i === selected) b.classList.add('wrong');
        }
        b.onclick = function () {
          if (answered) return;
          selected = i;
          answered = true;
          total++;
          if (i === correctIdx) score++;
          render();
          setTimeout(function () {
            if (total >= 10) { done = true; render(); }
            else { newQuestion(); render(); }
          }, 900);
        };
        opts.appendChild(b);
      });
      wrap.appendChild(opts);
    }

    function renderChrono() {
      wrap.innerHTML = '';
      var tabs = el('div', 'clk-tabs');
      var t0 = el('button', 'clk-tab', 'ساعت عقربه‌ای');
      t0.onclick = function () { mode = 0; render(); };
      var t1 = el('button', 'clk-tab active', 'کرنومتر');
      t1.onclick = function () { mode = 1; render(); };
      tabs.appendChild(t0); tabs.appendChild(t1);
      wrap.appendChild(tabs);

      var el2 = chronoRunning ? (Date.now() - chronoStart) : chronoElapsed;
      var mm = Math.floor(el2 / 60000);
      var ss = Math.floor((el2 / 1000) % 60);
      var cc = Math.floor((el2 % 1000) / 10);
      var disp = el('div', 'chrono-display', pad2(mm) + ':' + pad2(ss) + '.' + pad2(cc));
      wrap.appendChild(disp);

      var actions = el('div', 'chrono-actions');
      var main = el('button', 'chrono-btn ' + (chronoRunning ? 'stop' : 'start'), chronoRunning ? 'توقف' : 'شروع');
      main.onclick = function () {
        if (!chronoRunning) {
          chronoStart = Date.now() - chronoElapsed;
          chronoRunning = true;
          if (chronoTimer) clearInterval(chronoTimer);
          chronoTimer = setInterval(function () {
            if (!chronoRunning) return;
            var e = Date.now() - chronoStart;
            var m = Math.floor(e / 60000);
            var s = Math.floor((e / 1000) % 60);
            var c = Math.floor((e % 1000) / 10);
            disp.textContent = pad2(m) + ':' + pad2(s) + '.' + pad2(c);
          }, 30);
        } else {
          chronoElapsed = Date.now() - chronoStart;
          chronoRunning = false;
          main.textContent = 'شروع';
          main.className = 'chrono-btn start';
        }
        render();
      };
      actions.appendChild(main);
      var reset = el('button', 'chrono-btn reset', 'صفر');
      reset.onclick = function () {
        chronoRunning = false;
        chronoElapsed = 0;
        if (chronoTimer) { clearInterval(chronoTimer); chronoTimer = null; }
        render();
      };
      actions.appendChild(reset);
      wrap.appendChild(actions);
    }

    function pad2(n) { return n < 10 ? '0' + n : '' + n; }

    newQuestion();
    render();
  }

  // ============================================================
  // QUIZ — 16 questions
  // ============================================================
  var QUIZ = [
    { q: 'کدام یک از موارد زیر «کمیت» است؟', o: ['خط‌کش','طول','اندازه‌گیری','متر'], c: 1 },
    { q: 'یکای جرم در SI چیست؟', o: ['نیوتن','کیلوگرم','متر','لیتر'], c: 1 },
    { q: 'وزن یک جسم روی ماه نسبت به زمین چگونه است؟', o: ['بیشتر','کمتر','یکسان','صفر'], c: 1 },
    { q: 'یکای وزن در SI چیست؟', o: ['کیلوگرم','نیوتن','گرم','ژول'], c: 1 },
    { q: 'حجم مایع با کدام ابزار اندازه‌گیری می‌شود؟', o: ['ترازو','خط‌کش','استوانه مدرج','دماسنج'], c: 2 },
    { q: 'چگالی آب چند گرم بر سانتی‌متر مکعب است؟', o: ['0.5','1.0','7.8','19.3'], c: 1 },
    { q: 'جسمی با چگالی ۰.۸ در آب چه می‌کند؟', o: ['غرق می‌شود','شناور می‌ماند','محو می‌شود','منفجر می‌شود'], c: 1 },
    { q: 'دقت خط‌کش معمولی چقدر است؟', o: ['۱ سانتی‌متر','۱ میلی‌متر','۰.۰۱ میلی‌متر','۱ متر'], c: 1 },
    { q: 'کدام یک از ابزارهای دقیق اندازه‌گیری طول است؟', o: ['خط‌کش','متر نواری','ریزسنج','پارچه‌ای'], c: 2 },
    { q: 'هنگام خواندن استوانه مدرج به چه چیزی باید دقت کرد؟', o: ['رنگ مایع','هلال سطح مایع','دمای اتاق','ارتفاع استوانه'], c: 1 },
    { q: 'جرم ۵۰۰ گرم روی زمین، وزنش تقریباً چند نیوتن است؟', o: ['۰.۵','۵','۵۰','۵۰۰'], c: 1 },
    { q: 'کدام مورد خطای اندازه‌گیری نیست؟', o: ['خطای ابزار','خطای خواندن','خطای انسانی','محاسبه ذهنی'], c: 3 },
    { q: 'دماسنج برای اندازه‌گیری چه کمیتی است؟', o: ['جرم','طول','دما','حجم'], c: 2 },
    { q: 'چگالی آهن تقریباً چند برابر آب است؟', o: ['همان اندازه','دو برابر','حدود ۸ برابر','حدود ۲۰ برابر'], c: 2 },
    { q: 'کدام کمیت با نیروسنج اندازه‌گیری می‌شود؟', o: ['جرم','وزن','حجم','طول'], c: 1 },
    { q: 'واحد میلی‌لیتر برای اندازه‌گیری چه چیزی است؟', o: ['جرم','طول','حجم','زمان'], c: 2 }
  ];

  function initQuiz(root) {
    var sec = root.querySelector('section[data-renderer="quiz16"]');
    if (!sec) return;
    var wrap = sec.querySelector('#quiz-wrap');
    var cur = 0;
    var answers = new Array(QUIZ.length).fill(-1);
    var perm = [];

    function render() {
      wrap.innerHTML = '';
      var bar = el('div', 'quiz-progress');
      var fill = el('div');
      fill.style.width = ((cur + 1) / QUIZ.length * 100) + '%';
      bar.appendChild(fill);
      wrap.appendChild(bar);
      wrap.appendChild(el('div', 'quiz-meta', 'سوال ' + toFa(cur + 1) + ' از ' + toFa(QUIZ.length)));

      var q = QUIZ[cur];
      wrap.appendChild(el('div', 'quiz-question', q.q));

      if (perm[cur] == null) perm[cur] = shuffle([0, 1, 2, 3]);
      var opts = el('div', 'quiz-options');
      perm[cur].forEach(function (origIdx) {
        var b = el('button', 'quiz-opt', q.o[origIdx]);
        if (answers[cur] === origIdx) b.classList.add(origIdx === q.c ? 'correct' : 'wrong');
        b.onclick = function () { answers[cur] = origIdx; render(); };
        opts.appendChild(b);
      });
      wrap.appendChild(opts);

      var nav = el('div', 'quiz-nav');
      if (cur > 0) {
        var prev = el('button', 'btn-sm gray', 'قبلی');
        prev.onclick = function () { cur--; render(); };
        nav.appendChild(prev);
      }
      if (cur < QUIZ.length - 1) {
        var next = el('button', 'btn-sm green', 'بعدی');
        next.onclick = function () { cur++; render(); };
        nav.appendChild(next);
      } else {
        var fin = el('button', 'btn-sm red', 'اتمام آزمون');
        fin.onclick = renderFinal;
        nav.appendChild(fin);
      }
      wrap.appendChild(nav);
    }

    function renderFinal() {
      var score = 0;
      for (var i = 0; i < QUIZ.length; i++) if (answers[i] === QUIZ[i].c) score++;
      var s20 = Math.round(score * 20 / QUIZ.length);
      var pct = Math.round(score * 100 / QUIZ.length);
      wrap.innerHTML = '';
      var box = el('div', 'quiz-final');
      box.appendChild(el('h3', null, 'نتیجه آزمون'));
      var bar = el('div', 'score-bar');
      var fill = el('div');
      fill.style.width = pct + '%';
      bar.appendChild(fill);
      box.appendChild(bar);
      box.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(QUIZ.length) + ' پاسخ درست'));
      box.appendChild(el('div', 'score-line', 'نمره شما: ' + toFa(s20) + ' از ۲۰'));
      box.appendChild(el('div', 'score-line', 'درصد: ' + toFa(pct) + '٪'));
      var again = el('button', 'btn-sm green', 'آزمون جدید');
      again.style.marginTop = '20px';
      again.onclick = function () { cur = 0; answers = new Array(QUIZ.length).fill(-1); perm = []; render(); };
      box.appendChild(again);
      wrap.appendChild(box);
      if (pct >= 70) confettiBurst();
    }

    render();
  }

})();