(function () {
  "use strict";

  const tools = [
    { name: "خط‌کش", purpose: "اندازه‌گیری طول", unit: "سانتی‌متر", category: "طول", type: "ruler" },
    { name: "کولیس", purpose: "اندازه‌گیری دقیق طول", unit: "میلی‌متر", category: "طول", type: "caliper" },
    { name: "ریزسنج", purpose: "اندازه‌گیری قطر دقیق", unit: "میلی‌متر (۰.۰۱)", category: "طول", type: "micrometer" },
    { name: "ترازو", purpose: "اندازه‌گیری جرم", unit: "گرم یا کیلوگرم", category: "جرم", type: "scale" },
    { name: "نیروسنج", purpose: "اندازه‌گیری وزن", unit: "نیوتن", category: "وزن", type: "spring" },
    { name: "استوانه مدرج", purpose: "اندازه‌گیری حجم مایع", unit: "میلی‌لیتر", category: "حجم", type: "cylinder" },
    { name: "پی‌پت", purpose: "برداشتن حجم دقیق", unit: "میلی‌لیتر", category: "حجم", type: "pipette" },
    { name: "دماسنج", purpose: "اندازه‌گیری دما", unit: "درجه سلسیوس", category: "دما", type: "thermo" }
  ];

  const measureTools = [
    { name: "خط‌کش", min: 1, max: 15, step: .1, tol: .5, unit: "cm", type: "ruler" },
    { name: "کولیس", min: 5, max: 25, step: .1, tol: .5, unit: "mm", type: "caliper" },
    { name: "ریزسنج", min: .1, max: 2.5, step: .01, tol: .05, unit: "mm", type: "micrometer" },
    { name: "ترازو", min: 10, max: 500, step: .1, tol: 2, unit: "g", type: "scale" },
    { name: "نیروسنج", min: .5, max: 20, step: .1, tol: .2, unit: "N", type: "spring" },
    { name: "استوانه مدرج", min: 10, max: 100, step: 1, tol: 3, unit: "ml", type: "cylinder" },
    { name: "پی‌پت", min: 1, max: 10, step: .1, tol: .3, unit: "ml", type: "pipette" },
    { name: "دماسنج", min: -10, max: 60, step: 1, tol: 1, unit: "°C", type: "thermo" },
    { name: "متر نواری", min: 50, max: 500, step: 1, tol: 2, unit: "cm", type: "tape" },
    { name: "کرنومتر", min: 1, max: 30, step: .1, tol: .2, unit: "s", type: "stopwatch" }
  ];

  const materials = [
    { name: "چوب", d: .6, color: "#A06E3C" },
    { name: "یخ", d: .9, color: "#BEE1F0" },
    { name: "پلاستیک", d: .95, color: "#6EB4DC" },
    { name: "آلومینیوم", d: 2.7, color: "#B4B4BE" },
    { name: "آهن", d: 7.8, color: "#50505A" },
    { name: "طلا", d: 19.3, color: "#DCB432" }
  ];

  const planets = [
    { name: "زمین", g: 9.8 },
    { name: "ماه", g: 1.6 },
    { name: "مریخ", g: 3.7 },
    { name: "مشتری", g: 24.8 }
  ];

  const quizQuestions = [
    ["کدام یک از موارد زیر «کمیت» است؟", ["خط‌کش", "طول", "اندازه‌گیری", "متر"], 1],
    ["یکای جرم در SI چیست؟", ["نیوتن", "کیلوگرم", "متر", "لیتر"], 1],
    ["وزن یک جسم روی ماه نسبت به زمین چگونه است؟", ["بیشتر", "کمتر", "یکسان", "صفر"], 1],
    ["یکای وزن در SI چیست؟", ["کیلوگرم", "نیوتن", "گرم", "ژول"], 1],
    ["حجم مایع با کدام ابزار اندازه‌گیری می‌شود؟", ["ترازو", "خط‌کش", "استوانه مدرج", "دماسنج"], 2],
    ["چگالی آب چند گرم بر سانتی‌متر مکعب است؟", ["0.5", "1.0", "7.8", "19.3"], 1],
    ["جسمی با چگالی ۰.۸ در آب چه می‌کند؟", ["غرق می‌شود", "شناور می‌ماند", "محو می‌شود", "منفجر می‌شود"], 1],
    ["دقت خط‌کش معمولی چقدر است؟", ["۱ سانتی‌متر", "۱ میلی‌متر", "۰.۰۱ میلی‌متر", "۱ متر"], 1],
    ["کدام یک از ابزارهای دقیق اندازه‌گیری طول است؟", ["خط‌کش", "متر نواری", "ریزسنج", "پارچه‌ای"], 2],
    ["هنگام خواندن استوانه مدرج به چه چیزی باید دقت کرد؟", ["رنگ مایع", "هلال سطح مایع", "دمای اتاق", "ارتفاع استوانه"], 1],
    ["جرم ۵۰۰ گرم روی زمین، وزنش تقریباً چند نیوتن است؟", ["۰.۵", "۵", "۵۰", "۵۰۰"], 1],
    ["کدام مورد خطای اندازه‌گیری نیست؟", ["خطای ابزار", "خطای خواندن", "خطای انسانی", "خطای محاسبه ذهنی"], 3],
    ["دماسنج برای اندازه‌گیری چه کمیتی است؟", ["جرم", "طول", "دما", "حجم"], 2],
    ["چگالی آهن تقریباً چند برابر آب است؟", ["همان اندازه", "دو برابر", "حدود ۸ برابر", "حدود ۲۰ برابر"], 2],
    ["کدام کمیت با نیروسنج اندازه‌گیری می‌شود؟", ["جرم", "وزن", "حجم", "طول"], 1],
    ["واحد میلی‌لیتر برای اندازه‌گیری چه چیزی است؟", ["جرم", "طول", "حجم", "زمان"], 2]
  ];

  const homeItems = [
    ["tools", "ابزارها و کاربردها", "ruler"],
    ["measure", "اندازه‌گیری دقیق", "measure"],
    ["mass", "جرم و وزن", "scale"],
    ["density", "حجم و چگالی", "drop"],
    ["error", "خطا و دقت", "target"],
    ["clock", "ساعت", "clock"],
    ["quiz", "آزمون جامع", "quiz"]
  ];

  const faDigits = value => String(value).replace(/\d/g, d => "۰۱۲۳۴۵۶۷۸۹"[d]);
  const fmt = (n, digits = 2) => faDigits(Number(n).toFixed(digits).replace(/\.?0+$/, ""));
  const shuffle = arr => arr.map(v => [Math.random(), v]).sort((a, b) => a[0] - b[0]).map(x => x[1]);

  function icon(name) {
    const common = 'viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#2563EB" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"';
    const paths = {
      ruler: '<path d="M3 7h18v10H3z"/><path d="M7 7v4m4-4v2m4-2v4m4-4v2"/>',
      measure: '<path d="M4 7h16M4 12h16M4 17h16"/><path d="M7 5v4m5-4v4m5-4v4"/>',
      scale: '<path d="M5 20h14l-1-12H6z"/><path d="M12 8l3 4"/><path d="M9 5h6"/>',
      drop: '<path d="M12 3s7 8 7 12a7 7 0 0 1-14 0c0-4 7-12 7-12z"/>',
      target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 2v4m10 6h-4"/>',
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l4 2"/>',
      quiz: '<path d="M5 4h14v17H5z"/><path d="M8 8h8M8 12h8M8 16h5"/>'
    };
    return `<svg ${common}>${paths[name] || paths.quiz}</svg>`;
  }

  function svgTool(type, label = "") {
    const drawings = {
      ruler: '<rect x="18" y="24" width="264" height="42" rx="4"/><path d="M35 24v20m18-20v12m18-12v20m18-20v12m18-12v20m18-20v12m18-12v20m18-20v12m18-12v20m18-20v12m18-12v20"/>',
      caliper: '<path d="M25 45h260M55 20v55M55 20h70M125 20v18M245 20v38M245 20h40M125 45v20M245 45v20"/>',
      micrometer: '<path d="M60 22a50 50 0 1 0 0 52h125V22zM185 22v52m0-26h75m0-18v36"/>',
      scale: '<rect x="65" y="35" width="150" height="85" rx="10"/><path d="M95 35a45 45 0 0 1 90 0"/><path d="M140 20l20 15M105 90h70"/>',
      spring: '<path d="M145 10v15l-15 10 30 12-30 12 30 12-30 12 30 12-15 10v15"/><path d="M145 10h30M145 120h30"/>',
      cylinder: '<path d="M100 15v105q0 12 40 12t40-12V15M100 15q40 15 80 0M100 35h20m-20 20h20m-20 20h20m-20 20h20"/>',
      pipette: '<path d="M125 15h30v20l-10 12v50l-5 20-5-20V47l-10-12z"/><path d="M120 15h40M130 47h20"/>',
      thermo: '<path d="M130 20a12 12 0 0 1 24 0v65a25 25 0 1 1-24 0z"/><path d="M142 40v60m12-50h10m-10 20h8"/>',
      tape: '<rect x="70" y="30" width="140" height="90" rx="22"/><circle cx="140" cy="75" r="22"/><path d="M210 75h75m-55 0v-12m15 12v-8m15 8v-12"/>',
      stopwatch: '<circle cx="145" cy="75" r="48"/><path d="M145 27V12m-18 0h36M145 75l25-20"/>'
    };
    return `<svg class="tool-svg" viewBox="0 0 300 150" role="img" aria-label="${label}" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">${drawings[type] || drawings.ruler}</svg>`;
  }

  function showError(root, error) {
    const box = root.querySelector("#chapter-error");
    if (box) {
      box.hidden = false;
      box.textContent = "بخشی از فعالیت با خطا روبه‌رو شد. لطفاً دوباره تلاش کنید.";
    }
    console.error(error);
  }

  function confetti(root) {
    const box = document.createElement("div");
    box.className = "confetti";
    for (let i = 0; i < 42; i++) {
      const p = document.createElement("i");
      p.style.left = Math.random() * 100 + "%";
      p.style.setProperty("--delay", Math.random() * 1.5 + "s");
      p.style.setProperty("--hue", Math.floor(Math.random() * 360));
      box.appendChild(p);
    }
    root.appendChild(box);
    setTimeout(() => box.remove(), 3500);
  }

  function initTools(el) {
    el.innerHTML = `
      <p class="intro">برای دیدن کاربرد و یکای هر ابزار، روی نام آن کلیک کنید.</p>
      <div class="tool-layout">
        <div class="tool-list">${tools.map((t, i) => `<button class="tool-choice" data-tool="${i}">${t.name}</button>`).join("")}</div>
        <div class="panel" id="tool-detail"><p>یک ابزار را انتخاب کنید.</p></div>
      </div>
      <button class="primary" id="start-tool-game">شروع بازی تطبیق</button>
      <div id="tool-game" class="panel" hidden></div>`;
    const detail = el.querySelector("#tool-detail");
    el.querySelectorAll("[data-tool]").forEach(btn => btn.addEventListener("click", () => {
      const t = tools[+btn.dataset.tool];
      detail.innerHTML = `${svgTool(t.type, t.name)}<h3>${t.name}</h3><p>${t.purpose}</p><p>یکا: <b>${t.unit}</b></p><p>کمیت: ${t.category}</p>`;
      el.querySelectorAll(".tool-choice").forEach(b => b.classList.toggle("selected", b === btn));
    }));

    const game = el.querySelector("#tool-game");
    let order = [], index = 0, score = 0, locked = false;
    function round() {
      if (index >= order.length) {
        game.innerHTML = `<h3>بازی تمام شد</h3><p>امتیاز شما: ${faDigits(score)} از ۸</p><button class="primary" id="again-tools">شروع دوباره</button>`;
        game.querySelector("#again-tools").onclick = start;
        if (score >= 6) confetti(el);
        return;
      }
      const t = order[index];
      const opts = shuffle(["طول", "جرم", "وزن", "حجم", "دما"]);
      game.innerHTML = `<p class="progress-label">مرحله ${faDigits(index + 1)} از ۸</p>${svgTool(t.type, t.name)}<h3>این ابزار برای اندازه‌گیری چه کمیتی است؟</h3><div class="option-grid">${opts.map(x => `<button class="option">${x}</button>`).join("")}</div><div class="feedback" aria-live="polite"></div>`;
      locked = false;
      game.querySelectorAll(".option").forEach(b => b.onclick = () => {
        if (locked) return;
        locked = true;
        const ok = b.textContent === t.category;
        b.classList.add(ok ? "correct" : "wrong");
        if (!ok) game.querySelectorAll(".option").forEach(x => { if (x.textContent === t.category) x.classList.add("correct"); });
        if (ok) score++;
        game.querySelector(".feedback").innerHTML = `${ok ? "آفرین!" : "پاسخ درست: " + t.category}<button class="primary next-round">بعدی</button>`;
        game.querySelector(".next-round").onclick = () => { index++; round(); };
      });
    }
    function start() { order = shuffle(tools); index = 0; score = 0; game.hidden = false; round(); }
    el.querySelector("#start-tool-game").onclick = start;
  }

  function initMeasure(el) {
    el.innerHTML = `<p class="intro">عدد نمایش‌داده‌شده روی ابزار را بخوانید و وارد کنید. پاسخ شما با دامنه خطای مشخص بررسی می‌شود.</p><div id="measure-stage" class="panel"></div>`;
    const stage = el.querySelector("#measure-stage");
    const order = shuffle(measureTools);
    let index = 0, score = 0, answered = false, current = 0;
    function render() {
      if (index === order.length) {
        stage.innerHTML = `<h3>پایان تمرین</h3><p class="score">${faDigits(score)} از ۱۰</p><p>${faDigits(Math.round(score * 10))} درصد</p><button class="primary" id="measure-again">تکرار تمرین</button>`;
        if (score >= 8) confetti(el);
        stage.querySelector("#measure-again").onclick = () => { index = 0; score = 0; render(); };
        return;
      }
      const t = order[index];
      const decimals = t.step < 1 ? 1 : 0;
      current = Math.round((t.min + Math.random() * (t.max - t.min)) / t.step) * t.step;
      stage.innerHTML = `<div class="progress"><span style="width:${index * 10}%"></span></div><p>ابزار ${faDigits(index + 1)} از ۱۰</p><h3>${t.name}</h3>${svgTool(t.type, t.name)}<p class="reading-value">${fmt(current, decimals)} ${t.unit}</p><label>عدد خوانده‌شده را وارد کنید</label><div class="answer-row"><input id="measure-input" type="number" step="${t.step}" inputmode="decimal" placeholder="عدد را وارد کنید"><span>${t.unit}</span></div><button class="primary" id="measure-check">بررسی پاسخ</button><div class="feedback" id="measure-feedback"></div>`;
      answered = false;
      stage.querySelector("#measure-check").onclick = () => {
        if (answered) return;
        const input = stage.querySelector("#measure-input");
        if (input.value.trim() === "") { input.focus(); return; }
        answered = true;
        const val = Number(input.value);
        const ok = Number.isFinite(val) && Math.abs(val - current) <= t.tol;
        if (ok) score++;
        input.disabled = true;
        stage.querySelector("#measure-check").disabled = true;
        stage.querySelector("#measure-feedback").innerHTML = `${ok ? "آفرین!" : "جواب درست: " + fmt(current, decimals) + " " + t.unit}<button class="primary" id="measure-next">بعدی</button>`;
        stage.querySelector("#measure-next").onclick = () => { index++; render(); };
      };
    }
    render();
  }

  function initMass(el) {
    el.innerHTML = `
      <p class="intro">جرم را انتخاب کنید یا مقدار دلخواه را بر حسب کیلوگرم وارد کنید. سپس جسم را روی ترازو رها کنید.</p>
      <div class="mass-options">${[.1, .5, 1, 5].map((m, i) => `<button class="mass-preset" data-mass="${m}">${["۱۰۰ گرم", "۵۰۰ گرم", "۱ کیلوگرم", "۵ کیلوگرم"][i]}</button>`).join("")}</div>
      <div class="answer-row"><label for="custom-mass">جرم دلخواه (کیلوگرم)</label><input id="custom-mass" type="number" min=".01" max="100" step=".01" placeholder="مثلاً ۲"></div>
      <div class="drop-stage panel"><div class="object-drag" draggable="true" id="mass-object">جسم را بکشید</div><div class="scale-drop" id="mass-scale">جسم را اینجا رها کنید</div></div>
      <div id="mass-result" class="panel" hidden></div>`;
    let mass = 1, selected = false;
    const object = el.querySelector("#mass-object"), scale = el.querySelector("#mass-scale");
    function choose(v) {
      if (!(v > 0 && v <= 100)) return;
      mass = v; selected = true;
      object.textContent = `${fmt(v)} kg`;
      object.classList.add("ready");
      el.querySelectorAll(".mass-preset").forEach(b => b.classList.toggle("selected", +b.dataset.mass === v));
    }
    el.querySelectorAll("[data-mass]").forEach(b => b.onclick = () => { el.querySelector("#custom-mass").value = ""; choose(+b.dataset.mass); });
    el.querySelector("#custom-mass").onchange = e => choose(+e.target.value);
    object.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", "mass"); });
    scale.addEventListener("dragover", e => e.preventDefault());
    scale.addEventListener("drop", e => { e.preventDefault(); showResult(); });
    object.addEventListener("click", () => { if (selected) showResult(); });
    scale.addEventListener("click", () => { if (selected) showResult(); });
    function showResult() {
      if (!selected) { el.querySelector("#custom-mass").focus(); return; }
      const result = el.querySelector("#mass-result");
      result.hidden = false;
      result.innerHTML = `<h3>وزن جسم در سیاره‌های مختلف</h3><p>رابطه وزن: <b>W = m × g</b></p><p>جرم انتخابی: ${fmt(mass)} کیلوگرم</p><div class="chart-bars">${planets.map(p => `<div class="bar-item"><span>${p.name}</span><div class="bar-track"><i style="height:${Math.max(4, mass * p.g / (mass * 24.8) * 100)}%"></i></div><b>${fmt(mass * p.g)} N</b><small>g = ${p.g}</small></div>`).join("")}</div>`;
      if (mass >= 1) confetti(el);
    }
  }

  function initDensity(el) {
    el.innerHTML = `<p class="intro">یک ماده انتخاب کنید، آن را روی ترازو بگذارید و سپس در آب قرار دهید.</p><div class="material-grid">${materials.map((m, i) => `<button class="material-choice" data-material="${i}"><i style="background:${m.color}"></i>${m.name}<small>چگالی: ${m.d}</small></button>`).join("")}</div><div class="drop-stage panel"><div class="object-drag" id="density-object" draggable="true">ماده را انتخاب کنید</div><div class="scale-drop" id="density-scale">ترازو</div><div class="scale-drop" id="density-water">ظرف آب</div></div><div id="density-result" class="panel" hidden></div>`;
    let chosen = null, weighed = false;
    const obj = el.querySelector("#density-object"), scale = el.querySelector("#density-scale"), water = el.querySelector("#density-water");
    el.querySelectorAll("[data-material]").forEach(b => b.onclick = () => {
      chosen = materials[+b.dataset.material]; weighed = false;
      obj.textContent = chosen.name; obj.style.background = chosen.color;
      el.querySelectorAll(".material-choice").forEach(x => x.classList.toggle("selected", x === b));
      el.querySelector("#density-result").hidden = true;
    });
    obj.addEventListener("dragstart", e => e.dataTransfer.setData("text/plain", "material"));
    [scale, water].forEach(zone => zone.addEventListener("dragover", e => e.preventDefault()));
    scale.addEventListener("drop", e => { e.preventDefault(); weigh(); });
    scale.addEventListener("click", weigh);
    water.addEventListener("drop", e => { e.preventDefault(); floatTest(); });
    water.addEventListener("click", floatTest);
    obj.addEventListener("click", () => { if (chosen && !weighed) weigh(); else floatTest(); });
    function weigh() {
      if (!chosen) return;
      weighed = true;
      el.querySelector("#density-result").hidden = false;
      el.querySelector("#density-result").innerHTML = `<p>جرم ماده با حجم ۸ سانتی‌متر مکعب:</p><h3>m = d × V = ${chosen.d} × ۸ = ${fmt(chosen.d * 8)} گرم</h3><p>اکنون ماده را در ظرف آب قرار دهید.</p>`;
    }
    function floatTest() {
      if (!chosen || !weighed) return;
      const floats = chosen.d < 1;
      const result = el.querySelector("#density-result");
      result.innerHTML += `<div class="water-visual"><div class="water-fill"></div><div class="water-object ${floats ? "floating" : "sinking"}" style="background:${chosen.color}"></div></div><h3>${floats ? "ماده روی آب شناور می‌ماند." : "ماده در آب فرو می‌رود."}</h3><p>چگالی ماده: ${chosen.d} g/cm³</p><div class="density-bars">${materials.map(m => `<div><span>${m.name}</span><i><b style="width:${m.d / 19.3 * 100}%"></b></i><small>${m.d}</small></div>`).join("")}</div>`;
      if (floats) confetti(el);
    }
  }

  function initError(el) {
    const scenarios = [
      { q: "روی خط‌کشی که دقیق‌ترین گزارش را می‌دهد کلیک کنید", options: ["۵ سانتی‌متر", "۵.۳ سانتی‌متر", "۵.۳۰ سانتی‌متر"], correct: 2, drawings: ["ruler-coarse", "ruler-medium", "ruler-fine"], explain: "خط‌کش با تقسیم‌بندی ریزتر، اندازه‌گیری دقیق‌تری فراهم می‌کند." },
      { q: "کدام دماسنج دقیق‌تر است؟", options: ["دماسنج با درجه‌بندی ۱۰ درجه‌ای", "دماسنج با درجه‌بندی ۱ درجه‌ای"], correct: 1, drawings: ["thermo-coarse", "thermo-fine"], explain: "هرچه فاصله درجه‌بندی‌ها کوچک‌تر باشد، دقت خواندن بیشتر است." },
      { q: "کدام ترازو دقیق‌تر است؟", options: ["ترازوی عقربه‌ای", "ترازوی دیجیتال با نمایش ۲۵.۳۴ گرم"], correct: 1, drawings: ["scale-analog", "scale-digital"], explain: "نمایش رقم‌های اعشاری بیشتر امکان گزارش دقیق‌تر را فراهم می‌کند." }
    ];
    let index = 0, score = 0, locked = false;
    function render() {
      if (index === scenarios.length) {
        el.innerHTML = `<div class="panel result-panel"><h3>پایان فعالیت</h3><p class="score">${faDigits(score)} از ۳</p><button class="primary" id="error-again">تکرار فعالیت</button></div>`;
        if (score === 3) confetti(el);
        el.querySelector("#error-again").onclick = () => { index = 0; score = 0; render(); };
        return;
      }
      const s = scenarios[index];
      el.innerHTML = `<div class="progress"><span style="width:${index / 3 * 100}%"></span></div><p>موقعیت ${faDigits(index + 1)} از ۳</p><h3>${s.q}</h3><div class="error-options">${s.options.map((o, i) => `<button class="error-option" data-index="${i}"><div class="mini-instrument ${s.drawings[i]}">${instrumentSketch(s.drawings[i])}</div><span>${o}</span></button>`).join("")}</div><div class="feedback" id="error-feedback"></div>`;
      locked = false;
      el.querySelectorAll("[data-index]").forEach(b => b.onclick = () => {
        if (locked) return;
        locked = true;
        const ok = +b.dataset.index === s.correct;
        if (ok) score++;
        b.classList.add(ok ? "correct" : "wrong");
        el.querySelectorAll("[data-index]").forEach(x => { if (+x.dataset.index === s.correct) x.classList.add("correct"); });
        el.querySelector("#error-feedback").innerHTML = `${ok ? "آفرین!" : "پاسخ درست: " + s.options[s.correct]}<p>${s.explain}</p><button class="primary" id="error-next">بعدی</button>`;
        el.querySelector("#error-next").onclick = () => { index++; render(); };
      });
    }
    function instrumentSketch(kind) {
      if (kind.startsWith("ruler")) {
        const n = kind.endsWith("coarse") ? 5 : kind.endsWith("medium") ? 10 : 30;
        return `<svg viewBox="0 0 220 58"><rect x="5" y="8" width="210" height="40" rx="3" fill="#eff6ff" stroke="#2563eb"/>${Array.from({ length: n + 1 }, (_, i) => `<path d="M${10 + i * 200 / n} 8v${i % 5 === 0 ? 24 : 13}" stroke="#2563eb" stroke-width="1.5"/>`).join("")}</svg>`;
      }
      if (kind.startsWith("thermo")) {
        const n = kind.endsWith("coarse") ? 4 : 20;
        return `<svg viewBox="0 0 100 130"><rect x="42" y="8" width="16" height="92" rx="8" fill="#fff" stroke="#2563eb" stroke-width="2"/><circle cx="50" cy="102" r="16" fill="#ef4444"/>${Array.from({ length: n }, (_, i) => `<path d="M59 ${20 + i * 70 / n}h${i % 2 ? 7 : 12}" stroke="#2563eb"/>`).join("")}</svg>`;
      }
      return kind === "scale-digital"
        ? '<div class="digital-reading">25.34 g</div>'
        : '<svg viewBox="0 0 180 100"><path d="M20 75h140M35 75l10-35h90l10 35" fill="#e2e8f0" stroke="#2563eb" stroke-width="3"/><path d="M90 25v28l25-12" stroke="#2563eb" stroke-width="3" fill="none"/><circle cx="90" cy="25" r="5" fill="#2563eb"/></svg>';
    }
    render();
  }

  function initClock(el) {
    el.innerHTML = `<div class="tabs"><button class="tab active" data-tab="read">خواندن ساعت</button><button class="tab" data-tab="chrono">کرنومتر</button></div><div id="clock-read"></div><div id="clock-chrono" hidden></div>`;
    const read = el.querySelector("#clock-read"), chrono = el.querySelector("#clock-chrono");
    el.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => {
      el.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t === b));
      read.hidden = b.dataset.tab !== "read"; chrono.hidden = b.dataset.tab !== "chrono";
    });
    const times = shuffle(Array.from({ length: 10 }, () => {
      const h = 1 + Math.floor(Math.random() * 12);
      const m = [0, 15, 30, 45][Math.floor(Math.random() * 4)];
      return { h, m };
    }));
    let index = 0, score = 0, locked = false;
    function clockSvg(h, m) {
      const minuteAngle = m * 6 - 90, hourAngle = (h % 12) * 30 + m * .5 - 90;
      const pt = (angle, length) => [100 + Math.cos(angle * Math.PI / 180) * length, 100 + Math.sin(angle * Math.PI / 180) * length];
      const a = pt(minuteAngle, 68), b = pt(hourAngle, 43);
      return `<svg class="clock-face" viewBox="0 0 200 200"><circle cx="100" cy="100" r="91" fill="#fff" stroke="#2563eb" stroke-width="3"/>${Array.from({ length: 12 }, (_, i) => { const p = pt(i * 30 - 90, 76); return `<text x="${p[0]}" y="${p[1] + 5}" text-anchor="middle" font-size="13" fill="#1e293b">${i || 12}</text>`; }).join("")}<path d="M100 100L${a.join(" ")}" stroke="#2563eb" stroke-width="4" stroke-linecap="round"/><path d="M100 100L${b.join(" ")}" stroke="#0f172a" stroke-width="7" stroke-linecap="round"/><circle cx="100" cy="100" r="5" fill="#2563eb"/></svg>`;
    }
    function renderRead() {
      if (index >= 10) {
        read.innerHTML = `<div class="panel"><h3>نتیجه خواندن ساعت</h3><p class="score">${faDigits(score)} از ۱۰</p><button class="primary" id="clock-again">شروع دوباره</button></div>`;
        if (score >= 8) confetti(el);
        read.querySelector("#clock-again").onclick = () => { index = 0; score = 0; renderRead(); };
        return;
      }
      const t = times[index];
      const correct = `${faDigits(t.h)}:${faDigits(String(t.m).padStart(2, "0"))}`;
      const opts = shuffle([correct, ...Array.from(new Set([0, 1, 2].map(k => `${faDigits((t.h + k + 1) % 12 || 12)}:${faDigits(String((t.m + 15 * (k + 1)) % 60).padStart(2, "0"))}`)))]);
      read.innerHTML = `<p>پرسش ${faDigits(index + 1)} از ۱۰</p><div class="progress"><span style="width:${index * 10}%"></span></div>${clockSvg(t.h, t.m)}<h3>ساعت چند است؟</h3><div class="option-grid">${opts.map(o => `<button class="option">${o}</button>`).join("")}</div><div class="feedback"></div>`;
      locked = false;
      read.querySelectorAll(".option").forEach(b => b.onclick = () => {
        if (locked) return;
        locked = true;
        const ok = b.textContent === correct;
        if (ok) score++;
        b.classList.add(ok ? "correct" : "wrong");
        if (!ok) read.querySelectorAll(".option").forEach(x => { if (x.textContent === correct) x.classList.add("correct"); });
        read.querySelector(".feedback").innerHTML = `${ok ? "آفرین!" : "پاسخ درست: " + correct}<button class="primary" id="clock-next">بعدی</button>`;
        read.querySelector("#clock-next").onclick = () => { index++; renderRead(); };
      });
    }
    renderRead();

    chrono.innerHTML = `<div class="panel stopwatch"><div id="chrono-display">۰۰:۰۰.۰۰</div><div class="button-row"><button class="primary" id="chrono-toggle">شروع</button><button class="secondary" id="chrono-reset">بازنشانی</button></div></div>`;
    let elapsed = 0, started = 0, running = false, raf = 0;
    const display = chrono.querySelector("#chrono-display"), toggle = chrono.querySelector("#chrono-toggle");
    function paint() {
      const ms = elapsed + (running ? performance.now() - started : 0);
      const cs = Math.floor(ms / 10) % 100, sec = Math.floor(ms / 1000) % 60, min = Math.floor(ms / 60000);
      display.textContent = `${faDigits(String(min).padStart(2, "0"))}:${faDigits(String(sec).padStart(2, "0"))}.${faDigits(String(cs).padStart(2, "0"))}`;
      if (running) raf = requestAnimationFrame(paint);
    }
    toggle.onclick = () => {
      if (running) { elapsed += performance.now() - started; running = false; cancelAnimationFrame(raf); toggle.textContent = "ادامه"; paint(); }
      else { started = performance.now(); running = true; toggle.textContent = "توقف"; paint(); }
    };
    chrono.querySelector("#chrono-reset").onclick = () => { running = false; elapsed = 0; cancelAnimationFrame(raf); toggle.textContent = "شروع"; paint(); };
  }

  function initQuiz(el) {
    let index = 0, score = 0, locked = false, order = shuffle(quizQuestions);
    function render() {
      if (index >= order.length) {
        const pct = Math.round(score / order.length * 100);
        el.innerHTML = `<div class="panel result-panel"><h3>آزمون به پایان رسید</h3><div class="score">${faDigits(score)} از ۱۶</div><p>درصد پاسخ‌های درست: ${faDigits(pct)}٪</p><button class="primary" id="quiz-restart">شروع دوباره</button></div>`;
        if (pct >= 80) confetti(el);
        el.querySelector("#quiz-restart").onclick = () => { order = shuffle(quizQuestions); index = 0; score = 0; render(); };
        return;
      }
      const q = order[index];
      el.innerHTML = `<div class="progress"><span style="width:${index / order.length * 100}%"></span></div><p class="progress-label">پرسش ${faDigits(index + 1)} از ۱۶</p><div class="panel"><h3>${q[0]}</h3><div class="quiz-options">${q[1].map((o, i) => `<button class="option" data-answer="${i}">${o}</button>`).join("")}</div><div class="feedback" id="quiz-feedback"></div></div>`;
      locked = false;
      el.querySelectorAll("[data-answer]").forEach(b => b.onclick = () => {
        if (locked) return;
        locked = true;
        const ok = +b.dataset.answer === q[2];
        if (ok) score++;
        b.classList.add(ok ? "correct" : "wrong");
        el.querySelectorAll("[data-answer]").forEach(x => { x.disabled = true; if (+x.dataset.answer === q[2]) x.classList.add("correct"); });
        el.querySelector("#quiz-feedback").innerHTML = `${ok ? "آفرین! پاسخ درست است." : "پاسخ درست: " + q[1][q[2]]}<button class="primary" id="quiz-next">${index === order.length - 1 ? "مشاهده نتیجه" : "سؤال بعدی"}</button>`;
        el.querySelector("#quiz-next").onclick = () => { index++; render(); };
      });
    }
    render();
  }

  window.chapterInit = function (root) {
    if (!root) throw new Error("Chapter root is required");
    const cleanups = [];
    try {
      root.querySelectorAll(".chapter-section").forEach(s => { s.hidden = s.id !== "home"; s.classList.toggle("active", s.id === "home"); });
      const grid = root.querySelector("#home-grid");
      grid.innerHTML = homeItems.map(([id, label, iconName]) => `<button class="home-card" type="button" data-open="${id}">${icon(iconName)}<span>${label}</span></button>`).join("");
      function open(id) {
        root.querySelectorAll(".chapter-section").forEach(s => {
          s.hidden = s.id !== id;
          s.classList.toggle("active", s.id === id);
        });
        const external = window.__openSection;
        if (typeof external === "function") {
          try { external(id); } catch (e) { console.warn("Host section callback:", e); }
        }
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
      grid.querySelectorAll("[data-open]").forEach(b => b.addEventListener("click", () => open(b.dataset.open)));
      root.querySelectorAll("[data-home]").forEach(b => b.addEventListener("click", () => open("home")));

      initTools(root.querySelector("#tools-content"));
      initMeasure(root.querySelector("#measure-content"));
      initMass(root.querySelector("#mass-content"));
      initDensity(root.querySelector("#density-content"));
      initError(root.querySelector("#error-content"));
      initClock(root.querySelector("#clock-content"));
      initQuiz(root.querySelector("#quiz-content"));

      return function chapterDestroy() {
        cleanups.forEach(fn => { try { fn(); } catch (_) {} });
        root.querySelectorAll("*").forEach(node => {
          const clone = node.cloneNode(true);
          if (node.parentNode) node.parentNode.replaceChild(clone, node);
        });
      };
    } catch (error) {
      showError(root, error);
      throw error;
    }
  };
})();