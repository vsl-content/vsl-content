(function () {
'use strict';
var D = {"expNames": ["روغن مایع", "گوگرد", "نشاسته", "جوهر نمک", "براده آهن", "اتانول", "نمک خوراکی"], "expSol": [false, false, false, true, false, true, true], "expCol": [[230, 190, 40, 255], [240, 225, 60, 255], [245, 242, 225, 255], [190, 225, 150, 255], [70, 70, 80, 255], [200, 225, 245, 255], [250, 250, 250, 255]], "expRes": ["حل نمی‌شود؛ لایه‌ای طلایی روی آب شناور می‌ماند", "حل نمی‌شود؛ پودر زرد روی سطح آب شناور می‌ماند", "حل نمی‌شود؛ به‌آهستگی ته‌نشین می‌شود", "حل می‌شود؛ آب کمی سبز می‌شود", "حل نمی‌شود؛ سریع ته‌نشین می‌شود", "حل می‌شود؛ بی‌رنگ و نامرئی است", "حل می‌شود؛ پس از تکان دادن آب شفاف می‌شود"], "sciQs": [["علی دو گیاه مشابه را در دو جای مختلف گذاشت؛ یکی در تاریکی و دیگری در نور.", "او در کدام مرحله از روش علمی است؟", ["طرح پرسش", "انجام آزمایش", "نتیجه‌گیری", "گزارش‌نویسی"], 1, "او شرایط را تغییر داده و نتیجه را می‌سنجد؛ این مرحله انجام آزمایش است."], ["سارا می‌خواهد اثر دما بر حل شدن شکر در آب را بررسی کند.", "چرا باید فقط یک متغیر را تغییر دهد؟", ["تا آزمایش زودتر تمام شود", "تا علت تغییر مشخص شود", "تا ابزار کمتری لازم باشد", "تا فرضیه حتماً تأیید شود"], 1, "اگر چند متغیر با هم عوض شوند، نمی‌توان فهمید کدام عامل نتیجه را تغییر داده است."], ["نتیجه آزمایش رضا با فرضیه‌اش مطابقت نداشت.", "او چه کاری باید انجام دهد؟", ["نتیجه را تغییر دهد", "فرضیه را اصلاح یا آزمایش را بازبینی کند", "آزمایش را فراموش کند", "فرضیه را بدون بررسی درست بداند"], 1, "دانشمند نتیجه را تغییر نمی‌دهد؛ فرضیه را اصلاح می‌کند یا آزمایش را بازبینی می‌کند."], ["معلم از دانش‌آموزان خواست درباره یک سیب مشاهده‌هایی بنویسند.", "کدام مورد با حواس پنج‌گانه قابل مشاهده نیست؟", ["رنگ سیب", "بوی سیب", "سفتی سیب", "تعداد سلول‌های سیب"], 3, "سلول‌ها بسیار ریزند و فقط با میکروسکوپ دیده می‌شوند."], ["چند دانش‌آموز درباره دلیل رشد سریع‌تر گیاه حدس می‌زنند.", "کدام جمله یک فرضیه است؟", ["اگر گیاه نور بیشتری بگیرد، سریع‌تر رشد می‌کند", "گیاه ۱۰ سانتی‌متر قد دارد", "آیا گیاه به نور نیاز دارد؟", "گیاه‌ها در باغچه رشد می‌کنند"], 0, "فرضیه یک پاسخ احتمالی و قابل آزمایش به پرسش است."], ["در کلاس درباره تفاوت فرضیه و نظریه بحث می‌شود.", "تفاوت اصلی کدام است؟", ["فرضیه همیشه درست است", "نظریه فقط یک حدس است", "نظریه با آزمایش‌های متعدد تأیید شده، اما فرضیه هنوز آزمون نشده", "هیچ تفاوتی ندارند"], 2, "نظریه از فرضیه‌هایی به دست می‌آید که بارها آزمایش و تأیید شده‌اند."], ["مینا آزمایشی را دو بار انجام داد و هر دو بار نتیجه یکسان گرفت.", "چه نتیجه‌ای می‌گیرد؟", ["فرضیه برای همیشه ثابت شده است", "نتیجه آزمایش قابل اعتمادتر است", "آزمایش بی‌فایده بوده است", "دیگر نباید آزمایش کرد"], 1, "تکرار آزمایش و گرفتن نتیجه یکسان اعتماد به نتیجه را بیشتر می‌کند."], ["در آزمایش «اثر نور بر رشد گیاه» مقدار نور را تغییر می‌دهیم.", "متغیر مستقل کدام است؟", ["رشد گیاه", "نوع خاک", "مقدار نور", "مقدار آب"], 2, "متغیر مستقل همان چیزی است که خودمان عمداً تغییر می‌دهیم."], ["دانشمندی می‌خواهد پژوهش خود را آغاز کند.", "کدام مرحله اول انجام می‌شود؟", ["نتیجه‌گیری", "انجام آزمایش", "گزارش‌نویسی", "مشاهده و طرح پرسش"], 3, "پژوهش علمی با مشاهده و طرح پرسش شروع می‌شود."], ["برای ارائه یافته‌ها باید یک گزارش علمی نوشت.", "کدام مورد جزو گزارش علمی نیست؟", ["روش انجام آزمایش", "نتایج و داده‌ها", "حدس‌های بدون دلیل", "فرضیه"], 2, "گزارش علمی باید بر داده‌ها و دلیل تکیه کند، نه حدس بی‌پشتوانه."]], "techs": [["اتومبیل", "سرعت در جابه‌جایی", "آلودگی هوا", [70, 170, 100, 255], [210, 70, 70, 255]], ["هواپیما", "حمل‌ونقل جهانی", "هزینه بالا", [100, 180, 220, 255], [230, 200, 60, 255]], ["تلفن همراه", "ارتباط آسان", "اعتیاد به فضای مجازی", [100, 200, 170, 255], [220, 140, 170, 255]], ["دارو", "درمان بیماری", "عوارض جانبی", [170, 140, 210, 255], [240, 140, 120, 255]], ["ماهواره", "اینترنت و ارتباطات", "زباله فضایی", [80, 80, 180, 255], [230, 170, 60, 255]], ["پنل خورشیدی", "انرژی پاک", "هزینه نصب بالا", [240, 160, 60, 255], [40, 160, 150, 255]], ["پهپاد", "کشاورزی دقیق", "نقض حریم خصوصی", [120, 130, 140, 255], [150, 50, 80, 255]]], "facName": ["کنجکاوی", "دانش و اطلاعات", "مهارت و روش"], "facDesc": ["میل به پرسیدن و کشف کردن", "آگاهی از واقعیت‌ها و منابع", "توانایی آزمایش و کار با ابزار"], "facEx": [["مشاهده ستاره‌ها با تلسکوپ", 2], ["مطالعه کتاب دانشنامه", 1], ["پرسیدن سوال از خود", 0], ["استفاده از میکروسکوپ", 2], ["حفظ اطلاعات علمی", 1], ["داشتن حس کنجکاوی", 0], ["آزمایش با وسایل آزمایشگاهی", 2], ["مراجعه به منابع علمی", 1], ["تعجب از پدیده طبیعی", 0], ["یادگیری ریاضیات برای محاسبه", 1], ["ساختن مدل با وسایل ساده", 2], ["پرسش «چرا آسمان آبی است؟»", 0]], "quiz": [["علوم تجربی بیشتر درباره چه چیزی بحث می‌کند؟", ["قصه‌های قدیمی", "پدیده‌های طبیعی قابل آزمایش", "تاریخ پادشاهان", "قوانین شهری"], 1], ["«فناوری» یعنی چه؟", ["فقط حفظ کردن فرمول‌ها", "به‌کارگیری علم برای ساخت ابزار و حل مشکل", "نوشتن کتاب علمی", "تماشای ستاره‌ها"], 1], ["کدام یک از عوامل تولید علم است؟", ["تنبلی", "کنجکاوی", "بی‌تفاوتی", "ترس"], 1], ["هنگام مشاهده از چه چیزی استفاده می‌کنیم؟", ["حواس پنج‌گانه و ابزار", "فقط حدس", "فقط حافظه", "فقط محاسبه"], 0], ["حدس علمی که قابل آزمایش باشد چه نام دارد؟", ["فرضیه", "گزارش", "قانون", "مشاهده"], 0], ["در آزمایش، متغیری که ثابت نگه داشته می‌شود چه نام دارد؟", ["متغیر مستقل", "متغیر وابسته", "متغیر کنترل‌شده", "فرضیه"], 2], ["تلسکوپ برای مشاهده چه چیزی ساخته شد؟", ["اجرام آسمانی دور", "سلول‌ها", "میکروب‌ها", "اتم‌ها"], 0], ["میکروسکوپ چه چیزی را نشان می‌دهد؟", ["ستاره‌های دور", "اجسام بسیار ریز", "ابرها", "کوه‌ها"], 1], ["کدام مورد از فواید فناوری است؟", ["آلودگی هوا", "ارتباط سریع‌تر", "زباله فضایی", "عوارض جانبی"], 1], ["کدام مورد از ضررهای احتمالی فناوری است؟", ["درمان بیماری", "انرژی پاک", "آلودگی محیط زیست", "ارتباط آسان"], 2], ["دانشمندان یافته‌های خود را چگونه به دیگران منتقل می‌کنند؟", ["با گزارش علمی", "با پنهان کردن نتایج", "با حدس زدن", "با فراموش کردن"], 0], ["کدام مورد یک «مشاهده» است؟", ["رنگ محلول سبز شد", "فکر می‌کنم باران می‌آید", "باید آزمایش کنیم", "شاید گیاه رشد کند"], 0], ["نتیجه‌گیری در کدام مرحله انجام می‌شود؟", ["پیش از آزمایش", "پس از تحلیل داده‌ها", "پیش از مشاهده", "همزمان با طرح پرسش"], 1], ["برای اینکه آزمایش قابل اعتماد باشد باید چه کرد؟", ["فقط یک بار انجام داد", "آن را چند بار تکرار کرد", "نتیجه را عوض کرد", "داده‌ها را پنهان کرد"], 1], ["کدام یک از شاخه‌های علوم تجربی است؟", ["زیست‌شناسی", "خوشنویسی", "ورزش", "نقاشی"], 0], ["علم چگونه به دست می‌آید؟", ["با پرسش، مشاهده و آزمایش", "فقط با شنیدن", "فقط با خواب دیدن", "فقط با حدس زدن"], 0], ["فرضیه‌ای که با آزمایش‌های متعدد تأیید شود چه نام دارد؟", ["مشاهده", "نظریه", "پرسش", "گزارش"], 1], ["علوم تجربی به چند شاخه اصلی تقسیم می‌شود؟", ["دو", "سه", "چهار", "شش"], 2], ["کدام ابزار علمی با پیشرفت فناوری ساخته شد؟", ["چشم", "تلسکوپ", "گوش", "مغز"], 1], ["کدام نمونه «کاربرد علم در زندگی» است؟", ["طلوع خورشید", "ساخت واکسن", "جذر و مد", "رنگین‌کمان"], 1], ["اگر آزمایش فرضیه را رد کند، دانشمند چه می‌کند؟", ["نتایج را تغییر می‌دهد", "فرضیه را اصلاح می‌کند", "علم را رها می‌کند", "آزمایش را پنهان می‌کند"], 1], ["کدام مرحله از روش علمی به مشاهده وابسته است؟", ["گزارش‌نویسی", "طرح پرسش", "نتیجه‌گیری", "ساخت دستگاه"], 1], ["مثال «تحلیل نتایج» در آزمایش چیست؟", ["حدس زدن", "انتخاب ابزار", "مقایسه داده‌ها", "نوشتن عنوان"], 2], ["کدام یک شاخه علوم تجربی نیست؟", ["ریاضی", "فیزیک", "شیمی", "زمین‌شناسی"], 0], ["چرا شرایط آزمایش را ثابت نگه می‌داریم؟", ["تا آزمایش ارزان شود", "تا فقط یک متغیر تأثیر بگذارد", "تا نتیجه زیباتر شود", "تا زمان کم شود"], 1]], "carName": ["پزشک", "مهندس", "زیست‌شناس", "شیمی‌دان", "فیزیک‌دان", "زمین‌شناس", "ستاره‌شناس", "کشاورز علمی"], "carDesc": ["درمان بیماری‌ها", "طراحی و ساخت سازه‌ها", "مطالعه موجودات زنده", "مطالعه مواد و واکنش‌ها", "مطالعه نیروها و انرژی", "مطالعه سنگ‌ها و زمین", "مطالعه ستارگان و فضا", "بهبود محصولات کشاورزی"], "appCat": ["پزشکی", "کشاورزی", "صنعت", "فضا"], "apps": [["واکسن", 0], ["ام‌آر‌آی", 0], ["آنتی‌بیوتیک", 0], ["پیوند عضو", 0], ["کود زیستی", 1], ["آبیاری قطره‌ای", 1], ["تراکتور", 1], ["گلخانه", 1], ["ربات جوشکار", 2], ["چاپ سه‌بعدی", 2], ["ماشین نساجی", 2], ["توربین بادی", 2], ["ماهواره GPS", 3], ["کاوشگر مریخ", 3], ["تلسکوپ هابل", 3], ["لباس فضانوردی", 3]]};
var FAD = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
function toFa(n) { return String(n).replace(/\d/g, function (c) { return FAD[+c]; }); }
function fmt(v, d) { return toFa(Number(v).toFixed(d)).replace('.', '٫'); }
function parseNum(s) {
  s = String(s).replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 1776); })
    .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); })
    .replace(/[٫،,]/g, '.').replace(/[−–]/g, '-');
  var v = parseFloat(s);
  return isNaN(v) ? null : v;
}
function shuffle(a) {
  for (var i = a.length - 1; i > 0; i--) {
    var j = Math.floor(Math.random() * (i + 1));
    var t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}
function faText(s) { return String(s).replace(/\b\d+(?:\.\d+)?\b/g, function (m) { return toFa(m).replace('.', '٫'); }); }
function rnd(n) { return Math.floor(Math.random() * n); }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}
function clear(n) { while (n.firstChild) n.removeChild(n.firstChild); }
function btn(text, cls, fn) {
  var b = el('button', 'btn-sm' + (cls ? ' ' + cls : ''), text);
  b.type = 'button';
  if (fn) b.addEventListener('click', fn);
  return b;
}
function css(c) { return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')'; }
function subHtml(f) { return f.replace(/(\d+)/g, function (m) { return '<sub>' + toFa(m) + '</sub>'; }); }
var dead = false, timeouts = [], docHandlers = [];
function later(fn, ms) { var t = setTimeout(fn, ms); timeouts.push(t); return t; }
function onDoc(type, fn, opts) { document.addEventListener(type, fn, opts); docHandlers.push([type, fn, opts]); }
function loop(fn) {
  var last = 0;
  function tick(t) {
    if (dead) return;
    var dt = last ? Math.min(0.05, (t - last) / 1000) : 0.016;
    last = t;
    try { fn(dt, t); } catch (e) { console.error(e); }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}
function visible(n) { return !!(n && n.offsetParent !== null); }
function showError(root, e) {
  var d = el('div', 'err-box', 'خطا: ' + (e && e.message ? e.message : e));
  root.insertBefore(d, root.firstChild);
}
function confettiBurst() {
  var colors = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
  for (var i = 0; i < 80; i++) {
    var p = document.createElement('div');
    p.className = 'confetti-piece';
    p.style.left = (30 + Math.random() * 40) + '%';
    p.style.background = colors[Math.floor(Math.random() * colors.length)];
    p.style.animationDelay = (Math.random() * 0.3) + 's';
    document.body.appendChild(p);
    setTimeout(function (node) { return function () { if (node.parentNode) node.parentNode.removeChild(node); }; }(p), 3500);
  }
}
function secOf(root, type, renderer) {
  var ss = root.querySelectorAll('section');
  for (var i = 0; i < ss.length; i++) {
    if (ss[i].getAttribute('data-type') === type && (!renderer || ss[i].getAttribute('data-renderer') === renderer)) return ss[i];
  }
  return null;
}
function buildHome(root, cards) {
  var g = root.querySelector('#home-grid');
  if (!g) throw new Error('home-grid not found');
  clear(g);
  cards.forEach(function (c) {
    var b = el('button', 'home-card');
    b.type = 'button';
    b.appendChild(el('span', 'icon', c.icon));
    b.appendChild(document.createTextNode(c.label));
    b.addEventListener('click', function () {
      var t = secOf(root, c.type, c.renderer);
      if (t) window.__openSection(t);
    });
    g.appendChild(b);
  });
}
function hit(node, x, y) {
  var r = node.getBoundingClientRect();
  return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
}
function ptOf(e) {
  var t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
  return { x: t.clientX, y: t.clientY };
}
// drag with transform (mouse + touch). hooks.end(x, y) returns true when the node was placed somewhere else
function makeDrag(node, h) {
  var sx = 0, sy = 0, active = false;
  function down(e) {
    if (h.canStart && !h.canStart()) return;
    var p = ptOf(e);
    active = true; sx = p.x; sy = p.y;
    node.style.transition = 'none'; node.style.zIndex = '50';
    node.classList.add('dragging');
    if (h.start) h.start(p.x, p.y);
    if (e.cancelable) e.preventDefault();
  }
  function move(e) {
    if (!active) return;
    var p = ptOf(e);
    node.style.transform = 'translate(' + (p.x - sx) + 'px,' + (p.y - sy) + 'px)';
    if (h.move) h.move(p.x, p.y);
    if (e.cancelable) e.preventDefault();
  }
  function up(e) {
    if (!active) return;
    active = false;
    var p = ptOf(e);
    node.classList.remove('dragging'); node.style.zIndex = '';
    var ok = h.end ? h.end(p.x, p.y) : false;
    if (!ok) { node.style.transition = 'transform .22s ease-out'; node.style.transform = 'translate(0px,0px)'; }
  }
  node.addEventListener('mousedown', down);
  node.addEventListener('touchstart', down, { passive: false });
  onDoc('mousemove', move); onDoc('touchmove', move, { passive: false });
  onDoc('mouseup', up); onDoc('touchend', up); onDoc('touchcancel', up);
}
// free dragging inside a stage (sets left/top)
function dragFree(node, stage, onChange) {
  var active = false, ox = 0, oy = 0;
  function down(e) {
    var p = ptOf(e), r = node.getBoundingClientRect();
    active = true; ox = p.x - (r.left + r.width / 2); oy = p.y - (r.top + r.height / 2);
    node.classList.add('dragging');
    if (e.cancelable) e.preventDefault();
  }
  function move(e) {
    if (!active) return;
    var p = ptOf(e), s = stage.getBoundingClientRect();
    node.style.left = clamp(p.x - ox - s.left, 24, s.width - 24) + 'px';
    node.style.top = clamp(p.y - oy - s.top, 24, s.height - 24) + 'px';
    if (onChange) onChange();
    if (e.cancelable) e.preventDefault();
  }
  function up() { if (active) { active = false; node.classList.remove('dragging'); if (onChange) onChange(); } }
  node.addEventListener('mousedown', down);
  node.addEventListener('touchstart', down, { passive: false });
  onDoc('mousemove', move); onDoc('touchmove', move, { passive: false });
  onDoc('mouseup', up); onDoc('touchend', up); onDoc('touchcancel', up);
}
function resultBox(parent, score, total, restart, title) {
  var box = el('div', 'quiz-final');
  box.appendChild(el('div', 'res-title', title || 'نتیجه'));
  var pct = total ? Math.round(score * 100 / total) : 0;
  box.appendChild(el('div', 'res-pct', toFa(pct) + '٪'));
  var bar = el('div', 'res-bar'), fill = el('div', 'res-fill');
  fill.style.width = pct + '%';
  fill.style.background = pct >= 70 ? '#10B981' : (pct >= 40 ? '#F59E0B' : '#EF4444');
  bar.appendChild(fill); box.appendChild(bar);
  box.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(total)));
  var row = el('div', 'quiz-nav');
  row.appendChild(btn('بازی جدید', 'green', restart));
  box.appendChild(row);
  parent.appendChild(box);
  if (total && score / total >= 0.7) confettiBurst();
  return box;
}
function progressBar(frac) {
  var b = el('div', 'prog'), f = el('div', 'prog-fill');
  f.style.width = Math.round(clamp(frac, 0, 1) * 100) + '%';
  b.appendChild(f);
  return b;
}
// multiple choice engine: questions [{q, o[4], c, e, scen}]
function mcq(host, cfg) {
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var pool, idx, score;
  function start() {
    pool = cfg.shuffleQ ? shuffle(cfg.questions.slice()) : cfg.questions.slice();
    if (cfg.count) pool = pool.slice(0, cfg.count);
    idx = 0; score = 0;
    show();
  }
  function show() {
    clear(wrap);
    if (idx >= pool.length) { resultBox(wrap, score, pool.length, start, cfg.finalTitle); return; }
    var q = pool[idx];
    wrap.appendChild(progressBar(idx / pool.length));
    wrap.appendChild(el('div', 'mc-count', 'سوال ' + toFa(idx + 1) + ' از ' + toFa(pool.length)));
    if (q.scen) wrap.appendChild(el('div', 'scenario-card', faText(q.scen)));
    wrap.appendChild(el('div', 'quiz-question', faText(q.q)));
    var opts = el('div', 'quiz-options');
    var order = shuffle([0, 1, 2, 3]), buttons = [], locked = false;
    var expl = el('div', 'quiz-expl');
    expl.style.display = 'none';
    var nav = el('div', 'quiz-nav');
    order.forEach(function (oi) {
      var b = el('button', 'quiz-opt', faText(q.o[oi]));
      b.type = 'button';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (oi === q.c);
        if (ok) score++;
        buttons.forEach(function (x) { x.btn.disabled = true; if (x.oi === q.c) x.btn.classList.add('correct'); });
        if (!ok) b.classList.add('wrong');
        expl.textContent = (ok ? '✓ ' : '✗ ') + faText(q.e || (ok ? 'درست است!' : 'پاسخ درست با رنگ سبز مشخص شد.'));
        expl.style.display = 'block';
        nav.appendChild(btn(idx === pool.length - 1 ? 'نتیجه' : 'بعدی', '', function () { idx++; show(); }));
      });
      buttons.push({ btn: b, oi: oi });
      opts.appendChild(b);
    });
    wrap.appendChild(opts); wrap.appendChild(expl); wrap.appendChild(nav);
  }
  start();
  return { restart: start };
}
// matching: left[i] <-> right[i]; icons optional (array of css colours)
function matchGame(host, left, right, icons) {
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var done, sel, score, rorder, busy;
  function start() {
    clear(wrap);
    done = []; sel = -1; score = 0; busy = false;
    rorder = shuffle(left.map(function (_, i) { return i; }));
    var count = el('div', 'mc-count', 'امتیاز: ' + toFa(0) + ' از ' + toFa(left.length));
    wrap.appendChild(count);
    var cols = el('div', 'match-cols'), lc = el('div', 'match-col'), rc = el('div', 'match-col');
    var lb = [], rb = [];
    left.forEach(function (t, i) {
      var b = el('button', 'match-item');
      b.type = 'button';
      if (icons) { var d = el('span', 'dot'); d.style.background = icons[i]; b.appendChild(d); }
      b.appendChild(document.createTextNode(t));
      b.addEventListener('click', function () {
        if (busy || done[i]) return;
        sel = (sel === i) ? -1 : i;
        lb.forEach(function (x, k) { x.classList.toggle('sel', k === sel); });
      });
      lb.push(b); lc.appendChild(b);
    });
    rorder.forEach(function (ri) {
      var b = el('button', 'match-item', right[ri]);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (busy || done[ri] || sel < 0) return;
        if (sel === ri) {
          done[ri] = true; score++;
          lb[ri].className = 'match-item ok'; b.className = 'match-item ok';
          sel = -1;
          lb.forEach(function (x) { x.classList.remove('sel'); });
          count.textContent = 'امتیاز: ' + toFa(score) + ' از ' + toFa(left.length);
          if (score === left.length) later(function () { resultBox(wrap, score, left.length, start); }, 500);
        } else {
          busy = true;
          var cur = sel;
          lb[cur].classList.add('bad'); b.classList.add('bad');
          later(function () { lb[cur].classList.remove('bad', 'sel'); b.classList.remove('bad'); sel = -1; busy = false; }, 500);
        }
      });
      rb.push(b); rc.appendChild(b);
    });
    cols.appendChild(lc); cols.appendChild(rc); wrap.appendChild(cols);
  }
  start();
}
// one card + several choice buttons per round: items [{html|text, a, why}]
function choiceGame(host, items, choices, opts) {
  opts = opts || {};
  var wrap = el('div', 'mc-wrap');
  host.appendChild(wrap);
  var pool, idx, score;
  function start() { pool = shuffle(items.slice()); if (opts.count) pool = pool.slice(0, opts.count); idx = 0; score = 0; show(); }
  function show() {
    clear(wrap);
    if (idx >= pool.length) { resultBox(wrap, score, pool.length, start); return; }
    var it = pool[idx];
    wrap.appendChild(progressBar(idx / pool.length));
    wrap.appendChild(el('div', 'mc-count', toFa(idx + 1) + ' از ' + toFa(pool.length)));
    if (opts.prompt) wrap.appendChild(el('div', 'mc-prompt', opts.prompt));
    var card = el('div', 'choice-card');
    if (it.html) card.innerHTML = it.html; else card.textContent = it.text;
    wrap.appendChild(card);
    var row = el('div', 'choice-row'), bs = [], locked = false;
    choices.forEach(function (c, ci) {
      var b = el('button', 'choice-btn', c);
      b.type = 'button';
      b.addEventListener('click', function () {
        if (locked) return;
        locked = true;
        var ok = (ci === it.a);
        if (ok) score++;
        bs.forEach(function (x, k) { x.disabled = true; if (k === it.a) x.classList.add('correct'); });
        if (!ok) b.classList.add('wrong');
        fb.textContent = ok ? '✓ درست است' : '✗ پاسخ درست: ' + choices[it.a];
        fb.className = 'choice-fb ' + (ok ? 'ok' : 'bad');
        later(function () { idx++; show(); }, ok ? 900 : 1500);
      });
      bs.push(b); row.appendChild(b);
    });
    wrap.appendChild(row);
    var fb = el('div', 'choice-fb', '');
    wrap.appendChild(fb);
  }
  start();
}

var DK = '#334155';
function svgWrap(w, h, inner, minW) {
  return '<svg viewBox="0 0 ' + w + ' ' + h + '" xmlns="http://www.w3.org/2000/svg" style="width:100%;' + (minW ? 'min-width:' + minW + 'px;' : 'max-width:420px;') + '" font-family="Vazirmatn, Tahoma, sans-serif">' + inner + '</svg>';
}
function sT(x, y, text, size, anchor, fill) {
  return '<text x="' + x + '" y="' + y + '" font-size="' + (size || 11) + '" text-anchor="' + (anchor || 'middle') + '" fill="' + (fill || DK) + '">' + text + '</text>';
}
function sR(x, y, w, h, fill, stroke) {
  return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" fill="' + fill + '"' + (stroke ? ' stroke="' + stroke + '" stroke-width="2"' : '') + '/>';
}
function sP(d, color, w) { return '<path d="' + d + '" stroke="' + (color || DK) + '" stroke-width="' + (w || 1) + '" fill="none"/>'; }

// ---------- experiment: 7 substances poured into water (canvas) ----------
function initExperiment(sec) {
  var W = 360, H = 440, BL = 210, BR = 330, BT = 170, BB = 400, WT = 250, NP = 60;
  var wrap = el('div', 'exp-wrap');
  var info = el('div', 'exp-info');
  var cv = el('canvas', 'exp-canvas');
  cv.width = W; cv.height = H;
  var ctl = el('div', 'exp-ctl');
  wrap.appendChild(info); wrap.appendChild(cv); wrap.appendChild(ctl);
  sec.appendChild(wrap);
  var ctx = cv.getContext('2d');
  var N = D.expNames.length;
  var i, phase, preds, oks, score, jar, remaining, spawnAcc, parts, oilAmt, cloud, cloudStart, dissolve, phaseT, dragging, gx, gy, px, py;

  function resetRound() {
    jar = { x: 70, y: 330, tilt: 0 };
    remaining = 1; spawnAcc = 0; parts = []; oilAmt = 0; cloud = 0; cloudStart = 0; dissolve = 0; phaseT = 0;
    dragging = false; gx = 0; gy = 0; px = 0; py = 0; phase = 0;
  }
  function resetAll() { i = 0; preds = []; oks = []; score = 0; resetRound(); ui(); }
  function ui() {
    clear(info); clear(ctl);
    if (phase === 0) {
      info.textContent = 'ماده ' + toFa(i + 1) + ' از ' + toFa(N) + ' — آیا «' + D.expNames[i] + '» در آب حل می‌شود؟';
      ctl.appendChild(btn('بله', 'green', function () { preds[i] = 1; phase = 1; ui(); }));
      ctl.appendChild(btn('خیر', 'red', function () { preds[i] = 0; phase = 1; ui(); }));
    } else if (phase === 1) {
      info.textContent = 'ظرف را بگیرید و بالای لیوان ببرید تا مواد بریزد';
    } else if (phase === 2) {
      info.textContent = 'لیوان را تکان می‌دهیم ...';
    } else if (phase === 3) {
      info.textContent = (oks[i] ? '✓ پیش‌بینی درست بود — ' : '✗ پیش‌بینی درست نبود — ') + D.expNames[i] + ': ' + D.expRes[i];
      ctl.appendChild(btn('تایید و ماده بعدی', '', function () {
        i++;
        if (i >= N) { phase = 4; table(); } else { resetRound(); ui(); }
      }));
    }
  }
  function table() {
    clear(info); clear(ctl);
    info.textContent = 'جدول مقایسه نتایج';
    var t = el('table', 'exp-table'), h = el('tr');
    ['ماده', 'پیش‌بینی', 'نتیجه', 'وضعیت'].forEach(function (x) { h.appendChild(el('th', '', x)); });
    t.appendChild(h);
    for (var k = 0; k < N; k++) {
      var r = el('tr');
      r.appendChild(el('td', '', D.expNames[k]));
      r.appendChild(el('td', '', preds[k] ? 'حل می‌شود' : 'حل نمی‌شود'));
      r.appendChild(el('td', '', D.expSol[k] ? 'حل می‌شود' : 'حل نمی‌شود'));
      var s = el('td', oks[k] ? 'ok' : 'bad', oks[k] ? '✓' : '✗');
      r.appendChild(s); t.appendChild(r);
    }
    ctl.appendChild(t);
    resultBox(ctl, score, N, resetAll, 'پیش‌بینی‌های درست');
  }
  function cpt(e) {
    var t = ptOf(e), r = cv.getBoundingClientRect();
    return { x: (t.x - r.left) * W / (r.width || W), y: (t.y - r.top) * H / (r.height || H) };
  }
  function down(e) {
    if (phase !== 1) return;
    var p = cpt(e);
    if (Math.abs(p.x - jar.x) < 50 && Math.abs(p.y - jar.y) < 50) {
      dragging = true; gx = p.x - jar.x; gy = p.y - jar.y; px = p.x; py = p.y;
      if (e.cancelable) e.preventDefault();
    }
  }
  function move(e) { if (!dragging) return; var p = cpt(e); px = p.x; py = p.y; if (e.cancelable) e.preventDefault(); }
  function up() { dragging = false; }
  cv.addEventListener('mousedown', down);
  cv.addEventListener('touchstart', down, { passive: false });
  onDoc('mousemove', move); onDoc('touchmove', move, { passive: false });
  onDoc('mouseup', up); onDoc('touchend', up); onDoc('touchcancel', up);

  function lip() {
    var c = Math.cos(jar.tilt), s = Math.sin(jar.tilt);
    return { x: jar.x + 23 * c + 29 * s, y: jar.y + 23 * s - 29 * c };
  }
  function stepParts(dt) {
    for (var k = 0; k < parts.length; k++) {
      var p = parts[k];
      if (p.st === 0) {
        p.vy += 560 * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= (1 - 0.5 * dt);
        if (p.x < BL + 4) { p.x = BL + 4; p.vx = 0; }
        if (p.x > BR - 4) { p.x = BR - 4; p.vx = 0; }
        if (p.y >= WT) {
          p.y = WT;
          if (i === 0) { oilAmt += 1 / NP; p.st = 9; }
          else if (i === 1) { p.st = 1; p.y = WT - 1 - rnd(3); p.vx = (rnd(21) - 10) / 4; p.vy = 0; }
          else if (i === 2) { p.st = 2; p.vy = 24 + rnd(12); p.vx = (rnd(21) - 10) * 1.2; }
          else if (i === 4) { p.st = 2; p.vy = Math.max(p.vy, 150); p.vx *= 0.2; }
          else if (i === 3) { p.st = 4; p.t = 0; dissolve += 1 / NP; }
          else if (i === 5) { p.st = 9; }
          else { p.st = 4; p.t = 0; cloud = Math.min(1, cloud + 1.6 / NP); }
        }
      } else if (p.st === 1) {
        p.x += p.vx * dt;
        if (p.x < BL + 4) { p.x = BL + 4; p.vx = -p.vx; }
        if (p.x > BR - 4) { p.x = BR - 4; p.vx = -p.vx; }
      } else if (p.st === 2) {
        p.y += p.vy * dt; p.x += p.vx * dt;
        if (p.x < BL + 4) p.x = BL + 4;
        if (p.x > BR - 4) p.x = BR - 4;
        if (p.y >= BB - 4 - p.a) { p.y = BB - 4 - p.a; p.st = 3; }
      } else if (p.st === 4) {
        p.t += dt; p.y += 16 * dt;
        if (p.t > (i === 6 ? 1.2 : 0.5)) p.st = 9;
      }
    }
    parts = parts.filter(function (q) { return q.st !== 9; });
  }
  function step(dt) {
    if (phase < 1 || phase > 3) return;
    if (phase === 1) {
      if (dragging) { jar.x = clamp(px - gx, 30, W - 30); jar.y = clamp(py - gy, 90, H - 40); }
      var target = 0.7 * clamp((jar.x - 110) / 80, 0, 1);
      jar.tilt += (target - jar.tilt) * Math.min(1, dt * 8);
      var L = lip();
      if (remaining > 0 && jar.tilt > 0.3 && L.x > BL + 6 && L.x < BR - 6 && L.y < WT - 8) {
        var rate = clamp((jar.tilt - 0.3) / 0.4, 0, 1);
        var amt = Math.min(remaining, rate * 0.45 * dt);
        remaining -= amt; spawnAcc += amt * NP;
        while (spawnAcc >= 1) {
          parts.push({ x: L.x + rnd(5) - 2, y: L.y, vx: 120 * jar.tilt + rnd(21) - 10, vy: rnd(20), a: rnd(8), t: 0, st: 0 });
          spawnAcc -= 1;
        }
      }
    }
    stepParts(dt);
    if (phase === 1 && remaining <= 0) {
      var active = parts.some(function (q) { return q.st === 0 || q.st === 2 || q.st === 4; });
      if (!active) { phase = 2; phaseT = 0; cloudStart = cloud; ui(); }
    } else if (phase === 2) {
      phaseT += dt;
      if (i === 6) cloud = cloudStart * clamp(1 - phaseT, 0, 1);
      if (phaseT >= 1) {
        cloud = 0; phase = 3;
        oks[i] = (preds[i] === (D.expSol[i] ? 1 : 0));
        if (oks[i]) score++;
        ui();
      }
    }
  }
  function draw() {
    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = '#EEF3FA'; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#A88C6C'; ctx.fillRect(0, BB + 2, W, H - BB - 2);
    var col = css(D.expCol[i] || [200, 200, 200]);
    ctx.save();
    ctx.translate(phase === 2 ? Math.sin(phaseT * 45) * 4 * (1 - phaseT) : 0, 0);
    var g = (i === 3) ? Math.min(0.6, dissolve * 0.6) : 0;
    ctx.fillStyle = 'rgba(' + Math.round(110 + 40 * g / 0.6) + ',' + Math.round(170 + 45 * g / 0.6) + ',' + Math.round(230 - 80 * g / 0.6) + ',0.78)';
    ctx.fillRect(BL + 2, WT, BR - BL - 4, BB - WT - 2);
    if (cloud > 0.01) { ctx.fillStyle = 'rgba(255,255,255,' + (cloud * 0.78) + ')'; ctx.fillRect(BL + 2, WT, BR - BL - 4, BB - WT - 2); }
    if (oilAmt > 0.01) {
      var th = oilAmt * 34;
      ctx.fillStyle = 'rgba(235,190,40,0.85)'; ctx.fillRect(BL + 2, WT - th, BR - BL - 4, th);
    }
    var liquid = (i === 0 || i === 3 || i === 5);
    parts.forEach(function (p) {
      if (p.st === 4) ctx.globalAlpha = clamp(1 - p.t / (i === 6 ? 1.2 : 0.5), 0, 1);
      if (liquid) { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(p.x, p.y, 2.5, 0, 6.2832); ctx.fill(); }
      else { ctx.fillStyle = '#64748B'; ctx.fillRect(p.x - 2.5, p.y - 2.5, 5, 5); ctx.fillStyle = col; ctx.fillRect(p.x - 1.5, p.y - 1.5, 3, 3); }
      ctx.globalAlpha = 1;
    });
    ctx.strokeStyle = '#475569'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(BL, BT); ctx.lineTo(BL, BB); ctx.lineTo(BR, BB); ctx.lineTo(BR, BT); ctx.stroke();
    ctx.restore();
    if (phase <= 2) {
      ctx.save();
      ctx.translate(jar.x, jar.y); ctx.rotate(jar.tilt);
      ctx.fillStyle = 'rgba(205,222,240,0.7)'; ctx.fillRect(-23, -29, 46, 58);
      var ch = 50 * remaining;
      if (ch > 0.5) { ctx.fillStyle = col; ctx.fillRect(-20, 26 - ch, 40, ch); }
      ctx.fillStyle = '#78808C'; ctx.fillRect(-16, -37, 32, 8);
      ctx.strokeStyle = '#46505F'; ctx.lineWidth = 2; ctx.strokeRect(-23, -29, 46, 58);
      ctx.restore();
      ctx.fillStyle = '#334155'; ctx.font = '13px Vazirmatn, Tahoma, sans-serif'; ctx.textAlign = 'center';
      ctx.fillText(D.expNames[i], jar.x, jar.y + 52);
    }
  }
  resetAll();
  loop(function (dt) { if (!visible(cv)) return; step(dt); draw(); });
}

// ---------- technology: drag benefit / harm cards ----------
function initTech(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var ti, score;
  function rgba(c, a) { return 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')'; }
  function restart() { ti = 0; score = 0; show(); }
  function show() {
    clear(wrap);
    var n = D.techs.length;
    if (ti >= n) { resultBox(wrap, score, n * 2, restart, 'نتیجه فناوری'); return; }
    var t = D.techs[ti];
    wrap.appendChild(progressBar(ti / n));
    wrap.appendChild(el('div', 'mc-count', 'فناوری ' + toFa(ti + 1) + ' از ' + toFa(n)));
    wrap.appendChild(el('div', 'tech-name', t[0]));
    wrap.appendChild(el('div', 'mc-prompt', 'هر کارت را به جای درست بکشید'));
    var zones = el('div', 'zones');
    var zp = el('div', 'zone'), zc = el('div', 'zone');
    zp.style.background = rgba(t[3], 0.2); zp.style.borderColor = rgba(t[3], 0.9);
    zc.style.background = rgba(t[4], 0.2); zc.style.borderColor = rgba(t[4], 0.9);
    zp.appendChild(el('div', 'zone-label', 'فایده')); zc.appendChild(el('div', 'zone-label', 'ضرر'));
    zones.appendChild(zp); zones.appendChild(zc); wrap.appendChild(zones);
    var pool = el('div', 'card-pool'), nav = el('div', 'quiz-nav'), placed = 0;
    shuffle([{ text: t[1], type: 0 }, { text: t[2], type: 1 }]).forEach(function (c) {
      var node = el('div', 'drag-card', c.text), wrong = false;
      pool.appendChild(node);
      makeDrag(node, {
        end: function (x, y) {
          var z = hit(zp, x, y) ? 0 : (hit(zc, x, y) ? 1 : -1);
          if (z < 0) return false;
          if (z === c.type) {
            (z === 0 ? zp : zc).appendChild(node);
            node.style.transform = ''; node.style.transition = '';
            node.classList.add('placed', 'ok');
            node.style.pointerEvents = 'none';
            if (!wrong) score++;
            placed++;
            if (placed === 2) nav.appendChild(btn(ti === n - 1 ? 'نتیجه' : 'بعدی', '', function () { ti++; show(); }));
            return true;
          }
          wrong = true;
          node.classList.add('bad');
          later(function () { node.classList.remove('bad'); }, 500);
          return false;
        }
      });
    });
    wrap.appendChild(pool); wrap.appendChild(nav);
  }
  restart();
}

// ---------- applications: drag 16 items to 4 categories ----------
function initApps(sec) {
  var wrap = el('div', 'mc-wrap');
  sec.appendChild(wrap);
  var score, placed;
  function build() {
    clear(wrap);
    score = 0; placed = 0;
    var total = D.apps.length;
    var count = el('div', 'mc-count', toFa(0) + ' از ' + toFa(total));
    wrap.appendChild(count);
    wrap.appendChild(el('div', 'mc-prompt', 'هر کارت را روی دستهٔ مناسب آن بکشید'));
    var zones = el('div', 'zones4'), zs = [];
    D.appCat.forEach(function (name) {
      var z = el('div', 'zone');
      z.appendChild(el('div', 'zone-label', name));
      zs.push(z); zones.appendChild(z);
    });
    wrap.appendChild(zones);
    var pool = el('div', 'card-pool');
    shuffle(D.apps.slice()).forEach(function (a) {
      var node = el('div', 'drag-card small', a[0]), wrong = false;
      pool.appendChild(node);
      makeDrag(node, {
        end: function (x, y) {
          var z = -1;
          for (var k = 0; k < zs.length; k++) if (hit(zs[k], x, y)) z = k;
          if (z < 0) return false;
          if (z === a[1]) {
            zs[z].appendChild(node);
            node.style.transform = ''; node.style.transition = '';
            node.classList.add('placed', 'ok'); node.style.pointerEvents = 'none';
            if (!wrong) score++;
            placed++;
            count.textContent = toFa(placed) + ' از ' + toFa(total);
            if (placed === total) later(function () { resultBox(wrap, score, total, build, 'نتیجه کاربرد علوم'); }, 400);
            return true;
          }
          wrong = true;
          node.classList.add('bad');
          later(function () { node.classList.remove('bad'); }, 500);
          return false;
        }
      });
    });
    wrap.appendChild(pool);
  }
  build();
}

function initFactors(sec) {
  var info = el('div', 'fac-info');
  D.facName.forEach(function (n, k) {
    var c = el('div', 'fac-card');
    c.appendChild(el('div', 'fac-name', n));
    c.appendChild(el('div', 'fac-desc', D.facDesc[k]));
    info.appendChild(c);
  });
  sec.appendChild(info);
  choiceGame(sec, D.facEx.map(function (x) { return { text: x[0], a: x[1] }; }), D.facName, { prompt: 'این مثال مربوط به کدام عامل است؟' });
}

function safe(root, fn, section) {
  try { if (section) fn(section); } catch (e) { showError(root, e); }
}
window.chapterInit = function (root) {
  dead = false;
  try {
    buildHome(root, [
      { icon: '⚗️', label: 'آزمایش کنید', type: 'experiment' },
      { icon: '🔬', label: 'روش علمی', type: 'scenario' },
      { icon: '⚙️', label: 'فناوری', type: 'dragdrop', renderer: 'benefit_harm' },
      { icon: '💡', label: 'عوامل تولید علم', type: 'sort' },
      { icon: '📝', label: 'آزمون جامع', type: 'quiz' },
      { icon: '👨‍🔬', label: 'مشاغل علمی', type: 'match' },
      { icon: '🚀', label: 'کاربرد علوم', type: 'dragdrop', renderer: 'apps4cat' }
    ]);
  } catch (e) { showError(root, e); return; }
  safe(root, initExperiment, secOf(root, 'experiment'));
  safe(root, function (s) {
    mcq(s, { questions: D.sciQs.map(function (x) { return { scen: x[0], q: x[1], o: x[2], c: x[3], e: x[4] }; }), finalTitle: 'نتیجه روش علمی' });
  }, secOf(root, 'scenario'));
  safe(root, initTech, secOf(root, 'dragdrop', 'benefit_harm'));
  safe(root, initFactors, secOf(root, 'sort'));
  safe(root, function (s) {
    mcq(s, { questions: D.quiz.map(function (x) { return { q: x[0], o: x[1], c: x[2] }; }), finalTitle: 'نتیجه آزمون' });
  }, secOf(root, 'quiz'));
  safe(root, function (s) { matchGame(s, D.carName, D.carDesc, null); }, secOf(root, 'match'));
  safe(root, initApps, secOf(root, 'dragdrop', 'apps4cat'));
};
window.chapterTeardown = function () {
  dead = true;
  timeouts.forEach(function (t) { clearTimeout(t); }); timeouts = [];
  docHandlers.forEach(function (h) { document.removeEventListener(h[0], h[1], h[2]); }); docHandlers = [];
};

})();
