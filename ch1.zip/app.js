﻿(function () {
  'use strict';

  window.chapterInit = function (root, chapterId) {
    initHome(root);
    initExp(root);
    initScenario(root);
    initTech(root);
    initFactors(root);
    initQuiz(root);
    initCareer(root);
    initApps(root);
  };

  function toFa(n) {
    var fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return String(n).split('').map(function (c) {
      return /\d/.test(c) ? fa[parseInt(c, 10)] : c;
    }).join('');
  }

  function shuffle(a) {
    for (var i = a.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }

  function confettiBurst() {
    var colors = ['#2563EB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];
    for (var i = 0; i < 80; i++) {
      var p = document.createElement('div');
      p.className = 'confetti-piece';
      p.style.left = (30 + Math.random() * 40) + '%';
      p.style.background = colors[Math.floor(Math.random() * colors.length)];
      p.style.animationDelay = (Math.random() * 0.3) + 's';
      p.style.animationDuration = (1.8 + Math.random() * 1.2) + 's';
      document.body.appendChild(p);
      (function (node) {
        setTimeout(function () { node.remove(); }, 3500);
      })(p);
    }
  }

  // ============================================================
  // HOME
  // ============================================================
  function initHome(root) {
    var grid = root.querySelector('#home-grid');
    if (!grid) return;
    var items = [
      { label: 'آزمایش کنید', icon: '⚗️', type: 'experiment' },
      { label: 'روش علمی', icon: '🔬', type: 'scenario' },
      { label: 'فناوری', icon: '⚙️', type: 'dragdrop', r: 'benefit_harm' },
      { label: 'عوامل تولید علم', icon: '💡', type: 'sort' },
      { label: 'آزمون جامع', icon: '📝', type: 'quiz' },
      { label: 'مشاغل علمی', icon: '👨‍🔬', type: 'match' },
      { label: 'کاربرد علوم', icon: '🚀', type: 'dragdrop', r: 'apps4cat' }
    ];
    items.forEach(function (it) {
      var b = el('button', 'home-card');
      var ic = el('span', 'icon', it.icon);
      b.appendChild(ic);
      b.appendChild(document.createTextNode(it.label));
      b.onclick = function () {
        var sections = root.querySelectorAll('section');
        for (var i = 0; i < sections.length; i++) {
          var s = sections[i];
          var mt = s.getAttribute('data-type');
          var mr = s.getAttribute('data-renderer');
          if (mt === it.type && (!it.r || mr === it.r)) {
            if (window.__openSection) window.__openSection(s);
            return;
          }
        }
      };
      grid.appendChild(b);
    });
  }

  // ============================================================
  // EXPERIMENT — 7 SUBSTANCES (canvas)
  // ============================================================
  var EXP_NAMES = ['روغن مایع','گوگرد','نشاسته','جوهر نمک','براده آهن','اتانول','نمک خوراکی'];
  var EXP_SOL = [false, false, false, true, false, true, true];
  var EXP_RES = [
    'حل نمی‌شود؛ لایه‌ای طلایی روی آب شناور می‌ماند',
    'حل نمی‌شود؛ پودر زرد روی سطح آب شناور می‌ماند',
    'حل نمی‌شود؛ به‌آهستگی ته‌نشین می‌شود',
    'حل می‌شود؛ آب کمی سبز می‌شود',
    'حل نمی‌شود؛ سریع ته‌نشین می‌شود',
    'حل می‌شود؛ بی‌رنگ و نامرئی است',
    'حل می‌شود؛ پس از تکان دادن آب شفاف می‌شود'
  ];
  var EXP_COL = ['#E6BE28','#F0E13C','#F5F2E1','#BEE196','#464650','#C8E1F5','#FAFAFA'];

  function initExp(root) {
    var sec = root.querySelector('section[data-renderer="pour7"]');
    if (!sec) return;
    var canvas = sec.querySelector('#exp-canvas');
    var stepEl = sec.querySelector('#exp-step');
    var promptEl = sec.querySelector('#exp-prompt');
    var actionsEl = sec.querySelector('#exp-actions');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');

    var W = canvas.width, H = canvas.height;
    var BL = 300, BR = 500, BT = 160, BB = 420, WT = 220;
    var NPART = 100;

    var expIdx = 0, expPhase = 0, expScore = 0;
    var expPred = [0,0,0,0,0,0,0];
    var expOk = [false,false,false,false,false,false,false];
    var parts = [], splashes = [], ripples = [];
    var jarX = 110, jarY = 300, tilt = 0, remaining = 1, spawnAcc = 0;
    var cloud = 0, dissolveAmt = 0, oilAmt = 0, phaseT = 0;
    var jarDrag = false, grabDX = 0, grabDY = 0;
    var flashUntil = 0;

    function resetRound() {
      parts = []; splashes = []; ripples = [];
      jarX = 110; jarY = 300; tilt = 0; remaining = 1; spawnAcc = 0;
      cloud = 0; dissolveAmt = 0; oilAmt = 0; phaseT = 0;
      jarDrag = false; expPhase = 0;
    }

    function setPrompt() {
      if (expPhase === 4) {
        stepEl.textContent = 'جدول مقایسه نتایج';
        promptEl.textContent = 'پیش‌بینی درست: ' + toFa(expScore) + ' از ۷';
        return;
      }
      stepEl.textContent = 'ماده ' + toFa(expIdx + 1) + ' از ۷';
      if (expPhase === 0) {
        promptEl.textContent = 'آیا «' + EXP_NAMES[expIdx] + '» در آب حل می‌شود؟';
      } else if (expPhase === 1) {
        promptEl.textContent = 'ظرف را بگیرید و بالای لیوان بکشید تا مواد بریزد';
      } else if (expPhase === 2) {
        promptEl.textContent = 'لیوان را تکان می‌دهیم...';
      } else {
        promptEl.textContent = EXP_NAMES[expIdx] + ': ' + EXP_RES[expIdx];
      }
    }

    function clearActions() { actionsEl.innerHTML = ''; }

    function buildActions() {
      clearActions();
      if (expPhase === 0) {
        var yBtn = el('button', 'btn-sm green', 'بله');
        yBtn.onclick = function () { expPred[expIdx] = 1; expPhase = 1; setPrompt(); buildActions(); };
        var nBtn = el('button', 'btn-sm red', 'خیر');
        nBtn.onclick = function () { expPred[expIdx] = 0; expPhase = 1; setPrompt(); buildActions(); };
        actionsEl.appendChild(yBtn);
        actionsEl.appendChild(nBtn);
      } else if (expPhase === 3) {
        var nx = el('button', 'btn-sm', 'تایید و ماده بعدی');
        nx.onclick = function () {
          expIdx++;
          if (expIdx >= 7) { expPhase = 4; }
          else { resetRound(); setPrompt(); buildActions(); }
        };
        actionsEl.appendChild(nx);
      } else if (expPhase === 4) {
        var done = el('button', 'btn-sm green', 'پایان آزمایش');
        done.onclick = function () {
          if (window.__goBack) window.__goBack();
        };
        actionsEl.appendChild(done);
      }
    }

    function jarLip() {
      var c = Math.cos(tilt), s = Math.sin(tilt);
      var lx = jarX + 35 * c - (-45) * s;
      var ly = jarY + 35 * s + (-45) * c;
      return { x: lx, y: ly };
    }

    function addRipple(x) {
      if (ripples.length < 10 && Math.random() < 0.34) ripples.push({ x: x, age: 0 });
    }
    function addSplash(x) {
      if (Math.random() > 0.34) return;
      for (var k = 0; k < 2; k++) {
        splashes.push({
          x: x, y: WT,
          vx: (Math.random() * 80 - 40),
          vy: -(80 + Math.random() * 80),
          life: 0.5
        });
      }
    }

    function stepParticles(dt) {
      for (var i = 0; i < parts.length; i++) {
        var p = parts[i];
        if (p.st === 0) {
          p.vy += 700 * dt;
          p.x += p.vx * dt; p.y += p.vy * dt;
          p.vx *= (1 - 0.5 * dt);
          if (p.x < BL + 4) p.x = BL + 4;
          if (p.x > BR - 4) p.x = BR - 4;
          if (p.y >= WT) {
            addRipple(p.x); addSplash(p.x);
            p.y = WT;
            if (expIdx === 0) { oilAmt += 1 / NPART; p.st = 9; }
            else if (expIdx === 1) { p.st = 1; p.y = WT - 1 - Math.floor(Math.random() * 3); p.vx = (Math.random() * 21 - 10) / 4; p.vy = 0; }
            else if (expIdx === 2) { p.st = 2; p.vy = 30 + Math.random() * 15; p.vx = (Math.random() * 21 - 10) * 1.5; }
            else if (expIdx === 4) { p.st = 2; p.vy = Math.max(p.vy, 180); p.vx *= 0.2; }
            else if (expIdx === 3) { p.st = 4; p.t = 0; dissolveAmt += 1 / NPART; }
            else if (expIdx === 5) { p.st = 9; }
            else { p.st = 4; p.t = 0; cloud = Math.min(1, cloud + 1.6 / NPART); }
          }
        } else if (p.st === 1) {
          p.x += p.vx * dt;
          if (p.x < BL + 4) { p.x = BL + 4; p.vx = -p.vx; }
          if (p.x > BR - 4) { p.x = BR - 4; p.vx = -p.vx; }
        } else if (p.st === 2) {
          p.y += p.vy * dt; p.x += p.vx * dt;
          if (p.x < BL + 4) p.x = BL + 4;
          if (p.x > BR - 4) p.x = BR - 4;
          if (p.y >= BB - 4 - p.a) { p.y = BB - 4 - p.a; p.st = 3; }
        } else if (p.st === 4) {
          p.t += dt; p.y += 20 * dt;
          var dur = (expIdx === 6) ? 1.2 : 0.5;
          if (p.t > dur) p.st = 9;
        }
      }
      parts = parts.filter(function (p) { return p.st !== 9; });
      for (var j = 0; j < splashes.length; j++) {
        var s = splashes[j];
        s.vy += 600 * dt; s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt;
      }
      splashes = splashes.filter(function (s) { return s.life > 0 && s.y < WT + 2; });
      for (var k = 0; k < ripples.length; k++) ripples[k].age += dt;
      ripples = ripples.filter(function (r) { return r.age < 1; });
    }

    function updateExp(dt) {
      if (expPhase < 1 || expPhase > 3) return;
      if (expPhase === 1) {
        if (jarDrag) {
          jarX = clamp(pointerX - grabDX, 40, 480);
          jarY = clamp(pointerY - grabDY, 100, 460);
        }
        var target = 0.7 * clamp((jarX - 200) / 200, 0, 1);
        tilt += (target - tilt) * Math.min(1, dt * 8);
        var lip = jarLip();
        if (remaining > 0 && tilt > 0.3 && lip.x > BL + 6 && lip.x < BR - 6 && lip.y < WT - 10) {
          var rate = clamp((tilt - 0.3) / 0.4, 0, 1);
          var amt = Math.min(remaining, rate * 0.45 * dt);
          remaining -= amt;
          spawnAcc += amt * NPART;
          while (spawnAcc >= 1) {
            parts.push({
              x: lip.x + (Math.random() * 5 - 2),
              y: lip.y,
              vx: 160 * tilt + (Math.random() * 21 - 10),
              vy: Math.random() * 20,
              a: Math.random() * 10,
              t: 0, st: 0
            });
            spawnAcc -= 1;
          }
        }
      }
      stepParticles(dt);
      if (expPhase === 1 && remaining <= 0) {
        var active = parts.some(function (p) { return p.st === 0 || p.st === 2 || p.st === 4; });
        if (!active) { expPhase = 2; phaseT = 0; }
      } else if (expPhase === 2) {
        phaseT += dt;
        if (expIdx === 6) cloud = Math.max(0, cloud * (1 - phaseT));
        if (phaseT >= 1) {
          cloud = 0; expPhase = 3;
          expOk[expIdx] = (expPred[expIdx] === (EXP_SOL[expIdx] ? 1 : 0));
          if (expOk[expIdx]) expScore++;
          flashUntil = performance.now() + 1400;
          setPrompt();
          buildActions();
        }
      }
    }

    function drawJar() {
      ctx.save();
      ctx.translate(jarX, jarY);
      ctx.rotate(tilt);
      ctx.fillStyle = 'rgba(205,222,240,0.6)';
      ctx.fillRect(-35, -45, 70, 90);
      var ch = remaining * 80;
      if (ch > 0.5) {
        ctx.fillStyle = EXP_COL[expIdx];
        ctx.fillRect(-31, 41 - ch, 62, ch);
      }
      ctx.fillStyle = 'rgb(120,125,140)';
      ctx.fillRect(-26, -57, 52, 12);
      ctx.strokeStyle = 'rgb(70,80,100)';
      ctx.lineWidth = 2;
      ctx.strokeRect(-35, -45, 70, 90);
      ctx.restore();
      ctx.fillStyle = '#1A1A1A';
      ctx.font = '12px Vazirmatn, Tahoma';
      ctx.textAlign = 'center';
      ctx.fillText(EXP_NAMES[expIdx], jarX, jarY + 62);
    }

    function drawScene() {
      ctx.fillStyle = '#E8EEF7';
      ctx.fillRect(20, 60, 560, 400);
      ctx.fillStyle = 'rgb(160,130,100)';
      ctx.fillRect(20, 480, 560, 15);

      var shake = (expPhase === 2) ? Math.sin(phaseT * 45) * 5 * (1 - phaseT) : 0;
      var ox = shake;

      var wc = EXP_COL[expIdx];
      if (expIdx === 3) {
        var d = Math.min(0.6, dissolveAmt * 0.6);
        wc = blendColors('#6EAAE6', '#96D796', d);
      }
      ctx.fillStyle = hexToRgba(wc, 0.75);
      ctx.fillRect(BL + 3 + ox, WT, BR - BL - 6, BB - WT - 3);

      if (cloud > 0.01) {
        ctx.fillStyle = 'rgba(255,255,255,' + (cloud * 0.78) + ')';
        ctx.fillRect(BL + 3 + ox, WT, BR - BL - 6, BB - WT - 3);
      }

      if (oilAmt > 0.01) {
        var th = oilAmt * 36;
        ctx.fillStyle = 'rgba(235,190,40,0.82)';
        ctx.fillRect(BL + 3 + ox, WT - th, BR - BL - 6, th);
        ctx.strokeStyle = 'rgb(190,140,20)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(BL + 3 + ox, WT - th);
        ctx.lineTo(BR - 3 + ox, WT - th);
        ctx.stroke();
      }

      for (var i = 0; i < ripples.length; i++) {
        var r = ripples[i].age * 40;
        ctx.strokeStyle = 'rgba(255,255,255,' + (0.8 * (1 - ripples[i].age)) + ')';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(ripples[i].x - r + ox, WT);
        ctx.lineTo(ripples[i].x + r + ox, WT);
        ctx.stroke();
      }

      var pc = EXP_COL[expIdx];
      var liquid = (expIdx === 0 || expIdx === 3 || expIdx === 5);
      for (var j = 0; j < parts.length; j++) {
        var p = parts[j];
        var px = p.x + ox, py = p.y;
        if (p.st === 4) {
          var al = Math.max(0, 1 - p.t / ((expIdx === 6) ? 1.2 : 0.5));
          ctx.fillStyle = hexToRgba(pc, al);
          ctx.fillRect(px - 1, py - 1, 3, 3);
          continue;
        }
        if (liquid) {
          ctx.fillStyle = pc;
          ctx.beginPath();
          ctx.arc(px, py, 2, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = shadeColor(pc, -70);
          ctx.fillRect(px - 2, py - 2, 4, 4);
          ctx.fillStyle = pc;
          ctx.fillRect(px - 1, py - 1, 2, 2);
        }
      }

      for (var k = 0; k < splashes.length; k++) {
        ctx.fillStyle = 'rgb(190,225,255)';
        ctx.beginPath();
        ctx.arc(splashes[k].x + ox, splashes[k].y, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.strokeStyle = 'rgb(70,80,100)';
      ctx.lineWidth = 3;
      ctx.strokeRect(BL + ox, BT, BR - BL, BB - BT);

      if (expPhase <= 2) drawJar();

      if (expPhase >= 1 && performance.now() < flashUntil) {
        ctx.font = 'bold 20px Vazirmatn, Tahoma';
        ctx.textAlign = 'center';
        if (expOk[expIdx]) {
          ctx.fillStyle = '#10B981';
          ctx.fillText('✓ پیش‌بینی درست بود', 150, 130);
        } else {
          ctx.fillStyle = '#EF4444';
          ctx.fillText('✗ پیش‌بینی درست نبود', 150, 130);
        }
      }
    }

    var pointerX = 0, pointerY = 0;
    function getPointer(e) {
      var rect = canvas.getBoundingClientRect();
      var scaleX = canvas.width / rect.width;
      var scaleY = canvas.height / rect.height;
      var touch = e.touches ? e.touches[0] : e;
      pointerX = (touch.clientX - rect.left) * scaleX;
      pointerY = (touch.clientY - rect.top) * scaleY;
    }

    function pointerDown(e) {
      if (expPhase !== 1) return;
      getPointer(e);
      var dx = pointerX - jarX, dy = pointerY - jarY;
      if (dx * dx + dy * dy < 70 * 70) {
        jarDrag = true;
        grabDX = dx; grabDY = dy;
        e.preventDefault();
      }
    }
    function pointerMove(e) {
      if (!jarDrag) return;
      getPointer(e);
      e.preventDefault();
    }
    function pointerUp() { jarDrag = false; }

    canvas.addEventListener('mousedown', pointerDown);
    canvas.addEventListener('mousemove', pointerMove);
    canvas.addEventListener('mouseup', pointerUp);
    canvas.addEventListener('mouseleave', pointerUp);
    canvas.addEventListener('touchstart', pointerDown, { passive: false });
    canvas.addEventListener('touchmove', pointerMove, { passive: false });
    canvas.addEventListener('touchend', pointerUp);

    var lastT = performance.now();
    function loop(t) {
      var dt = Math.min(0.05, (t - lastT) / 1000);
      lastT = t;
      updateExp(dt);
      if (expPhase === 4 && !sec.querySelector('.exp-table')) buildResultsTable();
      ctx.clearRect(0, 0, W, H);
      if (expPhase !== 4) drawScene();
      requestAnimationFrame(loop);
    }

    function buildResultsTable() {
      var wrap = sec.querySelector('.exp-wrap');
      if (!wrap) return;
      var table = el('table', 'exp-table');
      var thead = el('thead');
      var trh = el('tr');
      ['ماده', 'پیش‌بینی', 'نتیجه', 'وضعیت'].forEach(function (h) {
        var th = el('th', null, h);
        trh.appendChild(th);
      });
      thead.appendChild(trh);
      table.appendChild(thead);
      var tbody = el('tbody');
      for (var i = 0; i < 7; i++) {
        var tr = el('tr');
        tr.appendChild(el('td', null, EXP_NAMES[i]));
        tr.appendChild(el('td', null, expPred[i] === 1 ? 'حل می‌شود' : 'حل نمی‌شود'));
        tr.appendChild(el('td', null, EXP_SOL[i] ? 'حل می‌شود' : 'حل نمی‌شود'));
        tr.appendChild(el('td', null, expOk[i] ? '✓' : '✗'));
        tbody.appendChild(tr);
      }
      table.appendChild(tbody);
      wrap.appendChild(table);
    }

    resetRound();
    setPrompt();
    buildActions();
    requestAnimationFrame(loop);
  }

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  function blendColors(c1, c2, t) {
    var a = hexToRgb(c1), b = hexToRgb(c2);
    var r = Math.round(a.r + (b.r - a.r) * t);
    var g = Math.round(a.g + (b.g - a.g) * t);
    var bl = Math.round(a.b + (b.b - a.b) * t);
    return 'rgb(' + r + ',' + g + ',' + bl + ')';
  }
  function shadeColor(hex, d) {
    var c = hexToRgb(hex);
    return 'rgb(' + clamp(c.r + d, 0, 255) + ',' + clamp(c.g + d, 0, 255) + ',' + clamp(c.b + d, 0, 255) + ')';
  }
  function hexToRgb(hex) {
    if (hex.startsWith('rgb')) {
      var m = hex.match(/\d+/g);
      return { r: +m[0], g: +m[1], b: +m[2] };
    }
    var h = hex.replace('#', '');
    return {
      r: parseInt(h.substring(0, 2), 16),
      g: parseInt(h.substring(2, 4), 16),
      b: parseInt(h.substring(4, 6), 16)
    };
  }
  function hexToRgba(hex, a) {
    if (hex.startsWith('rgb')) {
      var m = hex.match(/\d+/g);
      return 'rgba(' + m[0] + ',' + m[1] + ',' + m[2] + ',' + a + ')';
    }
    var c = hexToRgb(hex);
    return 'rgba(' + c.r + ',' + c.g + ',' + c.b + ',' + a + ')';
  }

  // ============================================================
  // SCENARIO — 10 questions (روش علمی)
  // ============================================================
  var SCI_QS = [
    { s: 'علی دو گیاه مشابه را در دو جای مختلف گذاشت؛ یکی در تاریکی و دیگری در نور.', q: 'او در کدام مرحله از روش علمی است؟', o: ['طرح پرسش','انجام آزمایش','نتیجه‌گیری','گزارش‌نویسی'], c: 1, e: 'او شرایط را تغییر داده و نتیجه را می‌سنجد؛ این مرحله انجام آزمایش است.' },
    { s: 'سارا می‌خواهد اثر دما بر حل شدن شکر در آب را بررسی کند.', q: 'چرا باید فقط یک متغیر را تغییر دهد؟', o: ['تا آزمایش زودتر تمام شود','تا علت تغییر مشخص شود','تا ابزار کمتری لازم باشد','تا فرضیه حتماً تأیید شود'], c: 1, e: 'اگر چند متغیر با هم عوض شوند، نمی‌توان فهمید کدام عامل نتیجه را تغییر داده است.' },
    { s: 'نتیجه آزمایش رضا با فرضیه‌اش مطابقت نداشت.', q: 'او چه کاری باید انجام دهد؟', o: ['نتیجه را تغییر دهد','فرضیه را اصلاح یا آزمایش را بازبینی کند','آزمایش را فراموش کند','فرضیه را بدون بررسی درست بداند'], c: 1, e: 'دانشمند نتیجه را تغییر نمی‌دهد؛ فرضیه را اصلاح می‌کند.' },
    { s: 'معلم از دانش‌آموزان خواست درباره یک سیب مشاهده‌هایی بنویسند.', q: 'کدام مورد با حواس پنج‌گانه قابل مشاهده نیست؟', o: ['رنگ سیب','بوی سیب','سفتی سیب','تعداد سلول‌های سیب'], c: 3, e: 'سلول‌ها بسیار ریزند و فقط با میکروسکوپ دیده می‌شوند.' },
    { s: 'چند دانش‌آموز درباره دلیل رشد سریع‌تر گیاه حدس می‌زنند.', q: 'کدام جمله یک فرضیه است؟', o: ['اگر گیاه نور بیشتری بگیرد، سریع‌تر رشد می‌کند','گیاه ۱۰ سانتی‌متر قد دارد','آیا گیاه به نور نیاز دارد؟','گیاه‌ها در باغچه رشد می‌کنند'], c: 0, e: 'فرضیه یک پاسخ احتمالی و قابل آزمایش به پرسش است.' },
    { s: 'در کلاس درباره تفاوت فرضیه و نظریه بحث می‌شود.', q: 'تفاوت اصلی کدام است؟', o: ['فرضیه همیشه درست است','نظریه فقط یک حدس است','نظریه با آزمایش‌های متعدد تأیید شده، اما فرضیه هنوز آزمون نشده','هیچ تفاوتی ندارند'], c: 2, e: 'نظریه از فرضیه‌هایی به دست می‌آید که بارها تأیید شده‌اند.' },
    { s: 'مینا آزمایشی را دو بار انجام داد و هر دو بار نتیجه یکسان گرفت.', q: 'چه نتیجه‌ای می‌گیرد؟', o: ['فرضیه برای همیشه ثابت شده است','نتیجه آزمایش قابل اعتمادتر است','آزمایش بی‌فایده بوده است','دیگر نباید آزمایش کرد'], c: 1, e: 'تکرار آزمایش و گرفتن نتیجه یکسان اعتماد را بیشتر می‌کند.' },
    { s: 'در آزمایش «اثر نور بر رشد گیاه» مقدار نور را تغییر می‌دهیم.', q: 'متغیر مستقل کدام است؟', o: ['رشد گیاه','نوع خاک','مقدار نور','مقدار آب'], c: 2, e: 'متغیر مستقل همان چیزی است که خودمان عمداً تغییر می‌دهیم.' },
    { s: 'دانشمندی می‌خواهد پژوهش خود را آغاز کند.', q: 'کدام مرحله اول انجام می‌شود؟', o: ['نتیجه‌گیری','انجام آزمایش','گزارش‌نویسی','مشاهده و طرح پرسش'], c: 3, e: 'پژوهش علمی با مشاهده و طرح پرسش شروع می‌شود.' },
    { s: 'برای ارائه یافته‌ها باید یک گزارش علمی نوشت.', q: 'کدام مورد جزو گزارش علمی نیست؟', o: ['روش انجام آزمایش','نتایج و داده‌ها','حدس‌های بدون دلیل','فرضیه'], c: 2, e: 'گزارش علمی باید بر داده‌ها تکیه کند، نه حدس بی‌پشتوانه.' }
  ];

  function initScenario(root) {
    var sec = root.querySelector('section[data-renderer="scenario10"]');
    if (!sec) return;
    var wrap = sec.querySelector('#scn-wrap');
    if (!wrap) return;
    var cur = 0, score = 0, answered = false;

    function render() {
      if (cur >= SCI_QS.length) {
        wrap.innerHTML = '';
        var f = el('div', 'scn-score');
        f.textContent = 'نتیجه: ' + toFa(score) + ' از ' + toFa(SCI_QS.length);
        wrap.appendChild(f);
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () {
          cur = 0; score = 0; answered = false; render();
          confettiBurst();
        };
        wrap.appendChild(again);
        confettiBurst();
        return;
      }
      var q = SCI_QS[cur];
      wrap.innerHTML = '';
      var card = el('div', 'scn-card');
      card.textContent = q.s;
      wrap.appendChild(card);

      var qEl = el('div', 'scn-q');
      qEl.textContent = toFa(cur + 1) + '. ' + q.q;
      wrap.appendChild(qEl);

      var idx = shuffle([0, 1, 2, 3]);
      answered = false;
      idx.forEach(function (origIdx) {
        var b = el('button', 'scn-opt', q.o[origIdx]);
        b.onclick = function () {
          if (answered) return;
          answered = true;
          if (origIdx === q.c) { score++; b.classList.add('correct'); }
          else {
            b.classList.add('wrong');
            wrap.querySelectorAll('.scn-opt').forEach(function (x, i) {
              if (idx[i] === q.c) x.classList.add('correct');
            });
          }
          wrap.querySelectorAll('.scn-opt').forEach(function (x) { x.disabled = true; });
          var ex = el('div', 'scn-expl', q.e);
          wrap.appendChild(ex);
          var nx = el('button', 'btn-sm green', cur === SCI_QS.length - 1 ? 'نتیجه' : 'بعدی');
          nx.style.marginTop = '10px';
          nx.onclick = function () { cur++; render(); };
          wrap.appendChild(nx);
        };
        wrap.appendChild(b);
      });
    }
    render();
  }

  // ============================================================
  // TECH — drag benefit / harm
  // ============================================================
  var TECHS = [
    { n: 'اتومبیل', pro: 'سرعت در جابه‌جایی', con: 'آلودگی هوا' },
    { n: 'هواپیما', pro: 'حمل‌ونقل جهانی', con: 'هزینه بالا' },
    { n: 'تلفن همراه', pro: 'ارتباط آسان', con: 'اعتیاد به فضای مجازی' },
    { n: 'دارو', pro: 'درمان بیماری', con: 'عوارض جانبی' },
    { n: 'ماهواره', pro: 'اینترنت و ارتباطات', con: 'زباله فضایی' },
    { n: 'پنل خورشیدی', pro: 'انرژی پاک', con: 'هزینه نصب بالا' },
    { n: 'پهپاد', pro: 'کشاورزی دقیق', con: 'نقض حریم خصوصی' }
  ];

  function initTech(root) {
    var sec = root.querySelector('section[data-renderer="benefit_harm"]');
    if (!sec) return;
    var wrap = sec.querySelector('#tech-wrap');
    if (!wrap) return;
    var cur = 0, score = 0;

    function render() {
      if (cur >= TECHS.length) {
        wrap.innerHTML = '';
        var f = el('div', 'tech-msg ok');
        f.textContent = 'نتیجه: ' + toFa(score) + ' از ' + toFa(TECHS.length * 2);
        wrap.appendChild(f);
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () { cur = 0; score = 0; render(); confettiBurst(); };
        wrap.appendChild(again);
        confettiBurst();
        return;
      }
      var t = TECHS[cur];
      wrap.innerHTML = '';
      var h = el('div', 'exp-step');
      h.textContent = 'چالش ' + toFa(cur + 1) + ' از ' + toFa(TECHS.length) + ' — ' + t.n;
      wrap.appendChild(h);

      var zones = el('div', 'tech-zones');
      var zPro = el('div', 'tech-zone pro', 'فایده');
      var zCon = el('div', 'tech-zone con', 'ضرر');
      zPro.dataset.type = 'pro'; zCon.dataset.type = 'con';
      [zPro, zCon].forEach(function (z) {
        z.addEventListener('dragover', function (e) { e.preventDefault(); z.classList.add('over'); });
        z.addEventListener('dragleave', function () { z.classList.remove('over'); });
        z.addEventListener('drop', function (e) {
          e.preventDefault();
          z.classList.remove('over');
          var id = e.dataTransfer.getData('text/plain');
          var card = wrap.querySelector('[data-card="' + id + '"]');
          if (!card) return;
          var isCorrect = card.dataset.correct === z.dataset.type;
          if (isCorrect) {
            score++;
            card.classList.add(z.dataset.type === 'pro' ? 'placed-pro' : 'placed-con');
            card.draggable = false;
            card.style.opacity = '0.6';
            z.textContent = z.textContent.split(' — ')[0] + ' — ' + card.textContent;
          } else {
            card.style.borderColor = '#EF4444';
            setTimeout(function () { card.style.borderColor = '#E5E7EB'; }, 600);
          }
          if (wrap.querySelectorAll('.placed-pro, .placed-con').length === 2) {
            setTimeout(function () {
              var msg = el('div', 'tech-msg ' + (score % 2 === 0 ? 'ok' : 'bad'), 'ادامه...');
              var nx = el('button', 'btn-sm green', 'بعدی');
              nx.style.marginTop = '10px';
              nx.onclick = function () { cur++; render(); };
              wrap.appendChild(nx);
            }, 700);
          }
        });
      });
      zones.appendChild(zPro); zones.appendChild(zCon);
      wrap.appendChild(zones);

      var cards = el('div', 'tech-cards');
      var items = shuffle([
        { text: t.pro, correct: 'pro', id: 'a' },
        { text: t.con, correct: 'con', id: 'b' }
      ]);
      items.forEach(function (it) {
        var c = el('div', 'tech-card', it.text);
        c.dataset.card = it.id;
        c.dataset.correct = it.correct;
        c.draggable = true;
        c.addEventListener('dragstart', function (e) {
          e.dataTransfer.setData('text/plain', it.id);
          c.classList.add('dragging');
        });
        c.addEventListener('dragend', function () { c.classList.remove('dragging'); });
        cards.appendChild(c);
      });
      wrap.appendChild(cards);
    }
    render();
  }

  // ============================================================
  // FACTORS — 12 examples, 3 factor buttons
  // ============================================================
  var FAC_NAME = ['کنجکاوی', 'دانش و اطلاعات', 'مهارت و روش'];
  var FAC_EX = [
    { t: 'مشاهده ستاره‌ها با تلسکوپ', f: 2 },
    { t: 'مطالعه کتاب دانشنامه', f: 1 },
    { t: 'پرسیدن سوال از خود', f: 0 },
    { t: 'استفاده از میکروسکوپ', f: 2 },
    { t: 'حفظ اطلاعات علمی', f: 1 },
    { t: 'داشتن حس کنجکاوی', f: 0 },
    { t: 'آزمایش با وسایل آزمایشگاهی', f: 2 },
    { t: 'مراجعه به منابع علمی', f: 1 },
    { t: 'تعجب از پدیده طبیعی', f: 0 },
    { t: 'یادگیری ریاضیات برای محاسبه', f: 1 },
    { t: 'ساختن مدل با وسایل ساده', f: 2 },
    { t: 'پرسش «چرا آسمان آبی است؟»', f: 0 }
  ];

  function initFactors(root) {
    var sec = root.querySelector('section[data-renderer="factors"]');
    if (!sec) return;
    var wrap = sec.querySelector('#fac-wrap');
    if (!wrap) return;
    var order = shuffle([0,1,2,3,4,5,6,7,8,9,10,11]);
    var cur = 0, score = 0;

    function render() {
      if (cur >= order.length) {
        wrap.innerHTML = '';
        var f = el('div', 'scn-score');
        f.textContent = 'نتیجه: ' + toFa(score) + ' از ' + toFa(order.length);
        wrap.appendChild(f);
        var again = el('button', 'btn-sm green', 'بازی جدید');
        again.style.marginTop = '20px';
        again.onclick = function () { order = shuffle([0,1,2,3,4,5,6,7,8,9,10,11]); cur = 0; score = 0; render(); confettiBurst(); };
        wrap.appendChild(again);
        confettiBurst();
        return;
      }
      wrap.innerHTML = '';
      var meta = el('div', 'exp-step');
      meta.textContent = 'مثال ' + toFa(cur + 1) + ' از ' + toFa(order.length);
      wrap.appendChild(meta);
      var ex = FAC_EX[order[cur]];
      var card = el('div', 'fac-example');
      card.textContent = ex.t;
      wrap.appendChild(card);

      var btns = el('div', 'fac-btns');
      var perm = shuffle([0, 1, 2]);
      perm.forEach(function (origIdx) {
        var b = el('button', 'fac-btn f' + origIdx, FAC_NAME[origIdx]);
        b.onclick = function () {
          btns.querySelectorAll('.fac-btn').forEach(function (x) { x.disabled = true; });
          if (origIdx === ex.f) { score++; b.classList.add('ok'); }
          else {
            b.classList.add('bad');
            btns.querySelectorAll('.fac-btn').forEach(function (x, i) {
              if (perm[i] === ex.f) x.classList.add('ok');
            });
          }
          setTimeout(function () { cur++; render(); }, 900);
        };
        btns.appendChild(b);
      });
      wrap.appendChild(btns);

      var bar = el('div', 'fac-bar');
      var fill = el('div');
      fill.style.width = (score / order.length * 100) + '%';
      bar.appendChild(fill);
      wrap.appendChild(bar);
    }
    render();
  }

  // ============================================================
  // QUIZ — 25 questions
  // ============================================================
  var QUIZ = [
    { q: 'علوم تجربی بیشتر درباره چه چیزی بحث می‌کند؟', o: ['قصه‌های قدیمی','پدیده‌های طبیعی قابل آزمایش','تاریخ پادشاهان','قوانین شهری'], c: 1 },
    { q: '«فناوری» یعنی چه؟', o: ['فقط حفظ کردن فرمول‌ها','به‌کارگیری علم برای ساخت ابزار و حل مشکل','نوشتن کتاب علمی','تماشای ستاره‌ها'], c: 1 },
    { q: 'کدام یک از عوامل تولید علم است؟', o: ['تنبلی','کنجکاوی','بی‌تفاوتی','ترس'], c: 1 },
    { q: 'هنگام مشاهده از چه چیزی استفاده می‌کنیم؟', o: ['حواس پنج‌گانه و ابزار','فقط حدس','فقط حافظه','فقط محاسبه'], c: 0 },
    { q: 'حدس علمی که قابل آزمایش باشد چه نام دارد؟', o: ['فرضیه','گزارش','قانون','مشاهده'], c: 0 },
    { q: 'در آزمایش، متغیری که ثابت نگه داشته می‌شود چه نام دارد؟', o: ['متغیر مستقل','متغیر وابسته','متغیر کنترل‌شده','فرضیه'], c: 2 },
    { q: 'تلسکوپ برای مشاهده چه چیزی ساخته شد؟', o: ['اجرام آسمانی دور','سلول‌ها','میکروب‌ها','اتم‌ها'], c: 0 },
    { q: 'میکروسکوپ چه چیزی را نشان می‌دهد؟', o: ['ستاره‌های دور','اجسام بسیار ریز','ابرها','کوه‌ها'], c: 1 },
    { q: 'کدام مورد از فواید فناوری است؟', o: ['آلودگی هوا','ارتباط سریع‌تر','زباله فضایی','عوارض جانبی'], c: 1 },
    { q: 'کدام مورد از ضررهای احتمالی فناوری است؟', o: ['درمان بیماری','انرژی پاک','آلودگی محیط زیست','ارتباط آسان'], c: 2 },
    { q: 'دانشمندان یافته‌های خود را چگونه به دیگران منتقل می‌کنند؟', o: ['با گزارش علمی','با پنهان کردن نتایج','با حدس زدن','با فراموش کردن'], c: 0 },
    { q: 'کدام مورد یک «مشاهده» است؟', o: ['رنگ محلول سبز شد','فکر می‌کنم باران می‌آید','باید آزمایش کنیم','شاید گیاه رشد کند'], c: 0 },
    { q: 'نتیجه‌گیری در کدام مرحله انجام می‌شود؟', o: ['پیش از آزمایش','پس از تحلیل داده‌ها','پیش از مشاهده','همزمان با طرح پرسش'], c: 1 },
    { q: 'برای اینکه آزمایش قابل اعتماد باشد باید چه کرد؟', o: ['فقط یک بار انجام داد','آن را چند بار تکرار کرد','نتیجه را عوض کرد','داده‌ها را پنهان کرد'], c: 1 },
    { q: 'کدام یک از شاخه‌های علوم تجربی است؟', o: ['زیست‌شناسی','خوشنویسی','ورزش','نقاشی'], c: 0 },
    { q: 'علم چگونه به دست می‌آید؟', o: ['با پرسش، مشاهده و آزمایش','فقط با شنیدن','فقط با خواب دیدن','فقط با حدس زدن'], c: 0 },
    { q: 'فرضیه‌ای که با آزمایش‌های متعدد تأیید شود چه نام دارد؟', o: ['مشاهده','نظریه','پرسش','گزارش'], c: 1 },
    { q: 'علوم تجربی به چند شاخه اصلی تقسیم می‌شود؟', o: ['دو','سه','چهار','شش'], c: 2 },
    { q: 'کدام ابزار علمی با پیشرفت فناوری ساخته شد؟', o: ['چشم','تلسکوپ','گوش','مغز'], c: 1 },
    { q: 'کدام نمونه «کاربرد علم در زندگی» است؟', o: ['طلوع خورشید','ساخت واکسن','جذر و مد','رنگین‌کمان'], c: 1 },
    { q: 'اگر آزمایش فرضیه را رد کند، دانشمند چه می‌کند؟', o: ['نتایج را تغییر می‌دهد','فرضیه را اصلاح می‌کند','علم را رها می‌کند','آزمایش را پنهان می‌کند'], c: 1 },
    { q: 'کدام مرحله از روش علمی به مشاهده وابسته است؟', o: ['گزارش‌نویسی','طرح پرسش','نتیجه‌گیری','ساخت دستگاه'], c: 1 },
    { q: 'مثال «تحلیل نتایج» در آزمایش چیست؟', o: ['حدس زدن','انتخاب ابزار','مقایسه داده‌ها','نوشتن عنوان'], c: 2 },
    { q: 'کدام یک شاخه علوم تجربی نیست؟', o: ['ریاضی','فیزیک','شیمی','زمین‌شناسی'], c: 0 },
    { q: 'چرا شرایط آزمایش را ثابت نگه می‌داریم؟', o: ['تا آزمایش ارزان شود','تا فقط یک متغیر تأثیر بگذارد','تا نتیجه زیباتر شود','تا زمان کم شود'], c: 1 }
  ];

  function initQuiz(root) {
    var sec = root.querySelector('section[data-renderer="quiz25"]');
    if (!sec) return;
    var wrap = sec.querySelector('#quiz-wrap');
    if (!wrap) return;
    var cur = 0;
    var answers = new Array(QUIZ.length).fill(-1);
    var perm = [];

    function renderQuestion() {
      wrap.innerHTML = '';
      var bar = el('div', 'quiz-progress');
      var fill = el('div');
      fill.style.width = ((cur + 1) / QUIZ.length * 100) + '%';
      bar.appendChild(fill);
      wrap.appendChild(bar);

      var meta = el('div', 'quiz-meta');
      meta.textContent = 'سوال ' + toFa(cur + 1) + ' از ' + toFa(QUIZ.length);
      wrap.appendChild(meta);

      var q = QUIZ[cur];
      var card = el('div', 'quiz-question');
      card.textContent = q.q;
      wrap.appendChild(card);

      if (perm[cur] == null) perm[cur] = shuffle([0, 1, 2, 3]);
      var opts = el('div', 'quiz-options');
      perm[cur].forEach(function (origIdx, displayIdx) {
        var b = el('button', 'quiz-opt', q.o[origIdx]);
        if (answers[cur] === origIdx) {
          b.classList.add(origIdx === q.c ? 'correct' : 'wrong');
        }
        b.onclick = function () {
          answers[cur] = origIdx;
          renderQuestion();
        };
        opts.appendChild(b);
      });
      wrap.appendChild(opts);

      var nav = el('div', 'quiz-nav');
      if (cur > 0) {
        var prev = el('button', 'btn-sm gray', 'قبلی');
        prev.onclick = function () { cur--; renderQuestion(); };
        nav.appendChild(prev);
      }
      if (cur < QUIZ.length - 1) {
        var next = el('button', 'btn-sm green', 'بعدی');
        next.onclick = function () { cur++; renderQuestion(); };
        nav.appendChild(next);
      } else {
        var fin = el('button', 'btn-sm red', 'اتمام آزمون');
        fin.onclick = function () { renderFinal(); };
        nav.appendChild(fin);
      }
      wrap.appendChild(nav);
    }

    function renderFinal() {
      var score = 0;
      for (var i = 0; i < QUIZ.length; i++) if (answers[i] === QUIZ[i].c) score++;
      var s20 = Math.round(score * 20 / QUIZ.length);
      var pct = Math.round(score * 100 / QUIZ.length);
      wrap.innerHTML = '';
      var box = el('div', 'quiz-final');
      box.appendChild(el('h3', null, 'نتیجه آزمون'));
      var bar = el('div', 'score-bar');
      var fill = el('div');
      fill.style.width = pct + '%';
      bar.appendChild(fill);
      box.appendChild(bar);
      box.appendChild(el('div', 'score-line', toFa(score) + ' از ' + toFa(QUIZ.length) + ' پاسخ درست'));
      box.appendChild(el('div', 'score-line', 'نمره شما: ' + toFa(s20) + ' از ۲۰'));
      box.appendChild(el('div', 'score-line', 'درصد موفقیت: ' + toFa(pct) + '٪'));
      var again = el('button', 'btn-sm green', 'آزمون جدید');
      again.style.marginTop = '20px';
      again.onclick = function () {
        cur = 0; answers = new Array(QUIZ.length).fill(-1); perm = []; renderQuestion();
      };
      box.appendChild(again);
      wrap.appendChild(box);
      if (pct >= 70) confettiBurst();
    }

    renderQuestion();
  }

  // ============================================================
  // CAREER — match two columns
  // ============================================================
  var CAR_NAME = ['پزشک','مهندس','زیست‌شناس','شیمی‌دان','فیزیک‌دان','زمین‌شناس','ستاره‌شناس','کشاورز علمی'];
  var CAR_DESC = ['درمان بیماری‌ها','طراحی و ساخت سازه‌ها','مطالعه موجودات زنده','مطالعه مواد و واکنش‌ها','مطالعه نیروها و انرژی','مطالعه سنگ‌ها و زمین','مطالعه ستارگان و فضا','بهبود محصولات کشاورزی'];

  function initCareer(root) {
    var sec = root.querySelector('section[data-renderer="careers"]');
    if (!sec) return;
    var wrap = sec.querySelector('#car-wrap');
    if (!wrap) return;
    var rightOrder = shuffle([0,1,2,3,4,5,6,7]);
    var done = [false,false,false,false,false,false,false,false];
    var selectedLeft = -1;
    var score = 0;

    function render() {
      wrap.innerHTML = '';
      var head = el('div', 'exp-step');
      head.textContent = 'یک شغل را انتخاب کنید، سپس توضیح مناسبش را بزنید';
      wrap.appendChild(head);

      var cols = el('div', 'car-cols');
      var left = el('div', 'car-col');
      var right = el('div', 'car-col');

      for (var i = 0; i < 8; i++) {
        var b = el('button', 'car-item left' + (done[i] ? ' done' : (selectedLeft === i ? ' sel' : '')), CAR_NAME[i]);
        if (done[i]) b.disabled = true;
        (function (idx) {
          b.onclick = function () {
            if (done[idx]) return;
            selectedLeft = idx;
            render();
          };
        })(i);
        left.appendChild(b);
      }
      for (var s = 0; s < 8; s++) {
        var ci = rightOrder[s];
        var rb = el('button', 'car-item right' + (done[ci] ? ' done' : ''), CAR_DESC[ci]);
        if (done[ci]) rb.disabled = true;
        (function (rightIdx, careerIdx) {
          rb.onclick = function () {
            if (selectedLeft < 0 || done[careerIdx]) return;
            if (selectedLeft === careerIdx) {
              done[careerIdx] = true;
              score++;
              selectedLeft = -1;
              render();
              if (score >= 8) {
                setTimeout(function () {
                  var f = el('div', 'scn-score', 'آفرین! همه را درست تطبیق دادی');
                  wrap.appendChild(f);
                  confettiBurst();
                }, 300);
              }
            } else {
              selectedLeft = -1;
              rb.style.background = '#EF4444';
              setTimeout(function () { render(); }, 400);
            }
          };
        })(s, ci);
        right.appendChild(rb);
      }
      cols.appendChild(left);
      cols.appendChild(right);
      wrap.appendChild(cols);

      var bar = el('div', 'quiz-progress');
      var fill = el('div');
      fill.style.width = (score / 8 * 100) + '%';
      bar.appendChild(fill);
      wrap.appendChild(bar);
    }
    render();
  }

  // ============================================================
  // APPS — drag 16 cards into 4 categories
  // ============================================================
  var APP_CAT = ['پزشکی', 'کشاورزی', 'صنعت', 'فضا'];
  var APP_ITEMS = [
    { t: 'واکسن', c: 0 }, { t: 'ام‌آرآی', c: 0 }, { t: 'آنتی‌بیوتیک', c: 0 }, { t: 'پیوند عضو', c: 0 },
    { t: 'کود زیستی', c: 1 }, { t: 'آبیاری قطره‌ای', c: 1 }, { t: 'تراکتور', c: 1 }, { t: 'گلخانه', c: 1 },
    { t: 'ربات جوشکار', c: 2 }, { t: 'چاپ سه‌بعدی', c: 2 }, { t: 'ماشین نساجی', c: 2 }, { t: 'توربین بادی', c: 2 },
    { t: 'ماهواره GPS', c: 3 }, { t: 'کاوشگر مریخ', c: 3 }, { t: 'تلسکوپ هابل', c: 3 }, { t: 'لباس فضانوردی', c: 3 }
  ];

  function initApps(root) {
    var sec = root.querySelector('section[data-renderer="apps4cat"]');
    if (!sec) return;
    var wrap = sec.querySelector('#apps-wrap');
    if (!wrap) return;
    var placed = new Array(APP_ITEMS.length).fill(false);
    var total = 0;
    var order = shuffle([...Array(APP_ITEMS.length).keys()]);

    function render() {
      wrap.innerHTML = '';
      var cols = el('div', 'apps-cols');
      for (var c = 0; c < 4; c++) {
        var col = el('div', 'apps-col c' + c);
        col.dataset.cat = c;
        col.appendChild(el('div', 'apps-col-title', APP_CAT[c]));
        var items = el('div', 'apps-items');
        APP_ITEMS.forEach(function (it, i) {
          if (placed[i] && it.c === c) {
            var card = el('div', 'app-card', it.t);
            card.style.background = '#ECFDF5';
            items.appendChild(card);
          }
        });
        col.appendChild(items);
        col.addEventListener('dragover', function (e) { e.preventDefault(); this.classList.add('over'); });
        col.addEventListener('dragleave', function () { this.classList.remove('over'); });
        col.addEventListener('drop', function (e) {
          e.preventDefault();
          this.classList.remove('over');
          var id = parseInt(e.dataTransfer.getData('text/plain'), 10);
          if (placed[id]) return;
          if (APP_ITEMS[id].c === c) {
            placed[id] = true; total++;
            render();
            if (total >= APP_ITEMS.length) confettiBurst();
          } else {
            var card = wrap.querySelector('[data-app-id="' + id + '"]');
            if (card) {
              card.style.borderColor = '#EF4444';
              setTimeout(function () { card.style.borderColor = '#E5E7EB'; }, 500);
            }
          }
        });
        cols.appendChild(col);
      }
      wrap.appendChild(cols);

      var pool = el('div', 'apps-pool');
      order.forEach(function (i) {
        if (placed[i]) return;
        var card = el('div', 'app-card', APP_ITEMS[i].t);
        card.dataset.appId = i;
        card.draggable = true;
        card.addEventListener('dragstart', function (e) {
          e.dataTransfer.setData('text/plain', String(i));
        });
        pool.appendChild(card);
      });
      wrap.appendChild(pool);

      var counter = el('div', 'apps-counter', toFa(total) + ' از ' + toFa(APP_ITEMS.length));
      wrap.appendChild(counter);
    }
    render();
  }

})();